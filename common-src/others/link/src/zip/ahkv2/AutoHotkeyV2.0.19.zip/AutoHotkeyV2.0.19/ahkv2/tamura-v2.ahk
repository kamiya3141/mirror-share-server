﻿#Requires AutoHotkey v2

#SingleInstance Force

#Include %A_ScriptDir%/..
#Include Lib/JXON.ahk

SetWorkingDir(A_ScriptDir "/../src")

; CoordMode "Mouse", "Screen"
CoordMode "ToolTip", "Screen"

; 以下からコードを記述

/*
####################################################################
変数と関数定義
####################################################################
*/

global LockGui := Gui()
global LockGuiPasswdName := "InputPassword"
;Modeが8の時のパスワード
global correctPassword := "15926535"
;ロックキー
global Keys := ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u",
    "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "^", "\", "/", "[", "]", "@", ".",
    "`,", "`:", "`;", "NumpadDiv", "NumpadMult", "NumpadAdd", "NumpadSub", "NumpadEnter", "Delete", "PrintScreen",
    "Pause",
    "Sleep", "Help", "ScrollLock", "CapsLock", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11",
    "F12",
    "Esc", "Space", "Tab", "LWin", "RWin", "Shift", "Ctrl", "Alt", "Up", "Down", "Left", "Right", "LButton", "RButton",
    "MButton", "WheelDown", "WheelUp", "WheelLeft", "WheelRight"]

global MainShortCutKeys := [
    Map(
        "modifier", "^",
        "basename", "",
        "function", "CtrlNFunc",
        "keys", [
            ["0", ["0", "通常モードになりました"]],
            ["1", ["1", "ブラウザモードになりました"]],
            ["2", ["2", "エディターモードになりました"]],
            ["3", ["3", "ゲーム起動モードになりました"]],
            ["4", ["4", "ファイル関連モードになりました"]],
            ["5", ["5", "チャットモードになりました"]],
            ["6", ["6", "お気に入り1モードになりました"]],
            ["7", ["7", "お気に入り2モードになりました"]],
            ["8", ["8", "ロックモードになりました"]],
            ["9", ["9", "電源・アカウント操作モードになりました"]]
        ]
    ),
    Map(
        "modifier", "",
        "basename", "Numpad",
        "function", "NumpadNFunc",
        "keys", [
            ["0", ["0"]],
            ["1", ["1"]],
            ["2", ["2"]],
            ["3", ["3"]],
            ["4", ["4"]],
            ["5", ["5"]],
            ["6", ["6"]],
            ["7", ["7"]],
            ["8", ["8"]],
            ["9", ["9"]],
            ["Dot", ["Dot"]]
        ]
    )
]

;ロックされてるかのフラッグ
global LockFlag := false
; テスト用またはカウント用変数
global CountNumber := 0

;PlayButtonSound用の音源定義
global ButtonSounds := [2, 6, 4, 5, 8]
global ScreenWidth := SysGet(78)
global ScreenHeight := SysGet(79)

global HalfScreenW := ScreenWidth / 2
global HalfScreenH := ScreenHeight / 2

global QScreenW := HalfScreenW / 2
global QScreenH := HalfScreenH / 2

global OScreenW := QScreenW / 2
global OScreenH := QScreenH / 2

global AddW := 10
global AddH := 31

global ScreenWidthMap := ScreenWidth + AddW * 2
global ScreenHeightMap := ScreenHeight + AddH * 2

;通常モードは0
global CtrlNumMode := 0
;ゲームモードを管理する変数
global GameMode := false
;プログラミングをするとき用のXButton + マウスボタンの切り替え
global ProgrammingMode := true
;追加キーボードの打鍵音設定
global AddKeySoundMode := true
;キーボードの打鍵音設定
global KeySoundMode := false
;キーボードの打鍵音の参照ディレクトリ設定
global KeySoundIndex := 3
;偽造マップのURL
global URLNAME := "gakugei.ohuda.com/svg/cx-map/index.svg"
;マイクラに使う連想配列
global MINECRAFT := Map("TF", false, "Loop", Map("Walk", false, "RBtn", false))
;Mediaが再生中かどうか（ほとんど機能していません）
global SoundPlayTF := false

global CurrentVolume := 0

global PlayButtonSoundExt := ".mp3"

; #############################################################################

global Ctrl8OrLockWindowsFlag := true

; #############################################################################

global NumpadMediaControl := false
global NumpadMediaControlAutoChange := false

global REPLACED_HOME_DIR_MARK := "DHU"
global DEFAULT_HOME_DIR := "/home/tamura"

AddKeyBoardHotkeyMap_text := FileRead("./common/json/AddKeyBoard-HotkeyMap.json")
global AddKeyBoardHotkeyMap := Jxon_Load(&AddKeyBoardHotkeyMap_text)
global SoundBeepStop := false
global SoundBeepWaitTime := 50
global AddKeyBoardStackCommandShortCutStr := ""
global AddKeyBoardStackCommand := ""
global AddKeyBoardIncludeWords := []
global AddSoundKeyBoardMuteTF := false
global AddKeyBoardKeyReverseTF := false

global LoadStreamDeck_AHK := true
GetLoadStreamDeck_AHK_Value() {
    global LoadStreamDeck_AHK
    return LoadStreamDeck_AHK
}

#Include ./ahkv2/utils/utils-functions-v2.ahk
#Include ./ahkv2/utils/utils-visuals.ahk
#Include ./ahkv2/projects/tamura/tamura-parts-v2.ahk
#Include ./ahkv2/projects/tamura/tamura-body-v2.ahk
#Include ./src/streamDeck/ahk/ahkv2/streamDeck-v2.ahk
#Include ./ahkv2/projects/tamura/tamura-addkeyboard-v2.ahk

CurrentVolume := GetVolume()
SetVolume(CurrentVolume)

CtrlN_Numpad_setFunc()

SetHotkeyFunc2()

AddKeyBoard_setFunc()

AddKeyBoardCommandExecFunc("3411", true)
AddKeyBoardCommandExecFunc("4321", true)

; 起動後の表示
DisplayToolTip("起動しました", 2000)