GetWindow_SSHSelectorDisplay() {
    global SSHSelectorGUI
    return SSHSelectorGUI
}

SetWindow_SSHSelectorDisplay(newGui) {
    global SSHSelectorGUI
    SSHSelectorGUI := newGui
    return SSHSelectorGUI
}

DestroyWindow_SSHSelectorDisplay() {
    local MyGui := GetWindow_SSHSelectorDisplay()
    MyGui.Destroy()
    return MyGui
}

global SSHSelectorDisplayParentInfo := Map("x", 0, "y", 0, "w", 1920, "h", 1080)
global SSHSelectorDisplayInfo := Map("w", SSHSelectorDisplayParentInfo["w"] * 3 / 4, "h", SSHSelectorDisplayParentInfo["h"] * 3 / 4)
; 基本情報
SSHSelectorDisplayInfo.Set("x", (SSHSelectorDisplayParentInfo["w"] - SSHSelectorDisplayInfo["w"]) / 2)
SSHSelectorDisplayInfo.Set("y", (SSHSelectorDisplayParentInfo["h"] - SSHSelectorDisplayInfo["h"]) / 2)
SSHSelectorDisplayInfo.Set("strict", "+AlwaysOnTop +Resize +ToolWindow -SysMenu +OwnDialogs -Caption")
SSHSelectorDisplayInfo.Set("background-color", "White")
SSHSelectorDisplayInfo.Set("font-size", "s20")
SSHSelectorDisplayInfo.Set("font-family", "Arial")
; ウィンドウ内タイトル
SSHSelectorDisplayInfo.Set("title", Map("x", SSHSelectorDisplayInfo["x"], "y", SSHSelectorDisplayInfo["y"], "w", SSHSelectorDisplayInfo["w"], "h", SSHSelectorDisplayInfo["h"] * 1 / 5))
; ウィンドウ内コンテンツボックス
SSHSelectorDisplayInfo.Set("contentsbox", Map("x", SSHSelectorDisplayInfo["x"], "y", SSHSelectorDisplayInfo["y"] + SSHSelectorDisplayInfo["title"]["h"], "w", SSHSelectorDisplayInfo["w"], "h", SSHSelectorDisplayInfo["h"] - SSHSelectorDisplayInfo["title"]["h"], "max-lines", 4, "max-columns", 5))
SSHSelectorDisplayInfo["contentsbox"].Set("max-items", SSHSelectorDisplayInfo["contentsbox"]["max-lines"] * SSHSelectorDisplayInfo["contentsbox"]["max-columns"])
; コンテンツボックス内コンテンツ（関数）
SSHSelectorDisplayInfo.Set("contents-calc", Map("w", (__CL__) => SSHSelectorDisplayInfo["contentsbox"]["w"] / __CL__, "h", (__LN__) => SSHSelectorDisplayInfo["contentsbox"]["h"] / __LN__))
SSHSelectorDisplayInfo["contents-calc"].Set("x", (__I__, __CL__, __LN__) => SSHSelectorDisplayInfo["contentsbox"]["x"] + (Mod((__I__ - 1), __CL__) * SSHSelectorDisplayInfo["contents-calc"]["w"](__CL__)))
SSHSelectorDisplayInfo["contents-calc"].Set("y", (__I__, __CL__, __LN__) => SSHSelectorDisplayInfo["contentsbox"]["x"] + (Floor((__I__ - 1) / __CL__) * SSHSelectorDisplayInfo["contents-calc"]["h"](__LN__)))


global FlexBoxLNCLArray := []
GetCalcFlexBoxContentsLNCL(n := 1) {
    global FlexBoxLNCLArray
    if n < 1
        n := 1
    if FlexBoxLNCLArray.Length < 1 {
        local __cl := SSHSelectorDisplayInfo["contentsbox"]["max-columns"]
        local __ln := SSHSelectorDisplayInfo["contentsbox"]["max-lines"]
        loop (__cl * __ln)
            FlexBoxLNCLArray.Push([(A_Index <= __cl ? A_Index : __cl), Floor(A_Index / __cl) + 1])
    }
    return FlexBoxLNCLArray[n]
}

CreateWindow_SSHSelectorDisplay() {

    local MyGui := DestroyWindow_SSHSelectorDisplay()
    MyGui := Gui(SSHSelectorDisplayInfo["strict"])
    SetWindow_SSHSelectorDisplay(MyGui)
    

    local MyGuiXYWH := Map("x", 0, "y", 0, "w", 0, "h", 0)

}