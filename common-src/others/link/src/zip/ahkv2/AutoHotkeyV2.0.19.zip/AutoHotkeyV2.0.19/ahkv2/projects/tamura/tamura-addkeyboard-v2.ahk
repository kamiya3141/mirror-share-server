AddKeyBoardShortCutStr(sht_str := "") {
    global AddKeyBoardStackCommandShortCutStr
    AddKeyBoardStackCommandShortCutStr := sht_str
    AddKeyBoardSetIncludeWords(sht_str)
    return
}
AddKeyBoardSetIncludeWords(input_str := "") {
    global AddKeyBoardHotkeyMap, AddKeyBoardIncludeWords
    if (input_str != "")
        AddKeyBoardIncludeWords := MapIncludeHitKey(AddKeyBoardHotkeyMap["cmd"], input_str, 1)
    return
}

AddKeyBoardKeyReverse(*) {
    global AddKeyBoardKeyReverseTF
    DisplayMsgBox("現在、こちらの機能は停止しています。")
    ; AddKeyBoardKeyReverseTF := !AddKeyBoardKeyReverseTF
    return
}

AddSoundKeyBoardMuteTFFunc(*) {
    global AddSoundKeyBoardMuteTF
    AddSoundKeyBoardMuteTF := !AddSoundKeyBoardMuteTF
    return
}

AddKeyBoardCommandExecFunc(input_cmd := "", background_flag := false) {
    global AddKeyBoardHotkeyMap, AddKeyBoardStackCommandShortCutStr, AddKeyBoardIncludeWords

    NumpadMediaControlFunc(false, true)

    if (AddKeyBoardStackCommandShortCutStr != "" && ArrayInclude(AddKeyBoardIncludeWords,
        AddKeyBoardStackCommandShortCutStr . input_cmd))
        input_cmd := AddKeyBoardStackCommandShortCutStr . input_cmd

    local _playSoundInputTF := true && !AddSoundKeyBoardMuteTF
    if (input_cmd != "" && AddKeyBoardHotkeyMap["cmd"].Has(input_cmd)) {
        PlayButtonSound(5, "se", _playSoundInputTF && !background_flag)
        local input_array := AddKeyBoardHotkeyMap["cmd"][input_cmd]
        local cmd_type_array := input_array["cmd-type"]
        local cmd_data_array := input_array["cmd"]
        local args := input_array["args"]

        if (cmd_type_array.Length != cmd_data_array.Length) {
            DisplayToolTip("Invalid-JSON-data: " input_cmd, 3000)
            return
        }

        for i, vt in cmd_type_array {
            for j, vd in cmd_data_array[i] {
                vd := TmScriptRegExReplaceAllEnvVars(vd)
                switch (vt) {
                    case "s":
                        Send(vd)
                    case "f":
                        if (ArrayEmpty(args) || ArrayEmpty(args[i]) || ArrayEmpty(args[i][j]))
                            %vd%()
                        else if (!ArrayEmpty(args[i]) && !ArrayEmpty(args[i][j]))
                            %vd%(args[i][j]*)
                    case "r":
                        Run(vd)
                    default:
                        DisplayToolTip("Invalid-cmd-type: " vt, 2000)
                }
                if (cmd_data_array.Length > 0)
                    Sleep 100
            }
            if (cmd_type_array.Length > 0)
                Sleep 100
        }
    } else if (!background_flag) {
        input_cmd := input_cmd == "" ? gsp() : input_cmd
        DisplayToolTip(input_cmd, 2000)
        PlayButtonSound(5, "b", _playSoundInputTF)
    }
    return
}

GetMirrorValue(l, n) {
    return l - n + 1
}

AddKeyBoardEditStackCommand(input_str := "", add_flag := true, get_flag := false) {
    global AddKeyBoardStackCommand
    if (!get_flag)
        AddKeyBoardStackCommand := (add_flag ? AddKeyBoardStackCommand : "") . input_str
    return AddKeyBoardStackCommand
}

AddKeyBoardExecFunc(idx := 7, hz := 1300) {
    global AddKeyBoardHotkeyMap, SoundBeepWaitTime, AddKeyBoardKeyReverseTF

    if CheckDisplayLock() == -1
        return
    local idx_max := AddKeyBoardHotkeyMap["data"].Length
    if (AddKeyBoardKeyReverseTF)
        idx := GetMirrorValue(idx_max, idx)
    local sound_tf := idx == idx_max
    ; DisplayToolTip(AddKeyBoardEditStackCommand(, , true))
    if (sound_tf) {
        AddKeyBoardCommandExecFunc(AddKeyBoardEditStackCommand(, , true))
        AddKeyBoardEditStackCommand(, false)
    } else if (StrLen(AddKeyBoardEditStackCommand(, , true)) < 100)
        AddKeyBoardEditStackCommand(String(idx))
    PlayButtonSound(1, idx, !sound_tf && !AddSoundKeyBoardMuteTF)
    /*
    if (AddKeyBoardEditStackCommand(, , true) == "44")
        AddKeyBoardExecFunc()
    else
        PlayButtonSound(1, idx, !sound_tf && !AddSoundKeyBoardMuteTF)
    */
    ; SetTimer((*) => SoundBeep((hz[1] + hz[2]) / 1.75, SoundBeepWaitTime), -10)
    return
}

Process_AddKeyBoardExecFunc(args*) {
    return (*) => AddKeyBoardExecFunc(args*)
}

AddKeyBoard_setFunc() {
    global AddKeyBoardHotkeyMap, SoundBeepWaitTime
    for idx, val in AddKeyBoardHotkeyMap["data"]
        Hotkey(val[1], Process_AddKeyBoardExecFunc(idx, val[2]))
    return
}