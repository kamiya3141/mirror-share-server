﻿SetScreenSize(*) {
    global ScreenWidth, ScreenHeight
    global HalfScreenW, HalfScreenH, QScreenW, QScreenH, OScreenW, OScreenH
    global AddW, AddH
    global ScreenWidthMap, ScreenHeightMap

    ScreenWidth := SysGet(78)
    ScreenHeight := SysGet(79)

    HalfScreenW := ScreenWidth / 2
    HalfScreenH := ScreenHeight / 2

    QScreenW := HalfScreenW / 2
    QScreenH := HalfScreenH / 2

    OScreenW := QScreenW / 2
    OScreenH := QScreenH / 2

    ScreenWidthMap := ScreenWidth + AddW * 2
    ScreenHeightMap := ScreenHeight + AddH * 2

    return
}

EditProgrammingMode(tf := true, get_flag := false) {
    global ProgrammingMode
    if get_flag
        return ProgrammingMode
    ProgrammingMode := tf
    return ProgrammingMode
}

SendSpaceFunc(*) {
    if EditProgrammingMode(, true)
        Send gsp()
    else
        Send gsp(0)
    PlayKeyboardSpaceEnterSound()
    return
}

;無効化
DisableKey(*) {
    return
}
;未登録メッセージ
NotExistMessage(*) {
    DisplayToolTip("######`n`n未登録です`n`n######", 250)
}

GetCtrlNumMode(*) {
    global CtrlNumMode
    return CtrlNumMode
}
SetCtrlNumMode(_num := 0) {
    global CtrlNumMode
    CtrlNumMode := ((_num > 9 || _num < 0) ? 10 : _num)
    return
}

;キーボードの音を鳴らす
PlayKeyboardNormalSound(*) {
    PlayButtonSound(5, "r")
    return
}

PlayKeyboardSpaceEnterSound(*) {
    PlayButtonSound(5, "se")
    return
}

PlayKeyboardBackspaceSound(*) {
    PlayButtonSound(5, "b")
    return
}

DisplayNowDays(*) {
    nowDay := A_Now
    nowDayArray := [SubStr(nowDay, 1, 4), SubStr(nowDay, 5, 2), SubStr(nowDay, 7, 2), SubStr(nowDay, 9, 2), SubStr(
        nowDay,
        11, 2)]
    nowGengo := nowDayArray[1] - 2018
    DisplayMsgBox(StrJoin(["#", "令和" nowGengo "年", "西暦" nowDayArray[1] "年", nowDayArray[2] "月", nowDayArray[3] "日",
        nowDayArray[4] "時", nowDayArray[5] "分", "#"], "`n"))
    return
}

PlayButtonSound(Idx := 1, Idx2 := 1, TmScriptPlayedOrOthers := false) {
    global KeySoundMode, ButtonSounds, PlayButtonSoundExt
    if (!KeySoundMode && !TmScriptPlayedOrOthers)
        return

    if (Idx2 == "r") {
        if (Idx < 1 || Idx > ButtonSounds.Length)
            Idx := 1
        Idx2 := Random(1, ButtonSounds[Idx])
    } else if (Idx < 5 && Idx2 > ButtonSounds[Idx + 1])
        Idx2 := 1

    FileName := "common\button\" Idx "\" Idx2 PlayButtonSoundExt
    Alias := "btn" Idx Idx2

    SoundPlayFunc(FileName, Alias)

    return
}

OpenCommandPrompt(input_cmd := "", _time := 250) {
    Send "#r"
    Sleep(_time)
    AddEnter("cmd")
    Sleep(_time * 4)
    if input_cmd != ""
        AddEnter(input_cmd, _time)
    return
}

CheckDisplayLock(Idx := 1) {
    global LockFlag, NumpadMediaControl
    if (LockFlag) {
        Idx := -1
    } else if (!LockFlag && GetCtrlNumMode() = 8) {
        Idx := -1
        ShowLockScreen()
    }
    if (Idx = -1 && NumpadMediaControl)
        NumpadMediaControl := false
    return Idx
}

;Modeが8の時にロック画面を起動するためのホットキーの起動と解除
;EnterとBackspaceは入力時に必要なため個別に設定（Keysは IfWinActive 内で再利用するため）

SetHotkeyFunc(TF := true) {
    global Keys
    local onof := TF ? "On" : "Off"
    for Key in Keys
        Hotkey(Key, ShowLockScreen, onof)
    Hotkey("Enter", ShowLockScreen, onof)
    Hotkey("Backspace", ShowLockScreen, onof)
}

SetHotkeyFunc2(TF := true) {
    global Keys
    local onof := TF ? "On" : "Off"
    for Key in Keys
        Hotkey("~" Key, PlayKeyboardNormalSound, onof)
    Hotkey("~Enter", PlayKeyboardSpaceEnterSound, onof)
    Hotkey("~Backspace", PlayKeyboardBackspaceSound, onof)
    Hotkey("Space", SendSpaceFunc, onof)
}

;パスワード確認
CheckPassword(&passwd_edit) {
    global LockGui, LockGuiPasswdName, LockFlag, correctPassword
    LockGui.Submit(true)
    if (passwd_edit.Value = correctPassword) {
        LockFlag := false
        SetCtrlNumMode()
        SetHotkeyFunc2()
        LockGui.Destroy()
    } else {
        ShowLockScreen()
        DisplayToolTip("パスワードが違います。", 1500)
    }
    return
}

ShowLockScreen(*) {
    global LockGui, LockGuiPasswdName, LockFlag, Keys, ScreenWidth, ScreenHeight, HalfScreenW, HalfScreenH

    SetScreenSize()

    LockFlag := true

    LockGui.Destroy()
    LockGui := Gui()
    LockGui.Opt("+AlwaysOnTop -Resize +ToolWindow -SysMenu +OwnDialogs -Border -Caption")
    LockGui.BackColor := "000000"
    local font_size := 40
    LockGui.SetFont("s" font_size " cff0000 w500", "Arial")

    local TextPos := [HalfScreenW / 2, HalfScreenH * 1 / 2, HalfScreenW, font_size * 1.25]
    local PasswdPos := [HalfScreenW - HalfScreenW / 4, HalfScreenH, HalfScreenW / 2, font_size * 1.25]
    local ButtonPos := [HalfScreenW - font_size * 2, HalfScreenH * 3 / 2, font_size * 4, font_size * 1.25]
    local LockGuiPos := ["-" font_size / 2, "-" font_size / 2, ScreenWidth + font_size / 2, ScreenHeight + font_size /
        2]

    LockGui.Add("Text", "x" TextPos[1] " y" TextPos[2] " w" TextPos[3] " h" TextPos[4] " +Center", " パスワードを入力してください")
    ; パスワード入力用のEditボックス
    local LockGuiEditObj := LockGui.Add("Edit", "x" PasswdPos[1] " y" PasswdPos[2] " w" PasswdPos[3] " h" PasswdPos[4] " v" LockGuiPasswdName " Password● +Center -Multi -HScroll -VScroll"
    )
    local LockGuiButtonObj := LockGui.Add("Button", "x" ButtonPos[1] " y" ButtonPos[2] " w" ButtonPos[3] " h" ButtonPos[
        4] " +Center Default",
        "OK")
    ; フルスクリーンでウィンドウを表示
    LockGui.Show("x" LockGuiPos[1] " y" LockGuiPos[2] " w" LockGuiPos[3] " h" LockGuiPos[4])

    HotIfWinActive "ahk_id " LockGui.Hwnd
    ; タスクマネージャー無効化 (無理に決まってんだろ)
    Hotkey("!Tab", DisableKey)
    Hotkey("#Tab", DisableKey)
    Hotkey("#d", DisableKey)
    Hotkey("#m", DisableKey)
    Hotkey("^!Delete", DisableKey)
    Hotkey("#^d", DisableKey)
    Hotkey("#^Left", DisableKey)
    Hotkey("#^Right", DisableKey)
    Hotkey("!F4", DisableKey)
    for Index, Key in Keys {
        Cmd := "*" Key
        Hotkey(Cmd, DisableKey)
    }
    HotIfWinActive

    LockGui[LockGuiPasswdName].Focus()

    LockGuiButtonObj.OnEvent("Click", (*) => CheckPassword(&LockGuiEditObj))

    ;ロック画面起動用のホットキーを解除
    SetHotkeyFunc(false)

    if GetLoadStreamDeck_AHK_Value()
        TmScriptSwitchControlLock()

    return
}

SwitchDesktop(Direction) {
    DKey := 0x44 ;Dキー
    Left := 0x25 ; ←キー
    Right := 0x27 ; →キー
    Ctrl := 0x11
    Win := 0x5B ; 左Windowsキー
    ;仮想デスクトップ作成か移動かを決めるキー（初期値をDにセット）
    Direction_Key := DKey

    if (Direction = 1) {
        Direction_Key := Left
    } else if (Direction = 2) {
        Direction_Key := Right
    }

    ; Win + Ctrl + (Left/Right)
    DllCall("keybd_event", "UInt", Win, "UInt", 0, "UInt", 0, "UInt", 0)
    DllCall("keybd_event", "UInt", Ctrl, "UInt", 0, "UInt", 0, "UInt", 0)
    DllCall("keybd_event", "UInt", Direction_Key, "UInt", 0, "UInt", 0, "UInt", 0)

    Sleep 50 ; 安定のため

    ; キーを離す
    DllCall("keybd_event", "UInt", Direction_Key, "UInt", 0, "UInt", 2, "UInt", 0)
    DllCall("keybd_event", "UInt", Ctrl, "UInt", 0, "UInt", 2, "UInt", 0)
    DllCall("keybd_event", "UInt", Win, "UInt", 0, "UInt", 2, "UInt", 0)

    return
}

;メディア
MediaNextFunc(*) {
    if CheckDisplayLock() == -1
        return
    Send "{Media_Next}"
    return
}
MediaPrevFunc(*) {
    if CheckDisplayLock() == -1
        return
    Send "{Media_Prev}"
    return
}
MediaPlayPauseFunc(*) {
    if CheckDisplayLock() == -1
        return
    Send "{Media_Play_Pause}"
    return
}
; システム
VolumeUpFunc(*) {
    global CurrentVolume
    if CheckDisplayLock() == -1
        return
    Send "{Volume_Up}"
    CurrentVolume := GetVolume()
    return
}
VolumeDownFunc(*) {
    global CurrentVolume
    if CheckDisplayLock() == -1
        return
    Send "{Volume_Down}"
    CurrentVolume := GetVolume()
    return
}
VolumeMuteFunc(*) {
    if CheckDisplayLock() == -1
        return
    Send "{Volume_Mute}"
    return
}
WindowTabFunc(*) {
    DllCall("keybd_event", "UInt", 0x5B, "UInt", 0, "UInt", 0, "UInt", 0)
    DllCall("keybd_event", "UInt", 0x09, "UInt", 0, "UInt", 0, "UInt", 0)
    DllCall("keybd_event", "UInt", 0x09, "UInt", 0, "UInt", 2, "UInt", 0)
    DllCall("keybd_event", "UInt", 0x5B, "UInt", 0, "UInt", 2, "UInt", 0)
    return
}
SwitchProgrammingModeFunc(*) {
    global GameMode
    if (!GameMode) {
        Send "{Shift Up}"
        local current_programming_mode := EditProgrammingMode(!EditProgrammingMode(, true))
        if GetLoadStreamDeck_AHK_Value()
            TmScriptPlayButtonFunc(6, i2bs(current_programming_mode))
        DisplayToolTip((current_programming_mode ? "Programming Mode On" : "Programming Mode Off"), 1000)
    } else {
        DisplayMsgBox("ProgrammingModeを変更できません`nGameModeをfalseにしてください")
    }
    return
}

SwitchGameModeFunc(*) {
    global GameMode, MINECRAFT

    if CheckDisplayLock() == -1
        return

    GameMode := !GameMode
    if GetLoadStreamDeck_AHK_Value()
        TmScriptPlayButtonFunc(6, (GameMode ? "true" : "false"))
    DisplayToolTip((GameMode ? "GameMode On" : "GameMode Off"), 1000)
    MINECRAFT["TF"] := (GameMode ? MINECRAFT["TF"] : false)
    return
}

SwitchKeySoundModeFunc(*) {
    global GameMode, KeySoundMode
    if (!GameMode) {
        Send "{Down Up}"
        KeySoundMode := !KeySoundMode
        if GetLoadStreamDeck_AHK_Value()
            TmScriptPlayButtonFunc(6, (KeySoundMode ? "true" : "false"))
        DisplayToolTip((KeySoundMode ? "KeySoundMode On" : "KeySoundMode Off"))
    } else {
        if GetLoadStreamDeck_AHK_Value()
            TmScriptPlayButtonFunc(5, "b")
        DisplayMsgBox("KeySoundModeを変更できません`nGameModeをfalseにしてください")
    }
    return
}
NumpadMediaControlFunc(not_background_flag := true, force_false := false) {
    global NumpadMediaControl
    if force_false == true {
        NumpadMediaControl := false
    } else {
        NumpadMediaControl := !NumpadMediaControl
        if not_background_flag
            DisplayToolTip("NumpadMediaControl : " . i2bs(NumpadMediaControl), 500)
    }
    return
}
NumpadMediaControlAutoChangeFunc(*) {
    global NumpadMediaControlAutoChange
    if CheckDisplayLock() == -1
        return
    NumpadMediaControlAutoChange := !NumpadMediaControlAutoChange
    DisplayToolTip("NumpadMediaControlAutoChange : " . (NumpadMediaControlAutoChange ? "true" : "false"), 500)
    NumpadMediaControlFunc()
    return
}

ReloadThisScript(*) {
    Reload()
    return
}

AddEnter(added_str := "", _time := 100) {
    Send(added_str)
    Send "{Enter}"
    Sleep(_time)
    return
}

SendWord_exit(cnt := 1, _time := 100) {
    loop cnt
        AddEnter("exit", _time)
    return
}
SendWord_clear(add_sudo := false) {
    AddEnter(add_sudo ? "sudo clear" : "clear")
    return
}
SendWord_MyPassword(type := 1) {
    type := (type < 1 || type > 3) ? 1 : type
    local str_begin := type == 1 ? "z" : "Z"
    local str_end := type < 2 ? "" : "_"
    local str_password := str_begin . "pulasa1" . str_end
    AddEnter(str_password)
    return
}
SendWord_VSCode_RemoteSSH(host := "", target_dir := "", _time := 500) {
    if host = "" || target_dir = ""
        DisplayMsgBox(["Value Error :", "ホストまたはターゲットのフォルダ・ファイルが不明です", "関数の実行を停止します"], true)
    else
        OpenCommandPrompt(StrJoin(["code", "--remote", "ssh-remote{+}" host, ReplacedHomeDir(target_dir), "&",
            "exit"],
            gsp()), _time)
    return
}
ReplacedHomeDir(input_dir := "") {
    global DEFAULT_HOME_DIR, REPLACED_HOME_DIR_MARK
    input_dir := StrReplace(input_dir, REPLACED_HOME_DIR_MARK, DEFAULT_HOME_DIR)
    return input_dir
}

InputKeyBoard(opt_str_len := 1) {
    local ih := InputHook("L" . opt_str_len . " A")
    ih.KeyOpt("{All}", "E")
    ih.Start()
    ih.Wait()
    local pressed_key := ih.EndKey
    return pressed_key
}


CtrlNFunc(md := 0, msg := "", check_display_lock_flag := true) {
    if CheckDisplayLock() == -1 && check_display_lock_flag
        return
    SetCtrlNumMode(md)
    if (md == 8)
        Ctrl8Func()
    if (msg != "")
        DisplayToolTip(msg)
    return
}

NumpadNFunc(n) {
    global CtrlNumMode, NumpadMediaControl, NumpadMediaControlAutoChange
    switch (n) {
        case 0:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                VolumeDownFunc()
                SetVolume(n * 10 + 0)
                return
            }
            switch (CtrlNumMode) {
                case 0:
                    CheckDisplayLock()
                    Send "0"
                case 1:
                    Run "C:\Users\shuut\Desktop\shortcut\Tor Browser.lnk"
                case 2:
                    DisplayMsgBox("登録されていません。")
                case 3:
                    Run "C:\Users\shuut\Desktop\shortcut\Minecraft.exe.lnk"
                case 4:
                    OpenCommandPrompt()
                case 5:
                    DisplayMsgBox("登録されていません。")
                case 6:
                    DisplayMsgBox("登録されていません。")
                case 7:
                    DisplayMsgBox("登録されていません。")
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    ; スリープ
                    SleepSend(100, "#x", "u", "s")
                default:
                    DisplayMsgBox("未知のモードで0を押したんやで")
            }
        case 1:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                VolumeDownFunc()
                SetVolume(n * 10 + 2)
                return
            }
            switch (CtrlNumMode) {

                case 0:
                    CheckDisplayLock()
                    Send "1"
                case 1:
                    Run "C:\Users\shuut\Desktop\shortcut\shuto - Chrome.lnk"
                case 2:
                    Run "C:\Users\shuut\Desktop\shortcut\Visual Studio Code.lnk"
                case 3:
                    Run "C:\Users\shuut\Desktop\shortcut\PCSX2.lnk"
                case 4:
                    Run "C:\Users\shuut\Desktop\shortcut\Tera Term.lnk"
                case 5:
                    Run "C:\Users\shuut\Desktop\shortcut\LINE.lnk"
                case 6:
                    Run(
                        "C:\Users\shuut\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Chrome アプリ\YouTube Music.lnk"
                    )
                case 7:
                    Send "#i"
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    ; ログアウト
                    SleepSend(100, "#x", "u", "i")
                default:
                    DisplayMsgBox("未知のモードで1を押したんやで")
            }
        case 2:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                VolumeDownFunc()
                SetVolume(n * 10 + 2)
                return
            }
            switch (CtrlNumMode) {

                case 0:
                    CheckDisplayLock()
                    Send "2"
                case 1:
                    Run "C:\Users\shuut\Desktop\shortcut\seigo - Chrome.lnk"
                case 2:
                    Run "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Visual Studio 2022.lnk"
                case 3:
                    Run "C:\Users\shuut\Desktop\shortcut\rpcs3.exe.lnk"
                case 4:
                    Run "C:\Users\shuut\Desktop\shortcut\FileZilla.lnk"
                case 5:
                    Run "C:\Users\shuut\Desktop\shortcut\Discord.lnk"
                case 6:
                    Run "C:\Users\shuut\Documents\TaskbarGroups\TaskbarGroups.exe"
                case 7:
                    Send "^+{Esc}"
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    ; 再起動
                    SleepSend(100, "#x", "u", "r")
                default:
                    DisplayMsgBox("未知のモードで2を押したんやで")
            }
        case 3:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                VolumeDownFunc()
                SetVolume(n * 10 + 0)
                return
            }
            switch (CtrlNumMode) {

                case 0:
                    CheckDisplayLock()
                    Send "3"
                case 1:
                    Run "C:\Users\shuut\Desktop\shortcut\yuto - Chrome.lnk"
                case 2:
                    Run "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Notepad++.lnk"
                case 3:
                    Run "C:\Users\shuut\Nestopia\nestopia.exe"
                case 4:
                    Run "C:\Users\shuut\Desktop\shortcut\WinSCP.lnk"
                case 5:
                    Run "C:\Users\shuut\Desktop\shortcut\Slack.exe.lnk"
                case 6:
                    Run("C:\Users\shuut\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Blender\Blender 4.3.lnk"
                    )
                case 7:
                    Run "calc.exe"
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    ; シャットダウン
                    SleepSend(100, "#x", "u", "u")
                default:
                    DisplayMsgBox("未知のモードで3を押したんやで")
            }
        case 4:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                MediaPrevFunc()
                return
            }
            switch (CtrlNumMode) {

                case 0:
                    CheckDisplayLock()
                    Send "4"
                case 1:
                    Run "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Microsoft Edge.lnk"
                case 2:
                    Run "C:\Users\shuut\Desktop\shortcut\notepad.exe.lnk"
                case 3:
                    Run "C:\Users\shuut\Desktop\shortcut\rpcs3.exe.lnk"
                case 4:
                    Run "C:\Users\shuut\Documents\ShellNewEdit1_20\ShellNewEdit\shellnewedit.exe"
                case 5:
                    DisplayMsgBox("登録されていません。")
                case 6:
                    Run(
                        "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Oracle VM VirtualBox\Oracle VM VirtualBox.lnk"
                    )
                case 7:
                    Run "C:\Users\shuut\Documents\TaskbarGroups\TaskbarGroups.exe"
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    DisplayMsgBox("登録されていません。")
                default:
                    DisplayMsgBox("未知のモードで4を押したんやで")
            }
        case 5:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                MediaPlayPauseFunc()
                return
            }
            switch (CtrlNumMode) {

                case 0:
                    CheckDisplayLock()
                    Send "5"
                case 1:
                    Run "C:\Users\shuut\Desktop\shortcut\Opera ブラウザ.lnk"
                case 2:
                    Run "C:\Users\shuut\Desktop\shortcut\processing.exe.lnk"
                case 3:
                    DisplayMsgBox("登録されていません。")
                case 4:
                    DisplayMsgBox("登録されていません。")
                case 5:
                    DisplayMsgBox("登録されていません。")
                case 6:
                    DisplayMsgBox("登録されていません。")
                case 7:
                    DisplayMsgBox("登録されていません。")
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    DisplayMsgBox("登録されていません。")
                default:
                    DisplayMsgBox("未知のモードで5を押したんやで")
            }
        case 6:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                MediaNextFunc()
                return
            }
            switch (CtrlNumMode) {

                case 0:
                    CheckDisplayLock()
                    Send "6"
                case 1:
                    Run "C:\Users\shuut\Desktop\shortcut\Opera GX ブラウザ.lnk"
                case 2:
                    Run "C:\Users\shuut\xedit184\xedit.exe"
                case 3:
                    DisplayMsgBox("登録されていません。")
                case 4:
                    DisplayMsgBox("登録されていません。")
                case 5:
                    DisplayMsgBox("登録されていません。")
                case 6:
                    DisplayMsgBox("登録されていません。")
                case 7:
                    DisplayMsgBox("登録されていません。")
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    DisplayMsgBox("登録されていません。")
                default:
                    DisplayMsgBox("未知のモードで6を押したんやで")
            }
        case 7:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                VolumeDownFunc()
                return
            }
            switch (CtrlNumMode) {

                case 0:
                    CheckDisplayLock()
                    Send "7"
                case 1:
                    DisplayMsgBox("登録されていません。")
                case 2:
                    Run "C:\Users\shuut\xedit184\xedit2.exe"
                case 3:
                    DisplayMsgBox("登録されていません。")
                case 4:
                    DisplayMsgBox("登録されていません。")
                case 5:
                    DisplayMsgBox("登録されていません。")
                case 6:
                    DisplayMsgBox("登録されていません。")
                case 7:
                    DisplayMsgBox("登録されていません。")
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    DisplayMsgBox("登録されていません。")
                default:
                    DisplayMsgBox("未知のモードで7を押したんやで")
            }
        case 8:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                VolumeMuteFunc()
                return
            }
            switch (CtrlNumMode) {

                case 0:
                    CheckDisplayLock()
                    Send "8"
                case 1:
                    Run "C:\Users\shuut\Desktop\shortcut\firefox.exe.lnk"
                case 2:
                    Run "C:\Users\shuut\Desktop\shortcut\vim.exe.lnk"
                case 3:
                    DisplayMsgBox("登録されていません。")
                case 4:
                    DisplayMsgBox("登録されていません。")
                case 5:
                    DisplayMsgBox("登録されていません。")
                case 6:
                    DisplayMsgBox("登録されていません。")
                case 7:
                    DisplayMsgBox("登録されていません。")
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    DisplayMsgBox("登録されていません。")
                default:
                    DisplayMsgBox("未知のモードで8を押したんやで")
            }
        case 9:
            if (NumpadMediaControl) {
                if (NumpadMediaControlAutoChange)
                    NumpadMediaControlFunc(false)
                VolumeUpFunc()
                return
            }
            switch (CtrlNumMode) {

                case 0:
                    CheckDisplayLock()
                    Send "9"
                case 1:
                    DisplayMsgBox("登録されていません。")
                case 2:
                    DisplayMsgBox("登録されていません。")
                case 3:
                    DisplayMsgBox("登録されていません。")
                case 4:
                    DisplayMsgBox("登録されていません。")
                case 5:
                    DisplayMsgBox("登録されていません。")
                case 6:
                    DisplayMsgBox("登録されていません。")
                case 7:
                    DisplayMsgBox("登録されていません。")
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    DisplayMsgBox("登録されていません。")
                default:
                    DisplayMsgBox("未知のモードで9を押したんやで")
            }
        case "Dot":
            switch (CtrlNumMode) {
                case 0:
                    CheckDisplayLock()
                    Send "{.}"
                case 1:
                    Run "C:\Users\shuut\Desktop\shortcut\DuckDuckGo.lnk"
                case 2:
                    DisplayMsgBox("登録されていません。")
                case 3:
                    DisplayMsgBox("登録されていません。")
                case 4:
                    Run "C:\Users\shuut\Desktop\shortcut\Anaconda Prompt.lnk"
                case 5:
                    DisplayMsgBox("登録されていません。")
                case 6:
                    DisplayMsgBox("登録されていません。")
                case 7:
                    DisplayMsgBox("登録されていません。")
                case 8:
                    CheckDisplayLock()
                    return
                case 9:
                    ; ロック
                    WindowsLockFunc()
                default:
                    DisplayMsgBox("未知のモードでドットを押したんやで")
            }
        default:
            return
    }
    PlayButtonSound()
    SetCtrlNumMode()
    return
}

Ctrl8Func(*) {
    global Ctrl8OrLockWindowsFlag, LockFlag
    if (!Ctrl8OrLockWindowsFlag)
        WindowsLockFunc()
    else {
        PlayButtonSound(7, 1)
        LockFlag := false
        SetHotkeyFunc2(false)
        SetHotkeyFunc()
        if GetLoadStreamDeck_AHK_Value()
            TmScriptSwitchControlLock()
        NumpadMediaControlFunc(false, true)
        ; ShowLockScreen()
    }
    return
}