import os
import cv2
import numpy as np

m = "Media"
arr = f"{m}Next-{m}PlayPause-{m}Prev-Editor-Game-Chat-Windows_OpenSetting-dir-void-ShortcutKeyImage".split("-");

#print(arr)

img_list = os.listdir("./")[1:]



for c in arr:
	for img_src in img_list:
		src = f"{c}.png"
		if src == img_src:
			img_list.remove(src)
			break

#print(img_list)

add_wh = 64

base_file_name = "WinSCP"
base_export_file_add_name = "export"

img_list = [[base_file_name, f"{base_file_name}-{base_export_file_add_name}"]];

for img_src2 in img_list:
	img_src = img_src2[0] + ".png"
	img_src_export = img_src2[1] + ".png"
	print(img_src)
	input_img = cv2.imread(img_src, -1)
	height, width = input_img.shape[:2]

	black_img = np.zeros((height + add_wh * 2, width + add_wh * 2, 4), dtype=np.uint8)
	black_img[:, :, :3] = 255
	black_img[:, :, 3] = 0

	black_img[add_wh:-add_wh, add_wh:-add_wh] = input_img

	end_img = black_img
	save_img_src = img_src_export
	cv2.imwrite(save_img_src, end_img)