﻿#Requires AutoHotkey v2

#SingleInstance Force

#Include %A_ScriptDir%\..
#Include Lib/JXON.ahk

SetWorkingDir(A_ScriptDir "/../src")

; CoordMode "Mouse", "Screen"
CoordMode "ToolTip", "Screen"

#Include ./ahkv2/utils/utils-functions-v2.ahk

; 以下からコードを記述
/*

global test_str := "ABCDEFG"
global a := "AB2"
global b := "HIJ"

test_str := StrReplace(test_str, a, b)

DisplayMsgBox(test_str, true)

global test_map := Map("x", 10)

test_map.Set("x", test_map.Get("x") + 1)

DisplayMsgBox(test_map.Get("x"), true)

*/

void_func() {
    return
}

global atoz_array := ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]

for key in atoz_array {
    Hotkey(key, (*) => void_func())
}

Enter::
{
    ExitApp()
    return
}