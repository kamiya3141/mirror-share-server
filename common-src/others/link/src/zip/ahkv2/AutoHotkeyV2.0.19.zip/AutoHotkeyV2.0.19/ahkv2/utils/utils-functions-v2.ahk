/*
汎用
*/

gsp(input_number := 1) {
    return input_number == 1 ? " " : "　"
}

i2bs(_bool := false, _ts := "true", _fs := "false") {
    local data_arr := []
    local ret_val := ""
    if HasProp(_bool, "Length") {
        for _val in _bool
            data_arr.Push((_val ? _ts : _fs))
        ret_val := data_arr.Clone()
    } else
        ret_val := (_bool ? _ts : _fs)

    return ret_val
}

StrRepeat(input_str := "", repeat_count := 1) {
    local ret_str := ""
    loop repeat_count
        ret_str .= input_str
    return ret_str
}
StrJoin(input_arr := [], split_str := ", ") {
    local ret_str := ""
    for v in input_arr
        ret_str .= v . split_str
    return ret_str
}
StrLenInArray(input_arr := []) {
    input_arr := input_arr.Clone()
    for i, v in input_arr
        input_arr[i] := StrLen(String(v))
    return input_arr.Length < 1 ? 0 : Max(input_arr*)
}

ArrayEmpty(input_arr := []) {
    return (IsObject(input_arr) && input_arr.Length < 1)
}
ArrayInclude(input_arr := [], input_obj := "") {
    if (input_arr.Length > 0) {
        for idx, val in input_arr {
            if (val == input_obj)
                return true
        }
    }
    return false
}
ArraySearch(input_arr := [], input_obj := "") {
    if (input_arr.Length > 0) {
        for idx, val in input_arr {
            if (val == input_obj)
                return idx
        }
    }
    return -1
}
ArraySearchHit(input_arr := [], input_obj := "", only_idx := false) {
    local l_arr := []
    if (input_arr.Length > 0) {
        for idx, val in input_arr {
            if (val == input_obj)
                l_arr.Push(only_idx ? idx : val)
        }
    }
    return l_arr
}
MapSearchHitKey(input_map := [], input_obj := "", return_key := true) {
    local l_arr := []
    for key_name, val in input_map {
        if (key_name == input_obj)
            l_arr.Push(return_key ? key_name : val)
    }
    return l_arr
}
MapSearchHitValue(input_map := [], input_obj := "", return_key := true) {
    local l_arr := []
    for key_name, val in input_map {
        if (val == input_obj)
            l_arr.Push(return_key ? key_name : val)
    }
    return l_arr
}
MapIncludeHitKey(input_map := [], input_obj := "", include_number := 0, return_key := true) {
    local l_arr := []
    for key_name, val in input_map {
        if (include_number ? InStr(key_name, input_obj) == include_number : InStr(key_name, input_obj))
            l_arr.Push(return_key ? key_name : val)
    }
    return l_arr
}
MapIncludeHitValue(input_map := [], input_obj := "", include_number := 0, return_key := true) {
    local l_arr := []
    for key_name, val in input_map {
        if (include_number ? InStr(val, input_obj) == include_number : InStr(val, input_obj))
            l_arr.Push(return_key ? key_name : val)
    }
    return l_arr
}

/*
特殊
*/

SetVolume(Val) {
    global CurrentVolume
    SoundSetVolume(Val)
    CurrentVolume := GetVolume()
    return
}

GetVolume(*) {
    Val := SoundGetVolume()
    return Val
}

SoundPlayFunc(_filename := "common\\button\\1\\1.mp3", _alias := "") {
    _filename := A_WorkingDir "\" _filename
    if !FileExist(_filename) {
        DisplayMsgBox(_filename " isn't exist !!")
    } else {
        _alias := "my_alias" _alias A_TickCount
        DllCall("winmm\mciSendStringW", "Str", "close " _alias, "Ptr", 0, "UInt", 0, "UInt", 0)
        DllCall("winmm\mciSendStringW", "Str", "open `"" _filename "`" alias " _alias, "Ptr", 0, "UInt", 0, "UInt", 0)
        DllCall("winmm\mciSendStringW", "Str", "play " _alias, "Ptr", 0, "UInt", 0, "UInt", 0)
    }
    return
}

DisplayToolTip(Pass, SleepTime := 250) {
    global HalfScreenW, HalfScreenH
    ToolTip(AddSurroundDecoration(Pass, true), 1920 / 2, 1080)
    SetTimer(RemoveToolTip, -SleepTime)
}
RemoveToolTip(*) {
    ToolTip()
}

AddSurroundDecoration(arg := [""], return_joined_str :=
    false, deco_char := "●", insert_space_count := 1, deco_char_count := 1) {
    insert_space_count := insert_space_count < 0 ? 0 : insert_space_count
    deco_char_count := deco_char_count < 0 ? 0 : deco_char_count
    local output_data := IsObject(arg) ? arg.Clone() : [arg]
    local len_max := StrLenInArray(output_data)
    local head_bottom_block := StrRepeat(deco_char, len_max)

    loop insert_space_count
        output_data.InsertAt(1, gsp())
    loop insert_space_count
        output_data.Push(gsp())
    loop deco_char_count
        output_data.InsertAt(1, head_bottom_block)
    loop deco_char_count
        output_data.Push(head_bottom_block)

    return return_joined_str ? StrJoin(output_data, "`n") : output_data
}
DisplayMsgBox(arg := "", decoration_flag := false, use_for_flag := false) {
    local output_data := IsObject(arg) ? arg.Clone() : [arg]
    if use_for_flag {
        for v in output_data
            MsgBox decoration_flag ? AddSurroundDecoration(v, true) : v
    } else
        MsgBox StrJoin(decoration_flag ? AddSurroundDecoration(output_data, false) : output_data, "`n")
    return
}

ExecFile(_filepath := "") {
    if (_filepath != "")
        Run A_ScriptDir "/" _filepath
    return
}

SleepSend(_time := 250, args*) {
    for arg in args {
        Send arg
        Sleep _time
    }
    return
}

WindowsLockFunc(*) {
    SetVolume(0)
    DllCall("LockWorkStation")
    return
}

____GetDumpObj_IN____(obj, indentSize := 1, useTab := true, re_count := 0) {

    if re_count < 0
        re_count := 0

    local str := ""
    local prefix := StrRepeat((useTab ? "`t" : gsp()), re_count * indentSize)

    for key, value in obj {
        if IsObject(value)
            str .= prefix key ":`n" ____GetDumpObj_IN____(value, indentSize, useTab, re_count + 1)
        else
            str .= prefix key ": " value "`n"
    }

    return str
}

GetDumpObj(obj, indentSize := 1, useTab := true) {
    return ____GetDumpObj_IN____(obj, indentSize, useTab, 0)
}