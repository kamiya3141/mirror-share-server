﻿;MediaControl ON / OFF
NumLock:: {
    CtrlNFunc(0, "", false)
    if CheckDisplayLock() != -1
        NumpadMediaControlFunc()
    return
}

+NumLock:: {
    NumpadMediaControlAutoChangeFunc()
    return
}

/*
####################################################################
Numpadと^Numberの設定
####################################################################
*/

Process_CtrlN_Numpad_setFunc(function_name := "", function_args := []) {
    if !IsObject(function_args)
        DisplayMsgBox(["Error: Process_CtrlN_Numpad_setHotkey", "第二引数が配列（オブジェクト）以外で渡されました"], true)
    return (*) => %function_name%(function_args*)
}
CtrlN_Numpad_setFunc() {
    global MainShortCutKeys
    for i, i_v in MainShortCutKeys
        for j, j_v in i_v["keys"]
            Hotkey(i_v["modifier"] . i_v["basename"] . j_v[1], Process_CtrlN_Numpad_setFunc(i_v["function"], j_v[2]))
    return
}

; ####################################################################
; 一般設定
; ####################################################################

Insert:: {
    global GameMode, MINECRAFT
    if CheckDisplayLock() == -1
        return
    if (GameMode) {
        MINECRAFT["TF"] := !MINECRAFT["TF"]
        DisplayToolTip("Minecraft.TF " . (MINECRAFT["TF"] ? "true" : "false"))
    } else {
        DisplayNowDays()
    }
    return
}

/*
############################################################################################################################################################################################################
XButton
############################################################################################################################################################################################################
*/
; 手前側
XButton1:: {
    AddKeyBoardEditStackCommand(, false)
    if (!EditProgrammingMode(, true))
        ; change
        Send "{End}"
    else
        Send "^d"
    return
}
; 奥側
XButton2:: {
    AddKeyBoardEditStackCommand(, false)
    if (!EditProgrammingMode(, true))
        ; change
        Send "{Home}"
    else
        Send "^y"
    return
}
+XButton1:: {
    AddKeyBoardEditStackCommand(, false)
    Send "+{End}"
    return
}
+XButton2:: {
    AddKeyBoardEditStackCommand(, false)
    Send "+{Home}"
    return
}
^XButton1:: {
    AddKeyBoardEditStackCommand(, false)
    Send "{End}"
    return
}
^XButton2:: {
    AddKeyBoardEditStackCommand(, false)
    Send "{Home}"
    return
}

XButton1 & LButton:: {
    global GameMode
    if (!GameMode) {
        if (!EditProgrammingMode(, true)) {
            MediaPrevFunc()
        } else {
            Send("^c")
        }
    } else {
        Send("{LButton down}")
    }
    return
}

XButton1 & RButton:: {
    global GameMode
    if (!GameMode) {
        if (!EditProgrammingMode(, true)) {
            MediaNextFunc()
        } else {
            Send("^v")
        }
    } else {
        Send("{RButton down}")
    }
    return
}

; minecraft用
XButton1 & LButton Up:: {
    global GameMode
    if (GameMode) {
        Send("{LButton up}")
    }
    return
}
XButton1 & RButton Up:: {
    global GameMode
    if (GameMode)
        Send("{RButton up}")
    return
}
XButton1 & MButton:: {
    global GameMode
    if (!GameMode) {
        if (!EditProgrammingMode(, true)) {
            MediaPlayPauseFunc()
        } else
            Send("^x")
    } else
        Send("{MButton}")
    return
}
XButton1 & WheelUp:: {
    global GameMode
    if (!GameMode) {
        if (!EditProgrammingMode(, true))
            VolumeUpFunc()
        else
            Send("^a")
    } else
        Send("{WheelUp}")
    return
}
XButton1 & WheelDown:: {
    global GameMode
    if (!GameMode) {
        if (!EditProgrammingMode(, true))
            VolumeDownFunc()
        else
            WindowTabFunc()
    } else
        Send("{WheelDown}")
    return
}
XButton2 & LButton:: {
    global GameMode
    if (!GameMode)
        SwitchDesktop(1)
    else
        Send("{LButton down}")
    return
}
XButton2 & RButton:: {
    global GameMode
    if (!GameMode)
        SwitchDesktop(2)
    else
        Send("{RButton Down}")
    return
}

; minecraft用
XButton2 & LButton Up:: {
    global GameMode
    if (GameMode)
        Send("{LButton Up}")
    return
}
XButton2 & RButton Up:: {
    global GameMode
    if (GameMode)
        Send("{RButton Up}")
    return
}
MButton & RButton:: {
    global GameMode
    if (CheckDisplayLock() == -1)
        return
    if (!GameMode)
        SwitchDesktop(0)
    else
        Send("{MButton}{RButton}")
    return
}

XButton2 & WheelUp:: {
    SendInput("{WheelRight 5}")
    return
}
XButton2 & WheelDown:: {
    SendInput("{WheelLeft 5}")
    return
}

XButton2 & MButton:: {
    if (CheckDisplayLock() != -1)
        SwitchProgrammingModeFunc()
    return
}

/*
############################################################################################################################################################################################################
AppsKey
############################################################################################################################################################################################################
*/

!AppsKey:: {
    SwitchGameModeFunc()
    return
}
^AppsKey:: {
    if (CheckDisplayLock() != -1 && GetLoadStreamDeck_AHK_Value())
        TmScriptChangeWHBaseSCTWindowFunc()
    return
}
+AppsKey:: {
    if (CheckDisplayLock() != -1)
        SwitchProgrammingModeFunc()
    return
}

^!AppsKey:: {
    if (CheckDisplayLock() != -1)
        SwitchKeySoundModeFunc()
    return
}

/*
############################################################################################################################################################################################################
変換, 無変換キー など
############################################################################################################################################################################################################
*/

; 無変換
sc07B:: {
    AddKeyBoardEditStackCommand(, false)
    return
}
; 変換
sc079:: {
    AddKeyBoardEditStackCommand(, false)
    if (CheckDisplayLock() != -1)
        Send "{Backspace}"
    return
}

; カタカナ/ひらがな
sc070:: {
    AddKeyBoardEditStackCommand(, false)
    if (CheckDisplayLock() != -1)
        AddEnter(, 10)
    return
}
; 全角/半角
sc029:: {
    AddKeyBoardEditStackCommand(, false)
    MediaPlayPauseFunc()
    return
}
; sc079（変換キー）
sc079 & l::
{
    Send "ssh tamura@localhost -p 22"
    return
}
; script reload 用
sc079 & r::
{
    ReloadThisScript()
    return
}
; workspace単体を開く用
sc079 & s::
{
    ExecFile "ahkv2.code-workspace"
    return
}
; test.ahk起動
sc079 & t::
{
    ExecFile "utils/test.ahk"
    return
}
; history.ahk起動
sc079 & h::
{
    ExecFile "history.ahk"
    return
}

; sc07B（無変換キー）
sc07B & e::
{
    ExitApp()
    return
}
; 移動
sc07B & w::
{
    Send "{Up}"
    return
}
sc07B & s::
{
    Send "{Down}"
    return
}
sc07B & a::
{
    Send "{Left}"
    return
}
sc07B & d::
{
    Send "{Right}"
    return
}