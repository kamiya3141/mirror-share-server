global UtilsVis_Var_WindowArray := []

UtilsVis_Func_GetWindowArray(idx := 0) {
    global UtilsVis_Var_WindowArray
    if (idx > 0 && idx <= UtilsVis_Var_WindowArray.Length)
        return UtilsVis_Var_WindowArray[idx]
    else
        DisplayMsgBox("第二引数のインデックスが範囲外に指定されました")
    return 0
}