﻿#Requires AutoHotkey v2

#SingleInstance Force

global TmScriptLocalFlag := False
global TmScriptSoundsArray := [2, 6, 4, 5, 8]

if (InStr(A_WorkingDir, "streamDeck")) {
    TmScriptLocalFlag := True
    #Include ./../../../../Lib/JXON.ahk
    SetWorkingDir(A_ScriptDir "\..\..\..")
}

global TmScriptBaseWorkingDir := (InStr(A_WorkingDir, "streamDeck") ? "" : "./streamDeck/")
global JsonUrl := TmScriptBaseWorkingDir "json/data.json"
JsonText := FileRead(JsonUrl)
global TmScriptJsonData := JXON_Load(&JsonText)

global TmScriptCL := TmScriptJsonData["cl"]
global TmScriptLN := TmScriptJsonData["ln"]

global TmScriptButtons := TmScriptJsonData["data"]["buttons"]
global TmScriptPages := TmScriptJsonData["data"]["pages"]
global TmScriptIndex := 1

global TmScriptScreenWidthOrg := 1920
global TmScriptScreenHeightOrg := 1080

global TmScriptSCTWindowChangeWH := False

global TmScriptScreenWidth := (!TmScriptSCTWindowChangeWH ? TmScriptScreenWidthOrg : TmScriptScreenHeightOrg)
global TmScriptScreenHeight := (TmScriptSCTWindowChangeWH ? TmScriptScreenWidthOrg : TmScriptScreenHeightOrg)

global TmScriptScreenX := TmScriptScreenWidthOrg * 0 + TmScriptScreenWidth * 0 - 5
global TmScriptScreenY := TmScriptScreenHeightOrg * 0 + TmScriptScreenHeight * 0 + 5

global TmScriptNameVArray := []

global TmScriptIconW := TmScriptScreenWidth / TmScriptCL
global TmScriptIconH := TmScriptScreenHeight / TmScriptLN

global TmScriptNowPageData := 0

global TmScriptMainGui := Gui()

global TmScriptBaseVName := "StreamDeck"
global TmScriptBasePictureName := "Picture"
global TmScriptBaseTextName := "Text"

global TmScriptMouseX := 0
global TmScriptMouseY := 0
global TmScriptMousePX := 0
global TmScriptMousePY := 0

global TmScriptMouseFlag := 2

global TmScriptDisplayFlag := False
global TmScriptClickAllow := True
global TmScriptSCTWindowChangeWH := True
global TmScriptClickLabelSound := True

global TmScriptSavePreURL := ""
global TmScriptSaveURLArray := []

global TmScriptControlLockFlag := True

global TmScriptClickSoundFixedFlag := False

SetSCTWindowInfo() {
    global TmScriptCL
    global TmScriptLN
    global TmScriptJsonData
    global TmScriptSCTWindowChangeWH
    global TmScriptScreenWidthOrg
    global TmScriptScreenHeightOrg
    global TmScriptScreenWidth
    global TmScriptScreenHeight
    global TmScriptIconW
    global TmScriptIconH
    global TmScriptNowPageData

    TmScriptCL := TmScriptJsonData[(!TmScriptSCTWindowChangeWH ? "cl" : "ln")]
    TmScriptLN := TmScriptJsonData[(TmScriptSCTWindowChangeWH ? "cl" : "ln")]
    TmScriptScreenWidth := (!TmScriptSCTWindowChangeWH ? TmScriptScreenWidthOrg : TmScriptScreenHeightOrg)
    TmScriptScreenHeight := (TmScriptSCTWindowChangeWH ? TmScriptScreenWidthOrg : TmScriptScreenHeightOrg)

    TmScriptIconW := TmScriptScreenWidth / TmScriptCL
    TmScriptIconH := TmScriptScreenHeight / TmScriptLN

    TmScriptNowPageData := 0
    return
}

AddVoidFunction(n, attr) {
    global TmScriptNowPageData
    global TmScriptCL
    global TmScriptLN

    max_data_length := (TmScriptCL * TmScriptLN)
    loop (n) {
        TmScriptNowPageData.Push(Map("ID", "void", "od", Map("icon", "")))
    }
    switch (attr) {
        case "d":
            if (TmScriptNowPageData[1]["ID"] != "dir_u") {
                TmScriptNowPageData.Pop()
                TmScriptNowPageData.InsertAt(1, Map("ID", "dir_u", "od", Map("icon", "")))
            }
        case "pr":
            TmScriptNowPageData[max_data_length] := Map("ID", "page_r", "od", Map("icon", ""))
            ; pageの移動ボタン左
        case "pl":
            idx := max_data_length - TmScriptCL + 1
            TmScriptNowPageData[idx] := Map("ID", "page_l", "od", Map("icon", ""))

            ; pageの移動ボタン両方
        case "pb":
            idx := max_data_length - TmScriptCL + 1
            TmScriptNowPageData[idx] := Map("ID", "page_l", "od", Map("icon", ""))
            TmScriptNowPageData[max_data_length] := Map("ID", "page_r", "od", Map("icon", ""))

        Default:

    }
    return
}

TmScriptLoadNewAllButtons(url) {
    global TmScriptSavePreURL
    global TmScriptCL
    global TmScriptLN
    global TmScriptNowPageData
    global TmScriptBaseVName
    global TmScriptBasePictureName
    global TmScriptButtons
    global TmScriptBaseTextName
    global TmScriptMainGui

    TmScriptSavePreURL := url
    local StartPageFileData := FileRead(TmScriptBaseWorkingDir "json\" url ".json")
    local NowPageDataOrg := JXON_Load(&StartPageFileData)
    TmScriptNowPageData := NowPageDataOrg["page"]
    local VarMinusLength := (TmScriptCL * TmScriptLN) - TmScriptNowPageData.Length
    if (VarMinusLength > 0) {
        AddVoidFunction(VarMinusLength, NowPageDataOrg["attr"])
    }
    for Index, Btn in TmScriptNowPageData {
        local VarMyV := TmScriptBaseVName Index
        local VarMyPictureV := VarMyV TmScriptBasePictureName
        local VarMyTextV := VarMyV TmScriptBaseTextName

        local VarMyName := Btn["ID"]
        if (!Btn.Has("od")) {
            Btn.Set("od", Map("icon", ""))
        }
        if (!Btn["od"].Has("icon")) {
            Btn["od"].Set("icon", "")
        }
        local VarMyIcon := (TmScriptButtons[VarMyName]["icon"] != "" ? TmScriptButtons[VarMyName]["icon"] :
            "png/void0.png")
        local VarMyUrl := "\" (Btn["od"]["icon"] != "" ? Btn["od"]["icon"] : VarMyIcon)

        local CtrlPicture := TmScriptMainGui[VarMyPictureV]
        if (IsObject(CtrlPicture))
            CtrlPicture.Value := TmScriptBaseWorkingDir VarMyUrl
        local VarMyTxt := (VarMyName == "dir" ? Btn["od"]["text"] : TmScriptButtons[VarMyName]["text"])
        local CtrlText := TmScriptMainGui[VarMyTextV]
        if (IsObject(CtrlText))
            CtrlText.Value := VarMyTxt
    }
    return
}
LogMousePos() {
    global TmScriptMouseFlag
    global TmScriptMouseX, TmScriptMouseY
    global TmScriptMousePX, TmScriptMousePY
    global TmScriptScreenX, TmScriptScreenY
    global TmScriptScreenWidth, TmScriptScreenHeight

    if (TmScriptMouseFlag = 2) {
        MouseGetPos(&TmScriptMouseX, &TmScriptMouseY, , , 1)

        if (
            (TmScriptMouseX != TmScriptMousePX || TmScriptMouseY != TmScriptMousePY)
            && !(
                TmScriptMouseX > TmScriptScreenX
                && TmScriptMouseX < (TmScriptScreenX + TmScriptScreenWidth)
                && TmScriptMouseY > TmScriptScreenY
                && TmScriptMouseY < (TmScriptScreenY + TmScriptScreenHeight)
            )
        ) {
            TmScriptMousePX := TmScriptMouseX
            TmScriptMousePY := TmScriptMouseY
            ; DisplayToolTip(TmScriptMousePX " : " TmScriptMousePY)
        }
    }
}
SetMouseFlag() {
    global TmScriptMouseFlag

    if (TmScriptMouseFlag = 1)
        TmScriptMouseFlag := 2
}

TmScriptExecCmdsFunc(url0, type0) {
    global TmScriptPages, TmScriptIndex
    global TmScriptSavePreURL
    global TmScriptSaveURLArray

    TmScriptPlayButtonFunc(6, "true")
    local allArr := []
    if (type0 = "mix" && url0.__Class = "Array")
        allArr := url0
    else
        allArr.Push([type0, url0])
    for Ch in allArr {
        local type := Ch[1]
        local url := Ch[2]
        local lasturl := StrSplit(url, "-:-")
        if (type = "rs") {
            local r_last_url_element := TmScriptRegExReplaceAllEnvVars(lasturl.RemoveAt(1))
            local r_last_url_element_last3str := SubStr(r_last_url_element, -3)
            if (r_last_url_element_last3str = "exe" && WinExist("ahk_exe " r_last_url_element)) {
                WinActivate
            } else {
                Run(r_last_url_element)
            }
            type := "s"
            Sleep 2000
        } else if (type = "sr") {
            s_last_url_element := lasturl.RemoveAt(1)
            Send(s_last_url_element)
            type := "r"
            Sleep 2000
        }
        for Idx, Value in lasturl {
            Value := TmScriptRegExReplaceAllEnvVars(Value)
            if (type = "s") {
                Send(Value)
            } else if (type = "gs") {
                %Value%()
            } else if (type = "r") {
                Run(Value)
            }

            if (lasturl.Length > 0)
                Sleep 1000
        }
    }
    local change_url := "page\" TmScriptPages[TmScriptIndex]
    if (TmScriptSavePreURL != change_url) {
        TmScriptSaveURLArray := [] ; 空の配列を初期化
        TmScriptSaveURLArray.Push(change_url)
        TmScriptLoadNewAllButtons(TmScriptSaveURLArray[-1])
    }
    return
}

SwitchClickLabelSound() {
    global TmScriptClickLabelSound

    TmScriptClickLabelSound := !TmScriptClickLabelSound
    TmScriptPlayButtonFunc(6, (TmScriptClickLabelSound ? "true" : "false"))
}

ClickedFunc(ctrl, *) {
    global TmScriptMouseFlag, TmScriptMousePX, TmScriptMousePY
    global TmScriptBaseVName, TmScriptBasePictureName
    global TmScriptNowPageData, TmScriptButtons
    global TmScriptClickAllow, TmScriptClickLabelSound
    global TmScriptIndex, TmScriptPages
    global TmScriptSaveURLArray
    global TmScriptControlLockFlag

    TmScriptMouseFlag := 0

    if (TmScriptControlLockFlag) {
        ; A_GuiControlを正規表現で分解
        if RegExMatch(ctrl.Name, TmScriptBaseVName "(.+)" TmScriptBasePictureName, &a_gui_control) {
            a_gui_control1 := a_gui_control[1]

            if (a_gui_control1 != "") {
                me := TmScriptNowPageData[a_gui_control1 + 0]
                org := TmScriptButtons[me["ID"]]
                url := org["cmd"]
                str := org["cmdType"]
                if (TmScriptClickAllow)
                    MouseMove(TmScriptMousePX, TmScriptMousePY)
                switch str {
                    case "r", "gs", "rs", "mix":
                        TmScriptExecCmdsFunc(url, str)
                    case "s", "sr":
                        if (TmScriptClickAllow)
                            Click(TmScriptMousePX, TmScriptMousePY)
                        TmScriptExecCmdsFunc(url, str)
                    case "pgr":
                        if (TmScriptClickLabelSound)
                            TmScriptPlayButtonFunc(6, "move")
                        TmScriptIndex += 1
                        TmScriptLoadNewAllButtons("page\" TmScriptPages[TmScriptIndex])
                    case "pgl":
                        if (TmScriptClickLabelSound)
                            TmScriptPlayButtonFunc(6, "move")
                        TmScriptIndex -= 1
                        TmScriptLoadNewAllButtons("page\" TmScriptPages[TmScriptIndex])
                    case "dir":
                        if (TmScriptClickLabelSound)
                            TmScriptPlayButtonFunc(6, "open")
                        TmScriptSaveURLArray.Push(me["od"]["url"])
                        TmScriptLoadNewAllButtons(TmScriptSaveURLArray[-1])
                    case "dru":
                        if (TmScriptClickLabelSound)
                            TmScriptPlayButtonFunc(6, "close")
                        TmScriptSaveURLArray.Pop()
                        TmScriptLoadNewAllButtons(TmScriptSaveURLArray[-1])
                    case "void":
                        if (TmScriptClickAllow)
                            MouseMove(TmScriptMousePX, TmScriptMousePY)
                }
            }
        }

        TmScriptMouseFlag := 1
        SetTimer(SetMouseFlag, -2000)
    }
}

CreateSCTWindow(*) {
    global TmScriptDisplayFlag, TmScriptMainGui
    global TmScriptPages, TmScriptIndex, TmScriptNowPageData
    global TmScriptCL, TmScriptLN, TmScriptIconW, TmScriptIconH
    global TmScriptBaseVName, TmScriptBasePictureName, TmScriptBaseTextName
    global TmScriptButtons, TmScriptSavePreURL
    global TmScriptScreenX, TmScriptScreenY, TmScriptScreenWidth, TmScriptScreenHeight

    TmScriptDisplayFlag := !TmScriptDisplayFlag
    TmScriptMainGui.Destroy()

    if !TmScriptDisplayFlag
        return

    TmScriptMainGui := Gui("+AlwaysOnTop +Resize +ToolWindow -SysMenu +OwnDialogs -Caption")
    TmScriptMainGui.BackColor := "White"
    TmScriptMainGui.SetFont("s20", "Arial")

    TmScriptSavePreURL := "page\" TmScriptPages[TmScriptIndex]
    LocalStartPageFileData := FileRead(TmScriptBaseWorkingDir "json\" TmScriptSavePreURL ".json")
    LocalNowPageDataOrg := JXON_Load(&LocalStartPageFileData)
    TmScriptNowPageData := LocalNowPageDataOrg["page"]

    local VarMinusLength := (TmScriptCL * TmScriptLN) - TmScriptNowPageData.Length
    if (VarMinusLength > 0)
        AddVoidFunction(VarMinusLength, LocalNowPageDataOrg["attr"])

    for Index, Btn in TmScriptNowPageData {
        BtnX := Mod(Index - 1, TmScriptCL) * TmScriptIconW
        BtnY := Floor((Index - 1) / TmScriptCL) * TmScriptIconH

        local VarMyV := TmScriptBaseVName Index
        local VarPictureV := VarMyV TmScriptBasePictureName
        local VarTextV := VarMyV TmScriptBaseTextName
        local VarMyName := Btn["ID"]
        if (!Btn.Has("od")) {
            Btn.Set("od", Map("icon", ""))
        }
        if (!Btn["od"].Has("icon")) {
            Btn["od"].Set("icon", "")
        }
        local VarMyIcon := (TmScriptButtons[VarMyName]["icon"] != "" ? TmScriptButtons[VarMyName]["icon"] :
            "png/void0.png")
        local VarPicUrl := TmScriptBaseWorkingDir (Btn["od"]["icon"] != "" ? Btn["od"]["icon"] : VarMyIcon)
        local VarMyTxt := (VarMyName == "dir" ? Btn["od"]["text"] : TmScriptButtons[VarMyName]["text"])
        local VarMyTxtX := BtnX
        local VarMyTxtY := BtnY + TmScriptIconH * 17 / 20
        local VarMyTxtH := 32

        ; Pictureコントロール追加
        local VarPictureCtrl := TmScriptMainGui.Add("Picture", "x" BtnX " y" BtnY " w" TmScriptIconW " h" TmScriptIconH " v" VarPictureV,
            VarPicUrl)
        VarPictureCtrl.OnEvent("Click", ClickedFunc)

        ; Textコントロール追加
        local VarTextCtrl := TmScriptMainGui.Add("Text", "x" VarMyTxtX " y" VarMyTxtY " w" TmScriptIconW " h" VarMyTxtH " v" VarTextV " BackgroundTrans Center",
            VarMyTxt)

    }

    ; 表示
    TmScriptMainGui.Show("x" TmScriptScreenX " y" TmScriptScreenY " w" TmScriptScreenWidth " h" TmScriptScreenHeight " NoActivate"
    )

    ; アクティブに
    WinActivate("ahk_class AutoHotkeyGUI")

    ; タイマー
    SetTimer(LogMousePos, 40)
    SetTimer(TmScriptFirstCreatedExecFunc, -10)
}

TmScriptFirstCreatedExecFunc() {
    global TmScriptSaveURLArray, TmScriptSavePreURL

    TmScriptSaveURLArray := []
    TmScriptSaveURLArray.Push(TmScriptSavePreURL)
    TmScriptLoadNewAllButtons(TmScriptSaveURLArray[TmScriptSaveURLArray.Length])
}

TmScriptSwitchControlLock() {
    global TmScriptControlLockFlag

    TmScriptControlLockFlag := !TmScriptControlLockFlag
    return
}

TmScriptPlayButtonFunc(Idx, Idx2) {
    global TmScriptSoundsArray, TmScriptClickSoundFixedFlag
    if (TmScriptClickSoundFixedFlag) {
        Idx := 1
        Idx2 := "r"
    }
    if (Idx2 == "r") {
        if (Idx < 1 || Idx > TmScriptSoundsArray.Length)
            Idx := 1
        Idx2 := Random(1, TmScriptSoundsArray[Idx])
    }

    local FileName := "common\\button\\" Idx "\\" Idx2 ".mp3"
    local Alias := "btn" Idx Idx2 A_TickCount

    if !FileExist(FileName) {
        MsgBox(FileName)
        return
    }

    DllCall("winmm\mciSendStringW", "Str", "close " Alias, "Ptr", 0, "UInt", 0, "UInt", 0)
    DllCall("winmm\mciSendStringW", "Str", "open `"" FileName "`" alias " Alias, "Ptr", 0, "UInt", 0, "UInt", 0)
    DllCall("winmm\mciSendStringW", "Str", "play " Alias, "Ptr", 0, "UInt", 0, "UInt", 0)
    return
}

TmScriptRegExReplaceAllEnvVars(Val) {
    local strPos := 1
    while RegExMatch(Val, "%(.*?)%", &obj, strPos) {
        local result := EnvGet(obj[1]) != "" ? EnvGet(obj[1]) : obj[0]
        strPos := obj.Pos + StrLen(result)
        Val := RegExReplace(Val, obj[0], result)
    }
    return Val
}

TmScriptReturnSCTWindowFunc() {
    global TmScriptDisplayFlag

    if (TmScriptDisplayFlag) {
        TmScriptDisplayFlag := False
        SetTimer(CreateSCTWindow, -100)
    }
    return
}

TmScriptChangeWHBaseSCTWindowFunc() {
    global TmScriptSCTWindowChangeWH
    SetSCTWindowInfo()
    TmScriptSCTWindowChangeWH := !TmScriptSCTWindowChangeWH
    ToolTip("現在の追加ウィンドウの\n横幅は" (TmScriptSCTWindowChangeWH ? "Width" : "Height") "Org です")
    Sleep 250
    ToolTip()
    return
}

TmScriptMoveStreamDeckDisplay(XY, add) {
    global TmScriptControlLockFlag, TmScriptDisplayFlag

    if (!TmScriptControlLockFlag) {
        return
    }
    TmScriptPlayButtonFunc(5, "r")
    local _TF := False
    if (TmScriptDisplayFlag) {
        CreateSCTWindow()
        _TF := !_TF
    }
    XY := XY + add
    if (_TF) {
        CreateSCTWindow()
    }
    return XY
}

AppsKey:: {
    global TmScriptControlLockFlag

    if (!TmScriptControlLockFlag) {
        return
    }
    CreateSCTWindow()
}

^Up:: {
    global TmScriptScreenY
    TmScriptScreenY := TmScriptMoveStreamDeckDisplay(TmScriptScreenY, -TmScriptScreenHeightOrg)
}

^Down:: {
    global TmScriptScreenY
    TmScriptScreenY := TmScriptMoveStreamDeckDisplay(TmScriptScreenY, TmScriptScreenHeightOrg)
}

^Left:: {
    global TmScriptScreenX
    TmScriptScreenX := TmScriptMoveStreamDeckDisplay(TmScriptScreenX, -TmScriptScreenWidthOrg)
}

^Right:: {
    global TmScriptScreenX
    TmScriptScreenX := TmScriptMoveStreamDeckDisplay(TmScriptScreenX, TmScriptScreenWidthOrg)
}