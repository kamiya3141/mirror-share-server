﻿global JsonUrl := "streamDeck\json\data.json"
FileRead, filedata, %JsonUrl%
global JsonData := JSON.Load(filedata)

global TmScriptCL := JsonData["cl"]
global TmScriptLN := JsonData["ln"]

global TmScriptButtons := JsonData["data"]["buttons"]
global TmScriptPages := JsonData["data"]["pages"]
global TmScriptIndex := 1

global TmScriptScreenWidthOrg := 1920
global TmScriptScreenHeightOrg := 1080

global TmScriptSCTWindowChangeWH := False

global TmScriptScreenWidth := (!TmScriptSCTWindowChangeWH ? TmScriptScreenWidthOrg : TmScriptScreenHeightOrg)
global TmScriptScreenHeight := (TmScriptSCTWindowChangeWH ? TmScriptScreenWidthOrg : TmScriptScreenHeightOrg)

global TmScriptScreenX := TmScriptScreenWidthOrg * 0 + TmScriptScreenWidth * 0 - 5
global TmScriptScreenY := TmScriptScreenHeightOrg * 0 + TmScriptScreenHeight * 0 + 5

global TmScriptNameVArray := []

global IconW := TmScriptScreenWidth / TmScriptCL
global IconH := TmScriptScreenHeight / TmScriptLN

global TmScriptNowPageData := 0

global TmScriptBaseVName := "StreamDeck"
global TmScriptBasePictureName := "Picture"
global TmScriptBaseTextName := "Text"

global TmScriptMouseX := 0
global TmScriptMouseY := 0
global TmScriptMousePX := 0
global TmScriptMousePY := 0

global TmScriptMouseFlag := 2

global TmScriptDisplayFlag := False
global TmScriptClickAllow := True
global TmScriptSCTWindowChangeWH := True
global TmScriptClickLabelSound := True

global TmScriptSavePreURL := ""
global TmScriptSaveURLArray := []

SetSCTWindowInfo() {
    TmScriptCL := JsonData[(!TmScriptSCTWindowChangeWH ? "cl" : "ln")]
    TmScriptLN := JsonData[(TmScriptSCTWindowChangeWH ? "cl" : "ln")]
    TmScriptScreenWidth := (!TmScriptSCTWindowChangeWH ? TmScriptScreenWidthOrg : TmScriptScreenHeightOrg)
    TmScriptScreenHeight := (TmScriptSCTWindowChangeWH ? TmScriptScreenWidthOrg : TmScriptScreenHeightOrg)

    IconW := TmScriptScreenWidth / TmScriptCL
    IconH := TmScriptScreenHeight / TmScriptLN

    TmScriptNowPageData := 0
    Return
}

AddVoidFunction(ByRef Arr, n, attr) {
    max_data_length := (TmScriptCL * TmScriptLN)
    Loop, %n% {
        Arr.Push({ID: "void", od: ""})
    }
    Switch (attr) {
        ; pageの移動ボタン右
        Case "d":{
            If (Arr[1]["ID"] != "dir_u") {
                Arr.Remove()
                Arr.Insert(1, {ID: "dir_u", od: ""})
            }
        }
        Case "pr":{
            Arr[max_data_length] := {ID: "page_r", od: ""}
        }
        ; pageの移動ボタン左
        Case "pl":{
            idx := max_data_length - TmScriptCL + 1
            Arr[idx] := {ID: "page_l", od: ""}
        }
        ; pageの移動ボタン両方
        Case "pb":{
            idx := max_data_length - TmScriptCL + 1
            Arr[idx] := {ID: "page_l", od: ""}
            Arr[max_data_length] := {ID: "page_r", od: ""}
        }
    }
    Return
}

LoadNewAllButtons(url) {
    TmScriptSavePreURL := url
    page_url := "streamDeck\json\" . url . ".json"
    FileRead, LocalStartPageFileData, %page_url%
    LocalNowPageDataOrg := JSON.Load(LocalStartPageFileData)
    TmScriptNowPageData := LocalNowPageDataOrg["page"]
    MinusLength := (TmScriptCL * TmScriptLN) - TmScriptNowPageData.length()
    If (MinusLength > 0) {
        AddVoidFunction(TmScriptNowPageData, MinusLength, LocalNowPageDataOrg["attr"])
    }
    For Index, Btn in TmScriptNowPageData {
        MyV := TmScriptBaseVName . Index
        MyPictureV := MyV . TmScriptBasePictureName
        MyName := Btn["ID"]
        MyIcon := (TmScriptButtons[MyName]["icon"] != "" ? TmScriptButtons[MyName]["icon"] : "png/void0.png")
        MyUrl := "streamDeck\" . (Btn["od"]["icon"] != "" ? Btn["od"]["icon"] : MyIcon)
        GuiControl, , %MyPictureV%, %MyUrl%
        Txt := (MyName == "dir" ? Btn["od"]["text"] : TmScriptButtons[MyName]["text"])
        TxtV := MyV . TmScriptBaseTextName
        GuiControl, , %TxtV%, %Txt%
    }
    Return
}

LogMousePos:
    If (TmScriptMouseFlag != 2) {
        Return
    }
    MouseGetPos, TmScriptMouseX, TmScriptMouseY
    If ((TmScriptMouseX != TmScriptMousePX || TmScriptMouseY != TmScriptMousePY ) && !(TmScriptMouseX > TmScriptScreenX && TmScriptMouseX < (TmScriptScreenX + TmScriptScreenWidth) && TmScriptMouseY > TmScriptScreenY && TmScriptMouseY < (TmScriptScreenY + TmScriptScreenHeight))){
        TmScriptMousePX := TmScriptMouseX
        TmScriptMousePY := TmScriptMouseY
        ; DisplayToolTip(TmScriptMousePX . " : " . TmScriptMousePY)
    }
Return

SetMouseFlag:
    If (TmScriptMouseFlag = 1) {
        TmScriptMouseFlag := 2
    }
Return

TmScriptExecCmdsFunc(url, type) {
    TmScriptPlayButtonFunc(6, "true")
    lasturl := StrSplit(url, "-:-")
    For Idx, Value in lasturl {
        If (type = "s") {
            ; SendLevel, 5
            Send, %Value%
        } Else If (type = "gs") {
            Gosub, %Value%
        } Else If (type = "r") {
            Run, %Value%
        }
        If (lasturl.length() > 0) {
            Sleep, 50
        }
    }
    change_url := "page\" . TmScriptPages[TmScriptIndex]
    If (TmScriptSavePreURL != change_url) {
        TmScriptSaveURLArray := []
        TmScriptSaveURLArray.Push(change_url)
        LoadNewAllButtons(TmScriptSaveURLArray[TmScriptSaveURLArray.MaxIndex()])
    }
Return
}

SwitchClickLabelSound:
    TmScriptClickLabelSound := !TmScriptClickLabelSound
    TmScriptPlayButtonFunc(6, (TmScriptClickLabelSound ? "true" : "false"))
Return

ClickedLabel:
    TmScriptMouseFlag := 0
    If (CheckDisplayLock(AddKeyMode) == -1) {
        Return
    }
    RegExMatch(A_GuiControl, TmScriptBaseVName . "(.+)" . TmScriptBasePictureName, a_gui_control)
    If (a_gui_control1 != "") {
        me := TmScriptNowPageData[a_gui_control1 + 0]
        org := TmScriptButtons[me["ID"]]
        url := org["cmd"]
        str := org["cmdType"]
        If (TmScriptClickAllow) {
            MouseMove, %TmScriptMousePX%, %TmScriptMousePY%
        }
        Switch (str) {
            Case "r":{
                TmScriptExecCmdsFunc(url, str)
            }
            Case "gs":{
                TmScriptExecCmdsFunc(url, str)
            }
            Case "s":{
                If (TmScriptClickAllow){
                    Click, %TmScriptMousePX%, %TmScriptMousePY%
                }
                TmScriptExecCmdsFunc(url, str)
            }
            Case "pgr":{
                If (TmScriptClickLabelSound) {
                    TmScriptPlayButtonFunc(6, "move")
                }
                TmScriptIndex := TmScriptIndex + 1
                LoadNewAllButtons("page\" . TmScriptPages[TmScriptIndex])
            }
            Case "pgl":{
                If (TmScriptClickLabelSound) {
                    TmScriptPlayButtonFunc(6, "move")
                }
                TmScriptIndex := TmScriptIndex - 1
                LoadNewAllButtons("page\" . TmScriptPages[TmScriptIndex])
            }
            Case "dir":{
                If (TmScriptClickLabelSound) {
                    TmScriptPlayButtonFunc(6, "open")
                }
                TmScriptSaveURLArray.Push(me["od"]["url"])
                LoadNewAllButtons(TmScriptSaveURLArray[TmScriptSaveURLArray.MaxIndex()])
            }
            Case "dru":{
                If (TmScriptClickLabelSound) {
                    TmScriptPlayButtonFunc(6, "close")
                }
                TmScriptSaveURLArray.RemoveAt(TmScriptSaveURLArray.MaxIndex())
                LoadNewAllButtons(TmScriptSaveURLArray[TmScriptSaveURLArray.MaxIndex()])
            }
            Case "void":{
                If (TmScriptClickAllow) {
                    MouseMove, %TmScriptMousePX%, %TmScriptMousePY%
                }
            }
        }
    }
    TmScriptMouseFlag := 1
    SetTimer, SetMouseFlag, -2000
Return

CreateSCTWindow:
    TmScriptDisplayFlag := !TmScriptDisplayFlag
    Gui, Destroy
    If (!TmScriptDisplayFlag) {
        Return
    }

    Gui, +AlwaysOnTop +Resize +ToolWindow -SysMenu +OwnDialogs +LastFound -Caption
    Gui, Color, White
    Gui, Font, s20, Arial
    TmScriptSavePreURL := "page\" . TmScriptPages[TmScriptIndex]
    page_url := "streamDeck\json\" . TmScriptSavePreURL . ".json"
    FileRead, LocalStartPageFileData, %page_url%
    LocalNowPageDataOrg := JSON.Load(LocalStartPageFileData)
    TmScriptNowPageData := LocalNowPageDataOrg["page"]
    MinusLength := (TmScriptCL * TmScriptLN) - TmScriptNowPageData.length()
    If (MinusLength > 0) {
        AddVoidFunction(TmScriptNowPageData, MinusLength, LocalNowPageDataOrg["attr"])
    }
    For Index, Btn in TmScriptNowPageData {
        BtnX := Mod((Index - 1), TmScriptCL) * IconW
        BtnY := Floor((Index - 1) / TmScriptCL) * IconH
        MyV := TmScriptBaseVName . Index
        PictureV := MyV . TmScriptBasePictureName
        MyName := Btn["ID"]
        MyIcon := (TmScriptButtons[MyName]["icon"] != "" ? TmScriptButtons[MyName]["icon"] : "png/void0.png")
        PicUrl := "streamDeck\" . (Btn["od"]["icon"] != "" ? Btn["od"]["icon"] : MyIcon)
        Txt := (MyName == "dir" ? Btn["od"]["text"] : TmScriptButtons[MyName]["text"])
        TxtX := BtnX
        TxtY := BtnY + IconH * 9 / 10
        TxtH := 32
        TextV := MyV . TmScriptBaseTextName

        ; picture
        Gui, Add, Picture, x%BtnX% y%BtnY% w%IconW% h%IconH% 0xE v%PictureV% gClickedLabel, %PicUrl%
        ; text
        Gui, Add, Text, x%TxtX% y%TxtY% w%IconW% h%TxtH% v%TextV% Center BackgroundTrans, %Txt%
    }
    Gui, Show, x%TmScriptScreenX% y%TmScriptScreenY% w%TmScriptScreenWidth% h%TmScriptScreenHeight% NoActivate, StreamDisplay
    WinActivate, StreamDisplay
    SetTimer, LogMousePos, 40
    SetTimer, TmScriptFirstCreatedExecLabel, -10
Return

TmScriptFirstCreatedExecLabel:
    TmScriptSaveURLArray := []
    TmScriptSaveURLArray.Push(TmScriptSavePreURL)
    LoadNewAllButtons(TmScriptSaveURLArray[TmScriptSaveURLArray.MaxIndex()])
Return

TmScriptPlayButtonFunc(Idx, Idx2) {
    PlayButtonSound(Idx, Idx2, True)
Return
}

TmScriptReturnSCTWindowFunc() {
    If (TmScriptDisplayFlag) {
        TmScriptDisplayFlag := False
        SetTimer, CreateSCTWindow, -100
    }
Return
}

TmScriptChangeWHBaseSCTWindowFunc() {
    SetSCTWindowInfo()
    TmScriptSCTWindowChangeWH := !TmScriptSCTWindowChangeWH
    DisplayToolTip("現在の追加ウィンドウの\n横幅は" . (TmScriptSCTWindowChangeWH ? "Width" : "Height") . "Org です")
Return
}

TmScriptMoveStreamDeckDisplay(ByRef XY, add) {
    If (CheckDisplayLock(AddKeyMode) == -1) {
        Return
    }
    PlayButtonSound(5, "r")
    _TF := False
    If (TmScriptDisplayFlag) {
        Gosub, CreateSCTWindow
        _TF := !_TF
    }
    XY := XY + add
    If (_TF) {
        Gosub, CreateSCTWindow
    }
Return
}

^Up::
    TmScriptMoveStreamDeckDisplay(TmScriptScreenY, -TmScriptScreenHeightOrg)
Return

^Down::
    TmScriptMoveStreamDeckDisplay(TmScriptScreenY, TmScriptScreenHeightOrg)
Return

^Left::
    TmScriptMoveStreamDeckDisplay(TmScriptScreenX, -TmScriptScreenWidthOrg)
Return

^Right::
    TmScriptMoveStreamDeckDisplay(TmScriptScreenX, TmScriptScreenWidthOrg)
Return