﻿#Requires AutoHotkey v2

#SingleInstance Force

InstallKeybdHook
InstallMouseHook
KeyHistory