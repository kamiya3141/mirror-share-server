﻿#Requires AutoHotkey v2

#SingleInstance Force

global DataDirName := "Data"
global SettingJsonFileName := "/ahk-setting.json"
global ExportedSettingJsonFilePath := DataDirName SettingJsonFileName
DirCreate(DataDirName)

if !FileExist(ExportedSettingJsonFilePath)
    FileInstall("./src/ahk-setting.json", ExportedSettingJsonFilePath)

#Include ../../../Lib/JXON.ahk

SetWorkingDir(A_ScriptDir)

global JsonTextData := FileRead(ExportedSettingJsonFilePath)
global SettingJsonData := Jxon_Load(&JsonTextData)

global ProgrammableKeysArray := SettingJsonData["programmable-keys"]
global MainHotkey := SettingJsonData["main-hotkey"]
global CustomHotkey := SettingJsonData["custom-hotkey"]
global ExitAppHotkey := SettingJsonData["exitapp-hotkey"]

global InheritString := "inherit"


ArraySearch(input_arr := [], input_obj := "") {
    if (input_arr.Length > 0) {
        for idx, val in input_arr {
            if (val == input_obj || InStr(input_obj, val))
                return idx
        }
    }
    return false
}

ArrayInclude(input_arr := [], input_obj := "") {
    if (input_arr.Length > 0) {
        for idx, val in input_arr {
            if (val == input_obj || InStr(input_obj, val))
                return true
        }
    }
    return 0
}

StrJoin(input_arr := [], split_str := ", ", add_last := false) {
    local ret_str := ""
    for i, v in input_arr
        ret_str .= (v . ((i == input_arr.Length && !add_last) ? "" : split_str))
    return ret_str
}

StrRepeat(input_str := "", repeat_count := 1) {
    local ret_str := ""
    if !IsInteger(repeat_count)
        ErrorExitFunc("main-hotkey-others-setting内のamountに")
    loop repeat_count
        ret_str .= input_str
    return ret_str
}

PressHotkeysFunc(idx := 1) {
    global SettingJsonData
    if (idx == 1) {
        local b_str := "", m_str := "", a_str := ""
        if (SettingJsonData["main-hotkey-others-setting"]["before-string"]["allow"]) {
            if (SettingJsonData["main-hotkey-others-setting"]["before-string"]["reference-programmable-keys"] && CheckProgrammableKey(SettingJsonData["main-hotkey-others-setting"]["before-string"]["char"])) {
                b_str := "{" SettingJsonData["main-hotkey-others-setting"]["before-string"]["char"] "}"
                b_str := StrRepeat(b_str, SettingJsonData["main-hotkey-others-setting"]["before-string"]["amount"])
            } else
                ErrorExitFunc("main-hotkey-others-setting/before-stringのcharに", "`n自由な値を設定したい場合は`nreference-programmable-keysをfalseに設定してください")
        }
        if (SettingJsonData["main-hotkey-others-setting"]["after-string"]["allow"]) {
            if (SettingJsonData["main-hotkey-others-setting"]["after-string"]["reference-programmable-keys"] && CheckProgrammableKey(SettingJsonData["main-hotkey-others-setting"]["after-string"]["char"])) {
                a_str := "{" SettingJsonData["main-hotkey-others-setting"]["after-string"]["char"] "}"
                a_str := StrRepeat(a_str, SettingJsonData["main-hotkey-others-setting"]["after-string"]["amount"])
            } else
                ErrorExitFunc("main-hotkey-others-setting/after-stringのcharに", "`n自由な値を設定したい場合は`nreference-programmable-keysをfalseに設定してください")
        }
        nowDay := A_Now
        nowDayArray := [SubStr(nowDay, 1, 4), "/", SubStr(nowDay, 5, 2), "/", SubStr(nowDay, 7, 2), " ", SubStr(nowDay, 9, 2), ":", SubStr(nowDay, 11, 2)]
        for i, v in nowDayArray
            m_str .= v
        Send(b_str m_str a_str)
    } else if (idx == 2) {
        local b_str := "", m_str := "", a_str := ""
        if (SettingJsonData["custom-hotkey-others-setting"]["before-string"]["allow"]) {
            if (SettingJsonData["custom-hotkey-others-setting"]["before-string"]["reference-programmable-keys"] && CheckProgrammableKey(SettingJsonData["custom-hotkey-others-setting"]["before-string"]["char"])) {
                b_str := "{" SettingJsonData["custom-hotkey-others-setting"]["before-string"]["char"] "}"
                b_str := StrRepeat(b_str, SettingJsonData["custom-hotkey-others-setting"]["before-string"]["amount"])
            } else
                ErrorExitFunc("custom-hotkey-others-setting/before-stringのcharに", "`n自由な値を設定したい場合は`nreference-programmable-keysをfalseに設定してください")
        }
        if (SettingJsonData["custom-hotkey-others-setting"]["after-string"]["allow"]) {
            if (SettingJsonData["custom-hotkey-others-setting"]["after-string"]["reference-programmable-keys"] && CheckProgrammableKey(SettingJsonData["custom-hotkey-others-setting"]["after-string"]["char"])) {
                a_str := "{" SettingJsonData["custom-hotkey-others-setting"]["after-string"]["char"] "}"
                a_str := StrRepeat(a_str, SettingJsonData["custom-hotkey-others-setting"]["after-string"]["amount"])
            } else
                ErrorExitFunc("custom-hotkey-others-setting/after-stringのcharに", "`n自由な値を設定したい場合は`nreference-programmable-keysをfalseに設定してください")
        }
        nowDay := A_Now
        nowDayArray := [SubStr(nowDay, 1, 4), SettingJsonData["custom-hotkey-setting"]["year"], SubStr(nowDay, 5, 2), SettingJsonData["custom-hotkey-setting"]["month"], SubStr(nowDay, 7, 2), SettingJsonData["custom-hotkey-setting"]["day"], SubStr(nowDay, 9, 2), SettingJsonData["custom-hotkey-setting"]["hour"], SubStr(nowDay, 11, 2), SettingJsonData["custom-hotkey-setting"]["minute"]]
        for i, v in nowDayArray
            m_str .= v
        Send(b_str m_str a_str)
    } else {
        MsgBox "アプリを終了します"
        ExitApp()
    }
}

Process_Press_Hotkeys_Func(idx := 1) {
    return (*) => PressHotkeysFunc(idx)
}

MainFunction() {
    global MainHotkey, CustomHotkey, ExitAppHotkey

    MainHotkey := ConvertInheritValue(MainHotkey, true)
    CustomHotkey := ConvertInheritValue(CustomHotkey)
    ExitAppHotkey := ConvertInheritValue(ExitAppHotkey)

    Hotkey(MainHotkey, Process_Press_Hotkeys_Func(1))
    Hotkey(CustomHotkey, Process_Press_Hotkeys_Func(2))
    Hotkey(ExitAppHotkey, Process_Press_Hotkeys_Func(3))

    return
}

CheckProgrammableKey(input_string := "") {
    global ProgrammableKeysArray
    local tf := ArrayInclude(ProgrammableKeysArray, input_string)
    return tf
}

ErrorExitFunc(b_str := "", a_str := "") {
    MsgBox(b_str "無効な値が設定されています`nアプリを強制終了します" a_str)
    ExitApp()
}

ConvertInheritValue(input_string := "", is_main_hotkey := false) {
    global MainHotkey, CustomHotkey, ExitAppHotkey, InheritString
    if (is_main_hotkey && InStr(input_string, InheritString))
        ErrorExitFunc("main-hotkeyに")
    else if (!is_main_hotkey)
        input_string := StrReplace(input_string, InheritString, MainHotkey)
    return input_string
}


MainFunction()