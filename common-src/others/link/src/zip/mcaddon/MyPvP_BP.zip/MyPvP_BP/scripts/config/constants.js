// ----------
// 重要な設定
// ----------

const PROJECT_INFO = {
	/**@summary マイクラ鯖の種別(kuni, kikaku, oc-pvp, mainなど) */
	serverName: "kikaku",
	/**@summary マイクラワールド名 */
	worldName: "kikaku-survival"
};

const NAME_SPACE_ORIGINAL = "MyPvP";
const NAME_SPACE = NAME_SPACE_ORIGINAL.toLowerCase();
const UI__NAME_SPACE = `${NAME_SPACE}-ui`;
function NS(name = "", name_space = NAME_SPACE, without_colon = true) {
	return name || !without_colon ? `${name_space}:${name}` : name_space;
}

const MC_CHUNK = 16;
function CALC_MCC(n = 1) {
	return Math.floor(MC_CHUNK * n);
}
const MC_SECOND = 20;
function CALC_MCS(n = 1) {
	return Math.floor(MC_SECOND * n);
}

const DEBUG_MODE = true;


// ----------
// その他
// ----------

const UUID_chars =
	"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
function generateUUID(length = CALC_MCC(2)) {
	let id = "";
	for (let i = 0; i < length; i++)
		id += UUID_chars[Math.floor(Math.random() * UUID_chars.length)];
	return id;
}

function createMinMaxObject(...args) {
	return {
		min: Math.min(...args),
		max: Math.max(...args)
	};
}
function isInRange(min, val, max) {
	return Boolean(Number(val) >= Number(min) && Number(val) <= Number(max));
}
function fixInRange(min, val, max) {
	if (isInRange(min, val, max))
		return val;
	if (val < min)
		return (max - min) - ((val - min) % (max - min)) + min + 1;
	if (val > max)
		return ((val - min) % (max - min)) + min - 1;
}
function constrain(min, val, max) {
	if (isInRange(min, val, max))
		return val;
	if (val < min)
		return min;
	if (val > max)
		return max;
}
function random(min, max) {
	return Math.floor((Math.random() * (max - min + 1)) - min);
}
const named_style_func_obj = {
	stl: (...arr) => {
		return stl_str(...arr);
	},
	bld: (...arr) => {
		return bld_str(...arr);
	},
	itl: (...arr) => {
		return itl_str(...arr);
	},
	err: (...arr) => {
		return err_str(...arr);
	},
	dng: (...arr) => {
		return dng_str(...arr);
	},
	wrn: (...arr) => {
		return wrn_str(...arr);
	},
	nml: (...arr) => {
		return nml_str(...arr);
	},
	crt: (...arr) => {
		return crt_str(...arr);
	},
	thin: (...arr) => {
		return thin_str(...arr);
	}
};
const RSS = stl_str("", "r");
function style_str(str = "", style_char_array = []) {
	if (Array.isArray(style_char_array))
		style_char_array.forEach(
			ipt =>
			(str = Array.isArray(ipt)
				? Object.keys(named_style_func_obj).some(s => s === ipt[0])
					? named_style_func_obj[ipt[0]](str, ipt[1])
					: stl_str(str, ipt[0])
				: named_style_func_obj[ipt](str))
		);
	else if (typeof style_char_array === "string") {
		if (style_char_array.length == 1) str = stl_str(str, style_char_array);
		else if (style_char_array.length > 1)
			str = named_style_func_obj[style_char_array](str);
	}
	return str + RSS;
}

function stl_str(str = "", style_char = "", _any = false) {
	const _char = !style_char || style_char.length > 1 ? "f" : style_char;
	return `§${_char}${str}`;
}
function bld_str(str = "", _any = false) {
	return stl_str(str, "l");
}
function itl_str(str = "", _any = false) {
	return stl_str(str, "o");
}
function err_str(str = "", with_error_str = false) {
	if (with_error_str) str = `[${itl_str("Error")}] ${str}`;
	return stl_str(str, "c");
}
function dng_str(str = "", with_dangerous_str = false) {
	if (with_dangerous_str) str = `[${itl_str("Danger")}] ${str}`;
	return stl_str(str, "6");
}
function wrn_str(str = "", with_warn_str = false) {
	if (with_warn_str) str = `[${itl_str("Warn")}] ${str}`;
	return stl_str(str, "e");
}
function nml_str(str = "", _any = false) {
	return stl_str(str, "b");
}
function crt_str(str = "", _any = false) {
	return stl_str(str, "a");
}
function thin_str(str = "", _any = false) {
	return stl_str(str, "8");
}

function deepCopyObject(obj) {
	if (obj === null || typeof obj !== "object") return obj;
	const copy = Array.isArray(obj) ? [] : {};
	for (const key in obj) {
		if (obj.hasOwnProperty(key)) copy[key] = deepCopyObject(obj[key]);
	}
	return copy;
}

function deepOutputStrObj(obj = {}, i = 0, key_name = null) {
	i = i < 0 ? 0 : i;
	const nbsp = " ".repeat(4);
	if (obj === null || typeof obj !== "object")
		return `${nbsp.repeat(i)}${typeof obj} | ${key_name ? `${key_name}: ` : ""
			}${obj}\n`;
	let res_str = "";
	for (const key in obj)
		if (obj.hasOwnProperty(key))
			res_str += deepOutputStrObj(obj[key], ++i, key);
	if (i === 0)
		res_str = `\n${res_str}`;
	return res_str;
}

export default {
	PROJECT_INFO,
	NAME_SPACE_ORIGINAL,
	NAME_SPACE,
	UI__NAME_SPACE,
	NS,
	CALC_MCC,
	CALC_MCS,
	DEBUG_MODE,
	UUID_chars,
	generateUUID,
	createMinMaxObject,
	isInRange,
	fixInRange,
	constrain,
	random,
	RSS,
	style_str,
	stl_str,
	bld_str,
	itl_str,
	err_str,
	dng_str,
	wrn_str,
	nml_str,
	crt_str,
	thin_str,
	deepCopyObject,
	deepOutputStrObj
};
