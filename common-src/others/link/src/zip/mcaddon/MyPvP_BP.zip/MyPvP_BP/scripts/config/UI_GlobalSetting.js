import constants from "./constants";
import { GSO } from "./Common_GlobalSetting";

export const UI__GSO_DEFINE = {
	settingData: {
		topClaimOrSuggest: {
			parts: {
				dropdown: [
					[
						{
							id: "suggest",
							name: "提案"
						},
						{
							id: "claim",
							name: "クレーム"
						}
					]
				],
				textField: [
					constants.createMinMaxObject(1, 128),
					constants.createMinMaxObject(1, 1024)
				]
			}
		}
	}
};

export const UI__GSO = {
	settingData: {
		top: {
			dataType: "action",
			parts: {
				body: [
					[constants.NS("トップメニュー", "ルート")]
				],
				button: [
					["チームの操作"],
					["試合の申請"],
					["試合の操作"],
					["観戦モード"],
					["プレイヤー/チーム/試合情報の確認"],
					["クレーム/提案をサーバに送信"],
					["%BACK_BTN_STR%"]
				]
			}
		},
		topTeam: {
			dataType: "action",
			parts: {
				body: [
					[constants.NS("トップメニュー", "チーム")]
				],
				button: [
					["チームを作成する"],
					["チームを削除する"],
					["チームメンバーを追加する"],
					["チームメンバーを削除する"],
					["%BACK_BTN_STR%"]
				]
			}
		},
		topMatchType: {
			dataType: "action",
			parts: {
				body: [
					[constants.NS("トップメニュー", "試合申請")]
				],
				button: [
					["プレイヤー vs プレイヤー"],
					["チーム vs チーム"],
					["プレイヤー vs NPC(単体)"],
					["チーム vs NPC(複数)"],
					["%BACK_BTN_STR%"]
				]
			}
		},
		topMatchEdit: {
			dataType: "action",
			parts: {
				body: [
					[constants.NS("トップメニュー", "試合操作")]
				],
				button: [
					["試合申請を受諾する"],
					["試合を棄却する"],
					["%BACK_BTN_STR%"]
				]
			}
		},
		topMatchWatch: {
			dataType: "action",
			parts: {
				body: [
					[constants.NS("トップメニュー", "試合観戦")]
				],
				button: [
					["試合を観戦する"],
					["%BACK_BTN_STR%"]
				]
			}
		},
		topInfo: {
			dataType: "action",
			parts: {
				body: [
					["プレイヤー、チーム、試合を選択"]
				],
				button: [
					["プレイヤー情報"],
					["チーム情報"],
					["試合情報"],
					["%BACK_BTN_STR%"]
				]
			}
		},
		topSuggestOrClaim: {
			dataType: "modal",
			parts: {
				dropdown: [
					...["内容選択"].map((s, i) => [s, UI__GSO_DEFINE.settingData.topClaimOrSuggest.parts.dropdown[i].map(obj => obj.name), { "defaultValueIndex": 0 }])
				],
				textField: [
					...["タイトル", "本文"].map((s, i) => [s, `${s}を入力(${Object.values(UI__GSO_DEFINE.settingData.topClaimOrSuggest.parts.textField[i]).join("~")}文字)`])
				]
			}
		},
		selectOnlinePlayers: {
			dataType: "modal",
			parts: {
				dropdown: [
					["プレイヤー選択", "%ONLINE_PLAYERS_NAME_ARRAY%", { "defaultValueIndex": 0 }]
				]
			}
		},
		selectAllPlayers: {
			dataType: "modal",
			parts: {
				dropdown: [
					["プレイヤー選択", "%ALL_PLAYERS_NAME_ARRAY%", { "defaultValueIndex": 0 }]
				]
			}
		},
		selectOnlineTeams: {
			dataType: "modal",
			parts: {
				dropdown: [
					["チーム選択", "%ONLINE_TEAMS_NAME_ARRAY%", { "defaultValueIndex": 0 }]
				]
			}
		},
		selectAllTeams: {
			dataType: "modal",
			parts: {
				dropdown: [
					["チーム選択", "%ALL_TEAMS_NAME_ARRAY%", { "defaultValueIndex": 0 }]
				]
			}
		},
		selectMatches: {
			dataType: "modal",
			parts: {
				dropdown: [
					["試合IDの選択", "%MATCHES_ID_ARRAY%", { "defaultValueIndex": 0 }]
				]
			}
		},
		selectAllFields: {
			dataType: "modal",
			parts: {
				dropdown: [
					["試合会場選択", [...GSO.limit.field.map(f => f.name)], { "defaultValueIndex": 0 }]
				]
			}
		},
		selectAllMyMatches: {
			dataType: "modal",
			parts: {
				dropdown: [
					["受信中の試合IDの選択", "%ALL_MY_MATCHES_ID_ARRAY%", { "defaultValueIndex": 0 }]
				]
			}
		},
		selectAllMyTeams: {
			dataType: "modal",
			parts: {
				dropdown: [
					["申請チームを選択", "%ALL_MY_TEAMS_NAME_ARRAY%", { "defaultValueIndex": 0 }]
				]
			}
		},
		inputTeamID: {
			dataType: "modal",
			parts: {
				textField: [
					[`チームID(${[GSO.limit.team.id.length.min, GSO.limit.team.id.length.max].join("~")}文字)[${GSO.limit.team.id.reg_str}]`, "新規/既存のチームIDを入力"]
				]
			}
		},
		inputTeamName: {
			dataType: "modal",
			parts: {
				textField: [
					[`チーム名(${[GSO.limit.team.name.length.min, GSO.limit.team.name.length.max].join("~")}文字)[${GSO.limit.team.name.reg_str}]`, "新規/既存のチーム名を入力"]
				]
			}
		},
		inputMatchID: {
			dataType: "modal",
			parts: {
				textField: [
					[`試合ID(${[GSO.limit.match.id.length.min, GSO.limit.match.id.length.max].join("~")}文字)[${GSO.limit.match.id.reg_str}]`, "新規/既存の試合IDを入力"]
				]
			}
		},
		displayText: {
			dataType: "action",
			parts: {
				body: [
					["%OUTPUT_TEXT%"]
				],
				button: [
					["%BACK_BTN_STR%"]
				]
			}
		}
	}
};