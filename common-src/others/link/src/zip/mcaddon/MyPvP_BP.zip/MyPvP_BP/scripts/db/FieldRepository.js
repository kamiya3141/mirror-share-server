import constants from "../config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "../config/Common_GlobalSetting";
import { wld } from "../world/World";
import { MyPvPEntityRepository } from "./MyPvPEntityRepository";
import {
	ALL_FIELDS_HISTORY
} from "./ObjectHistoryRepository";
import { Player } from "../player/Player";
import { Team } from "../team/Team";
import { MatchRepository } from "./MatchRepository";

export class FieldRepository extends MyPvPEntityRepository {
	#data = {
		id: "",
		name: "",
		location: new Array(MatchRepository.StatusKindsArray.length).fill([[], [], []])
	};
	constructor (id = "", name = "", location = [], isRestored = false, restoredData = {}) {
		this.saveDB();
	}
	loadDB() {
		super.saveDB(this.#loadDB());
		return super.loadDB();
	}
	#loadDB() {
		return this.get("data");
	}
	saveDB(data = null) {
		if (typeof data === "object") Object.assign(this.#data, data);
		super.saveDB(this.#data);
		this.#saveDB();
	}
	#saveDB() {
		this.set("data", this.#data);
		ALL_FIELDS_HISTORY[this.id] = this;
	}
	get id() {
		return this.#data.id;
	}
	set id(_id = "") {
		this.#data.id = _id;
		this.saveDB();
	}
	get name() {
		return this.#data.name;
	}
	set name(_name = "") {
		this.#data.name = _name;
		this.saveDB();
	}
}
