import { system } from "@minecraft/server";

import constants from "./../config/constants";
import { RANKING_BOARD_PLAYER_LENGTH } from "./../config/Common_GlobalSetting";
import {
	OH_KEYS,
	ALL_PLAYERS_HISTORY,
	ONLINE_PLAYERS,
	ALL_TEAMS_HISTORY,
	ALL_HISTORY_SAVE_FUNC,
	WAIT_MATCHES,
	ALL_MATCHES_HISTORY,
	UPDATE_ONLINE_PLAYERS_FUNCTION_ARRAY
} from "./../db/ObjectHistoryRepository";
import { wld } from "./../world/World";

const MAIN_RB_ID = "rb0";

if (!UPDATE_ONLINE_PLAYERS_FUNCTION_ARRAY.length)
	UPDATE_ONLINE_PLAYERS_FUNCTION_ARRAY.push(l => updateDashHoloCraftPlus(l, MAIN_RB_ID));
function updateDashHoloCraftPlus(len = 0, id = "test") {
	const get_name_func = player => `${constants.style_str(player.name, !player.isOffline ? "crt" : "thin")}`;
	const allPlayerData = Object.values(ALL_PLAYERS_HISTORY);
	const playerKillCountDataArray = [...allPlayerData].map(p => ({
		name: get_name_func(p),
		killCount: p.killCount
	})).sort((a, b) => (Number(b.killCount) - Number(a.killCount)));
	const rankingBoardPlayerInfoStrArray = new Array(RANKING_BOARD_PLAYER_LENGTH).fill(0).map((_, i) =>
		`${Object.values((i < playerKillCountDataArray.length) ? playerKillCountDataArray[i] : ({
			name: constants.style_str("NO_DATA", "err"),
			killCount: 0
		})).join(": ")} kill`
	);
	const rankingBoardAllPlayerInfoStrArray = [
		constants.style_str(`ONLINE: ${len}`, "crt"),
		constants.style_str(`OFFLINE: ${allPlayerData.length - len}`, "thin"),
		...rankingBoardPlayerInfoStrArray
	];
	const execWldCmd_HP = (cmd, ...args) => wld.cmd(["scriptevent", constants.NS(cmd, "hp"), id, ...args].join(" "));
	execWldCmd_HP("clear");
	execWldCmd_HP("addline", rankingBoardAllPlayerInfoStrArray.join("\n"));
}
