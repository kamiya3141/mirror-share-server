import constants from "./../config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "./../config/Common_GlobalSetting";
import {
	ALL_PLAYERS_HISTORY,
	ONLINE_PLAYERS,
	ALL_TEAMS_HISTORY
} from "./../db/ObjectHistoryRepository";
import { MyPvPEntityRepository } from "./MyPvPEntityRepository";

export class PlayerRepository extends MyPvPEntityRepository {
	#data = {
		id: "",
		name: "",
		teams: [],
		killCount: 0,
		status_index: 0,
		typeId: "",
		exist: true
	};
	constructor (player, isRestored = false, restoredData = {}) {
		super(player, constants.NS(player.id, "player"), isRestored);
		this.isRestored = isRestored;
		this.#data.id = this.isRestored ? restoredData.id : player.id;
		this.#data.teams = this.isRestored ? restoredData.teams : [];
		this.#data.killCount = this.isRestored ? restoredData.killCount : 0;
		this.#data.status_index = 0;	// this.isRestored ? restoredData.status_index : 0;
		this.#data.typeId = this.isRestored ? restoredData.typeId : (player.typeId ?? constants.NS("player", "minecraft"));
		this.#data.name = this.isRestored ? restoredData.name : (player.name ?? this.typeId);
		this.#data.exist = Boolean(!this.isRestored);
		this.saveDB();
	}
	get isMCPlayer() {
		return this.typeId === constants.NS("player", "minecraft");
	}
	checkEnemyEntity(field_index) {
		return this.typeId === GSO.limit.field[field_index].enemy.typeId;
	}
	loadDB() {
		super.saveDB(this.#loadDB());
		return super.loadDB();
	}
	#loadDB() {
		return this.get("data");
	}
	saveDB(data = null) {
		if (!this.isMCPlayer)
			return;
		if (typeof data === "object")
			Object.assign(this.#data, data);
		super.saveDB(this.#data);
		this.#saveDB();
	}
	#saveDB() {
		if (this.exist)
			this.set("data", this.#data);
		ALL_PLAYERS_HISTORY[this.id] = this;
	}
	get id() {
		return this.#data.id;
	}
	set id(new_id = "") {
		if (!this.isMCPlayer)
			this.#data.id = new_id;
	}
	get typeId() {
		return this.#data.typeId;
	}
	get name() {
		return this.#data.name;
	}
	get teams() {
		return this.#data.teams;
	}
	set teams(team) {
		if (this.existTeams(team)) return;
		this.#data.teams.push(team);
		this.saveDB();
	}
	set leaveTeam(tid = "") {
		if (!this.existTeams(tid)) return;
		const i = this.teams.findIndex(tid);
		if (i > 0)
			this.#data.teams.splice(i, 1);
		this.saveDB();
	}
	get teamsStr() {
		return this.teams.join(", ");
	}
	existTeams(...args) {
		for (const team of args)
			if (!this.teams.includes(team))
				return false;
		return true;
	}
	get killCount() {
		return this.#data.killCount;
	}
	set killCount(n = 0) {
		n = Number.isNaN(Number(n)) ? 0 : Number(n);
		this.#data.killCount = this.killCount + n;
		this.saveDB();
	}
	get status_index() {
		return this.#data.status_index;
	}
	set status_index(index = 0) {
		this.#data.status_index = index;
		this.saveDB();
	}
	get status() {
		return MyPvPEntityRepository.StatusKindsArray[this.status_index];
	}
	get exist() {
		return this.#data.exist;
	}
	set exist(bool = true) {
		this.#data.exist = Boolean(bool);
		this.saveDB();
	}
	static get idlingIndex() {
		return 0;
	}
	static get pendingIndex() {
		return 1;
	}
	static get matchingIndex() {
		return 2;
	}
	static get watchingIndex() {
		return 3;
	}
	get isIdling() {
		return this.status_index === PlayerRepository.idlingIndex;
	}
	get isPending() {
		return this.status_index === PlayerRepository.pendingIndex;
	}
	get isMatching() {
		return this.status_index === PlayerRepository.matchingIndex;
	}
	get isWatching() {
		return this.status_index === PlayerRepository.watchingIndex;
	}
}
