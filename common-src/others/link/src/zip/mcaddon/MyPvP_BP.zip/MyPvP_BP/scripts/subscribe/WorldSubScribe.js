import { world } from "@minecraft/server";

import constants from "./../config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "./../config/Common_GlobalSetting";
import {
	OH_KEYS,
	ALL_PLAYERS_HISTORY,
	ONLINE_PLAYERS,
	ALL_TEAMS_HISTORY,
	ALL_HISTORY_SAVE_FUNC,
	WAIT_MATCHES,
	ALL_MATCHES_HISTORY,
	UPDATE_ONLINE_PLAYERS_FUNCTION_ARRAY,
	updateOnlinePlayerLength
} from "./../db/ObjectHistoryRepository";
import { Player } from "./../player/Player";
import { Match } from "./../match/Match";

// プレイヤースポーン
world.afterEvents.playerSpawn.subscribe(ev => {
	const p = Player.findOnlinePlayer(ev.player.id);
	const player = p ?? new Player(ev.player);
	Player.addOnlinePlayer(player);
	updateOnlinePlayerLength();
	if (!p && player.getGamemode() !== Player.gameModeArray[1]) {
		player.setSpawnPoint(LOBBY_LOCATION);
		player.teleport(LOBBY_LOCATION);
		player.setGamemode(2);
	}
});
// プレイヤー離脱
world.beforeEvents.playerLeave.subscribe(ev => {
	const player = ev.player;
	Player.delOnlinePlayer(player.id);
	updateOnlinePlayerLength();
});

// エンティティ死亡
world.afterEvents.entityDie.subscribe(ev => {
	const dead_entity_data = ev.deadEntity;
	const attacker_entity_data = ev.damageSource.damagingEntity;
	if (!attacker_entity_data && !dead_entity_data)
		return;
	const attacker_entity = Player.findOnlinePlayer(attacker_entity_data?.id);
	const dead_entity = Player.findOnlinePlayer(dead_entity_data?.id);
	if (!attacker_entity && !dead_entity)
		return;
	for (let i = 0; i < BATTLE_FIELDS_COUNT; i++) {
		if (WAIT_MATCHES[i].waiting.length === 0 || !WAIT_MATCHES[i]["waiting"][0])
			continue;
		/**@type {Match} */
		const match = WAIT_MATCHES[i]["waiting"][0];
		if (constants.isInRange(1, match.status_index, 2)) {
			if (dead_entity) {
				if (dead_entity.checkEnemyEntity(i)) {
					const _idx = match.teams_pid_arr[1].indexOf(dead_entity.id);
					if (_idx === -1)
						continue;
					const new_player_entity = Match.spawnEnemy(i, match.status_index);
					new_player_entity.status_index = dead_entity.status_index;
					match.setTeamsPidArr(1, _idx, new_player_entity.id);
					Player.delOnlinePlayer(dead_entity.id);
					break;
				} else if (dead_entity.isMCPlayer) {
					const _idx = match.teams_pid_arr.findIndex(pid_arr => pid_arr.includes(dead_entity.id));
					if (_idx === -1)
						continue;
					const locs = GSO.limit.field[i].location[match.status][_idx];
					dead_entity.setSpawnPoint(...locs);
					if (attacker_entity && attacker_entity.isMCPlayer && !match.isInTeamsPidArr(attacker_entity.id, dead_entity.id))
						attacker_entity.addMatchKills(1);
					break;
				}
			}
		}
	}
});
// エンティティ削除
world.afterEvents.entityRemove.subscribe(ev => {
	const dead_entity = Player.findOnlinePlayer(ev.removedEntityId);
	for (let i = 0; i < BATTLE_FIELDS_COUNT; i++) {
		if (WAIT_MATCHES[i].waiting.length === 0 || !WAIT_MATCHES[i]["waiting"][0])
			continue;
		/**@type {Match} */
		const match = WAIT_MATCHES[i]["waiting"][0];
		if (constants.isInRange(1, match.status_index, 2)) {
			if (dead_entity && dead_entity.checkEnemyEntity(i)) {
				const _idx = match.teams_pid_arr[1].indexOf(dead_entity.id);
				if (_idx === -1)
					continue;
				const new_player_entity = Match.spawnEnemy(i, match.status_index);
				new_player_entity.status_index = dead_entity.status_index;
				match.setTeamsPidArr(1, _idx, new_player_entity.id);
				Player.delOnlinePlayer(dead_entity.id);
				break;
			}
		}
	}
});

// エンティティが傷ついたとき（プレイヤー攻撃）
world.beforeEvents.entityHurt.subscribe(ev => {
	if (ev.damageSource.cause === "fall")
		return ev.cancel = true;
	const p = ev.damageSource.damagingEntity;
	const t = ev.hurtEntity;
	if (!p || !t)
		return;
	const player = Player.findOnlinePlayer(p.id);
	const target = Player.findOnlinePlayer(t.id);
	if (player && target) {
		for (let i = 0; i < BATTLE_FIELDS_COUNT; i++) {
			/**@type {Match} */
			const match = WAIT_MATCHES[i]["waiting"][0];
			if (!match)
				continue;
			// 味方同士の攻撃をキャンセル
			if (match.isInTeamsPidArr(player.id, target.id)) {
				ev.cancel = true;
				break;
			}
		}
	}
});

// ブロック破壊
world.beforeEvents.playerBreakBlock.subscribe(ev => {
	const p = ev.player;
	const player = Player.findOnlinePlayer(p.id);
	if (!player || (player.isMatching && !player.getGamemode(1)))
		ev.cancel = true;
});

// ブロック操作
world.beforeEvents.playerInteractWithBlock.subscribe(ev => {
	const p = ev.player;
	const player = Player.findOnlinePlayer(p.id);
	const block = ev.block;
	const cancel_arr = ["chest"].map(_typeId => constants.NS(_typeId, "minecraft"));
	if (!player || (player.isMatching && !player.getGamemode(1) && !cancel_arr.includes(block.typeId)))
		ev.cancel = true;
});
