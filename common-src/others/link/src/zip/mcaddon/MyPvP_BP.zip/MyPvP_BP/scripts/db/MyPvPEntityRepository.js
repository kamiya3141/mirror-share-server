import constants from "./../config/constants";
import { DynamicPropertyRepository } from "./DynamicPropertyRepository";

export class MyPvPEntityRepository extends DynamicPropertyRepository {
	constructor (target, ns, isRestored = false) {
		// mp = mypvp
		super(target, constants.NS(ns, "mp-entity"));
		this.isRestored = isRestored;
		this.data = new Object();
		this.cache_data = new Object();
	}
	static StatusKindsArray = ["idling", "pending", "matching", "watching"];
	static IDCH = "_";
	static joinedArr(arr = [], n = 1) {
		n = n < 1 ? 1 : n;
		return arr.join(this.IDCH.repeat(n));
	}
	static finishedFlagStr = "finished";
	static createFinishedID(id = "Example") {
		return this.joinedArr([id, this.finishedFlagStr], 4);
	}
	static isFinishedID(id = "Example") {
		return id.endsWith(this.finishedFlagStr);
	}
	static canceledFlagStr = "canceled";
	static createCanceledID(id = "Example") {
		return this.joinedArr([id, this.canceledFlagStr], 4);
	}
	static isCanceledID(id = "Example") {
		return id.endsWith(this.canceledFlagStr);
	}
	static removedFlagStr = "removed";
	static createRemovedID(id = "Example") {
		return this.joinedArr([id, this.removedFlagStr], 4);
	}
	static isRemovedID(id = "Example") {
		return id.endsWith(this.removedFlagStr);
	}
	loadDB() {
		return this.data;
	}
	saveDB(db) {
		this.data = db;
	}
	writeCacheDataFromMyData() {
		this.cache_data = constants.deepCopyObject(this.data);
	}
	has(key) {
		return this.isRestored ? undefined : super.has(key);
	}
	get(key) {
		return this.isRestored ? undefined : super.get(key);
	}
	set(key, value) {
		return this.isRestored ? undefined : super.set(key, value);
	}
	delete(key) {
		return this.isRestored ? undefined : super.delete(key);
	}
}
