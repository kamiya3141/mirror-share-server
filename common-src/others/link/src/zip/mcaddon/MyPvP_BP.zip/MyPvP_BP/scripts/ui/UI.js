import { system, world } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";

import constants from "./../config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "./../config/Common_GlobalSetting";
import { UI__GSO, UI__GSO_DEFINE } from "./../config/UI_GlobalSetting";
import { ALL_MATCHES_HISTORY, ALL_PLAYERS_HISTORY, ALL_TEAMS_HISTORY, ONLINE_PLAYERS } from "./../db/ObjectHistoryRepository";
import { wld } from "./../world/World";
import { MyPvPEntityRepository } from "./../db/MyPvPEntityRepository";
import { Player } from "./../player/Player";
import { Team } from "./../team/Team";
import { Match } from "./../match/Match";

/**
 * 
 * @param {String} str 
 * @param {Player} player 
 * @param  {...any} args 
 * @returns {any}
 */
function convertMyPvPUIEnvVars(str = "", player, ...args) {
	if (typeof str !== "string") {
		// player.tell(`strが不正な値です\nstr: ${constants.deepOutputStrObj(str)}\nUI::convertMyPvPUIEnvVars`);
		return str;
	}

	let res_val = str;

	const start_str = "%";
	const end_str = "%";
	const comeback_str = "<- 戻る";
	const reg = new RegExp(`${start_str}(.*?)${end_str}`, "g");

	[...str.matchAll(reg)].forEach(match_arr => {
		const match = match_arr[1];
		const match_str = start_str + match + end_str;
		switch (match) {
			case "BACK_BTN_STR":
				res_val = res_val.replace(match_str, comeback_str);
				break;
			case "ONLINE_PLAYERS_NAME_ARRAY":
			case "ALL_PLAYERS_NAME_ARRAY":
			case "ONLINE_TEAMS_NAME_ARRAY":
			case "ALL_TEAMS_NAME_ARRAY":
			case "ALL_MY_TEAMS_NAME_ARRAY":
				const cls_array = args[0];
				res_val = cls_array.map(cls => cls.name);
				break;
			case "MATCHES_ID_ARRAY":
			case "ALL_MY_MATCHES_ID_ARRAY":
				const my_match_array = args[0];
				res_val = my_match_array.filter(m => !m.isCanceled && !m.isFinished).map(m => [m.originalID, m.matchingTime].join(" "));
				break;
			case "OUTPUT_TEXT":
				res_val = String(args[0]);
				break;
			default:
				break;
		}
	});
	return res_val;
}
/**
 * 
 * @param {Player} player 
 * @param {Object} obj 
 * @param  {...any} args 
 * @returns {any}
 */
function createFormData(player, obj = { "dataType": "action", "parts": {} }, ...args) {
	let form_data = null;
	switch (obj["dataType"]) {
		case "action":
			form_data = new ActionFormData();
			break;
		case "modal":
			form_data = new ModalFormData();
			break;
		case "message":
			form_data = new MessageFormData();
			break;
		default:
			player.tell(`obj["dataType"]が未知の値です: ${obj["dataType"]} UI::createFormData`, "err");
			return form_data;
	}
	if (!Object.keys(obj["parts"]).includes("title"))
		obj["parts"]["title"] = [[`${constants.NAME_SPACE_ORIGINAL}アドオン(UI版)`]];
	Object.entries(obj["parts"]).forEach(([k, v]) => {
		if (typeof v === "string")
			v = convertMyPvPUIEnvVars(v, player, ...args);
		v = v.map(arr_v => arr_v.map(arr_v2 => convertMyPvPUIEnvVars(arr_v2, player, ...args)));
		v.forEach(arr_v => form_data = form_data[k](...arr_v));
	});
	return form_data;
}
/**
 * 
 * @param {Player} player 
 * @param {Object} res 
 * @param {Array} func_arr 
 * @param {Array} add_args_arr 
 */
async function responseProcess(player, res, func_arr = [], add_args_arr = [], len = func_arr.length) {
	if ([func_arr.length, add_args_arr.length].some(v => v === (len - 1))) {
		func_arr.push((async () => null));
		add_args_arr.push([]);
	}
	const func_obj = {
		"func": func_arr,
		"addArgs": add_args_arr
	};
	if (res.selection < func_obj["addArgs"].length && res.selection < func_obj["func"].length)
		await func_obj["func"][res.selection](player.target, ...func_obj["addArgs"][res.selection]);
	else
		player.tell(`選択番号が定義されたオブジェクトの配列長を超えたため、\n処理を中止しました\n${res.selection}, ${func_obj["addArgs"].length}, ${func_obj["func"].length}`);
}


export async function showMenu(p, menu_type = "top", ...args) {
	const player = Player.findOnlinePlayer(p.id);
	if (!player)
		return;
	const formDataFunc = async (after_func = () => null) => {
		const form_data = createFormData(player, UI__GSO["settingData"][menu_type], ...args);
		const res = await form_data.show(p);
		after_func(player, res, ...args);
		return res;
	};
	switch (menu_type) {
		case "top": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			await responseProcess(player, res, [
				async (...a) => await showMenu(...a),	// topTeam
				async (...a) => await showMenu(...a),	// topMatchType
				async (...a) => await showMenu(...a),	// topMatchEdit
				async (...a) => await showMenu(...a),	// topMatchWatch
				async (...a) => await showMenu(...a),	// topInfo
				async (...a) => await showMenu(...a),	// topSuggestOrClaim
			], [
				["topTeam"],
				["topMatchType"],
				["topMatchEdit"],
				["topMatchWatch"],
				["topInfo"],
				["topSuggestOrClaim"]
			], 7);
			break;
		}
		case "topMatchType": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			await responseProcess(player, res, [
				async (...a) => await showMenu(...a),	// pvp
				async (...a) => await showMenu(...a),	// tvt
				async (...a) => await showMenu(...a),	// pve
				async (...a) => await showMenu(...a)	// tve
			], [
				["selectOnlinePlayers", Object.values(ONLINE_PLAYERS), "pvp"],
				["selectAllMyTeams", Team.getAllMyTeamArray(player.id), "tvt"],
				["selectAllFields", null, "pve"],
				["selectAllMyTeams", Team.getAllMyTeamArray(player.id), "tve"]
			], 5);
			break;
		}
		case "topTeam": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			await responseProcess(player, res, [
				async (...a) => await showMenu(...a),	// crtm
				async (...a) => await showMenu(...a),	// rmtm
				async (...a) => await showMenu(...a),	// admm
				async (...a) => await showMenu(...a),	// rmmm
			], [
				["inputTeamID", null, "crtm"],
				["selectAllMyTeams", Team.getAllMyTeamArray(player.id), "rmtm"],
				["selectOnlineTeams", Object.values(ALL_TEAMS_HISTORY), "admm"],
				["selectOnlineTeams", Object.values(ALL_TEAMS_HISTORY), "rmmm"],
			], 5);
			break;
		}
		case "topMatchEdit": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			await responseProcess(player, res, [
				async (...a) => await showMenu(...a),	// accept
				async (...a) => await showMenu(...a),	// cancel
			], [
				["selectAllMyMatches", Match.getMyWMArray(player.id, "p"), "accept"],
				["selectAllMyMatches", Match.getMyWMArray(player.id, "a"), "cancel"]
			], 3);
			break;
		}
		case "topMatchWatch": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			await responseProcess(player, res, [
				async (...a) => await showMenu(...a),	// watch
			], [
				["selectAllFields", null, "watch"],
			], 2);
			break;
		}
		case "topInfo": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			await responseProcess(player, res, [
				async (...a) => await showMenu(...a),	// info_p
				async (...a) => await showMenu(...a),	// info_t
				async (...a) => await showMenu(...a),	// info_m
			], [
				["selectAllPlayers", Object.values(ALL_PLAYERS_HISTORY), "info_p"],
				["selectAllTeams", Object.values(ALL_TEAMS_HISTORY), "info_t"],
				["inputMatchID", Object.values(ALL_MATCHES_HISTORY), "info_m"],
			], 4);
			break;
		}
		case "topSuggestOrClaim": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_idx, ttl_str, msg_str] = res.formValues;
			const summary_str = UI__GSO_DEFINE.settingData.topClaimOrSuggest.parts.dropdown[0][_idx]?.name;
			if (!summary_str)
				return player.tell(`summary_strが不正な値です。大至急アドオン制作者に連絡してください`, "err");
			if (![ttl_str, msg_str].every((_str, i) => constants.isInRange(UI__GSO_DEFINE.settingData.topClaimOrSuggest.parts.textField[i].min, _str.length, UI__GSO_DEFINE.settingData.topClaimOrSuggest.parts.textField[i].max)))
				return player.tell(`タイトルまたは本文の文字数が長すぎます`, "err");
			if (!constants.DEBUG_MODE)
				return player.tell(`こちらの機能は未実装です`, "err");
			const _str = JSON.stringify({
				summary: summary_str,
				title: ttl_str,
				message: msg_str
			});
			player.cmd(["scriptevent", constants.NS("http_send_data", "dashmcsrv"), _str].join(" "));
			break;
		}
		case "selectAllMyMatches": {
			if (!args[0].length)
				return player.tell(`試合が見つかりませんでした`, "err");
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_idx] = res.formValues;
			const match = args[0][_idx];
			if (!match)
				return player.tell(`指定された試合が見つかりませんでした`, "err");
			const mode = args[1];
			if (mode === "accept")
				player.cmd(`${constants.NS(mode)} ${match.originalID}`);
			else if (mode === "cancel")
				player.cmd(`${constants.NS(mode)} ${match.originalID}`);
			else
				player.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "selectAllMyTeams": {
			if (!args[0].length)
				return player.tell(`チームが見つかりませんでした`, "err");
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_idx] = res.formValues;
			const team = args[0][_idx];
			if (!team)
				return player.tell(`チームが見つかりませんでした`, "err");
			const mode = args[1];
			if (mode === "rmtm")
				player.cmd(`${constants.NS(mode)} ${team.id}`);
			else if (mode === "tvt")
				await showMenu(p, "selectOnlineTeams", Object.values(ALL_TEAMS_HISTORY), mode, team);
			else if (mode === "tve")
				await showMenu(p, "selectAllFields", null, mode, team);
			else
				player.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "selectAllFields": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_idx] = res.formValues;
			const mode = args[1];
			if (mode === "watch") {
				if (player.isWatching) {
					// 観戦から離脱
					if (player.tag(MyPvPEntityRepository.joinedArr([`F${_idx}`, player.status], 1), 0)) {
						player.cmd(`${constants.NS(mode)} "${_idx}" false`);
						break;
					} else
						for (let i = 0; i < BATTLE_FIELDS_COUNT; i++)
							if (i !== _idx && player.tag(MyPvPEntityRepository.joinedArr([`F${i}`, player.status], 1), 0))
								player.cmd(`${constants.NS(mode)} "${i}" false`);
				}
				player.cmd(`${constants.NS(mode)} "${_idx}" true`);
			} else if (mode === "pve") {
				await showMenu(p, "inputMatchID", [], mode, _idx);
			} else if (mode === "tve") {
				await showMenu(p, "inputMatchID", [], mode, args[2], _idx);
			} else if (mode === "pvp") {
				await showMenu(p, "inputMatchID", [], mode, args[2], _idx);
			} else if (mode === "tvt") {
				await showMenu(p, "inputMatchID", [], mode, args[2], args[3], _idx);
			} else
				wld.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "selectAllPlayers": {
			if (!args[0].length)
				return player.tell(`プレイヤーが見つかりませんでした`, "err");
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_idx] = res.formValues;
			const target = args[0][_idx];
			if (!target)
				return player.tell(`指定されたプレイヤーを見つけられませんでした`, "err");
			const mode = args[1];
			if (mode === "info_p")
				await showMenu(p, "displayText", target.outputData(), mode);
			else if (["admm", "rmmm"].some(_m => mode === _m))
				player.cmd(`${constants.NS(mode)} ${args[2]?.id} ${target?.name}`);
			else
				player.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "selectAllTeams": {
			if (!args[0].length)
				return player.tell(`チームが見つかりませんでした`, "err");
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_idx] = res.formValues;
			const team = args[0][_idx];
			if (!team)
				return player.tell(`指定されたチームを見つけられませんでした`, "err");
			const mode = args[1];
			if (mode === "info_t")
				await showMenu(p, "displayText", team.outputData(), mode);
			else
				player.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "selectOnlinePlayers": {
			if (!args[0].length)
				return player.tell(`プレイヤーが見つかりませんでした`, "err");
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_idx] = res.formValues;
			const target = args[0][_idx];
			if (!target)
				return player.tell(`指定されたプレイヤーを見つけられませんでした`, "err");
			const mode = args[1];
			if (mode === "pvp")
				await showMenu(p, "selectAllFields", null, mode, target);
			else
				player.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "selectOnlineTeams": {
			if (!args[0].length)
				return player.tell(`チームが見つかりませんでした`, "err");
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_idx] = res.formValues;
			const team = args[0][_idx];
			if (!team)
				return player.tell(`指定されたチームを見つけられませんでした`, "err");
			const mode = args[1];
			if (mode === "tvt")
				await showMenu(p, "selectAllFields", null, mode, args[1], team);
			else if (mode === "rmtm")
				player.cmd(`${constants.NS(mode)} ${team.id}`);
			else if (["admm", "rmmm"].some(_m => mode === _m))
				await showMenu(p, "selectAllPlayers", Object.values(ALL_PLAYERS_HISTORY), mode, team);
			else
				player.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "inputTeamID": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_txt] = res.formValues;
			const mode = args[1];
			if (mode === "crtm")
				await showMenu(p, "inputTeamName", null, mode, _txt);
			else
				player.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "inputTeamName": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_txt] = res.formValues;
			const mode = args[1];
			if (mode === "crtm")
				player.cmd(`${constants.NS(mode)} ${args[2]} ${_txt}`);
			else
				player.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "inputMatchID": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			const [_txt] = res.formValues;
			const mode = args[1];
			if (mode === "info_m") {
				const text_arr = Match.getMatchArrayByOriginalID(_txt, player.id).map(m => m.outputData());
				await showMenu(p, "displayText", text_arr.join("\n\n"), mode);
			} else if (mode === "pvp")
				player.cmd(`${constants.NS(mode)} ${args[2]?.name} "${args[3]}" ${_txt}`);
			else if (mode === "tvt")
				player.cmd(`${constants.NS(mode)} ${args[2]?.id} ${args[3]?.id} "${args[4]}" ${_txt}`);
			else if (mode === "pve")
				player.cmd(`${constants.NS(mode)} "${args[2]}" ${_txt}`);
			else if (mode === "tve")
				player.cmd(`${constants.NS(mode)} ${args[2]?.id} "${args[3]}" ${_txt}`);
			else
				player.tell(`不明なmode: ${mode}`, "err");
			break;
		}
		case "displayText": {
			const res = await formDataFunc();
			if (res.canceled)
				return;
			await responseProcess(player, res, [], [], 1);
			break;
		}
		default: {
			player.tell(`メニュータイプが特定できませんでした\nmenu_type: ${menu_type}`, "err");
			break;
		}
	}
	return;
}

