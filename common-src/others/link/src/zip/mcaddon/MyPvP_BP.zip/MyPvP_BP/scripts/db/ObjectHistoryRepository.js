import constants from "./../config/constants";
import { BATTLE_FIELDS_COUNT } from "./../config/Common_GlobalSetting";

export const ALL_PLAYERS_HISTORY = new Object();
export const ALL_TEAMS_HISTORY = new Object();
export const ALL_MATCHES_HISTORY = new Object();
export const ALL_FIELDS_HISTORY = new Object();

export const ONLINE_PLAYERS = new Object();

export const WAIT_MATCHES = new Array(BATTLE_FIELDS_COUNT).fill(0).map(c => ({ waiting: [], pending: [] }));

export let UPDATE_ONLINE_PLAYERS_FUNCTION_ARRAY = [];

export const OH_KEYS = {
	"APH": constants.NS("playersHistory", "OH"),
	"ATH": constants.NS("teamsHistory", "OH"),
	"AMH": constants.NS("matchesHistory", "OH"),
	"AFH": constants.NS("fieldsHistory", "OH"),
	"WM": constants.NS("waitMatches", "OH")
};

export function ALL_HISTORY_SAVE_FUNC(mypvp_entity) {
	mypvp_entity.set(OH_KEYS["APH"], ALL_PLAYERS_HISTORY);
	mypvp_entity.set(OH_KEYS["ATH"], ALL_TEAMS_HISTORY);
	mypvp_entity.set(OH_KEYS["AMH"], ALL_MATCHES_HISTORY);
	mypvp_entity.set(OH_KEYS["AFH"], ALL_FIELDS_HISTORY);
	mypvp_entity.set(OH_KEYS["WM"], WAIT_MATCHES);
}


export function updateOnlinePlayerLength() {
	const len = Object.values(ONLINE_PLAYERS).filter(p => p?.isMCPlayer).length;
	UPDATE_ONLINE_PLAYERS_FUNCTION_ARRAY.forEach(f => {
		if (typeof f === "function")
			f(len);
	});
}