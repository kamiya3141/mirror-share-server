import { system } from "@minecraft/server";

import { Command } from "./../command/Command";

system.afterEvents.scriptEventReceive.subscribe(ev => {
	Command.scriptEventSubscribe(ev);
});
system.beforeEvents.startup.subscribe(ev => {
	Command.CommandDataObject.enum.forEach(obj => ev.customCommandRegistry.registerEnum(obj.name, obj.data));
	Object.entries(Command.CommandDataObject.data).forEach(([cmd_name, obj]) =>
		new Command(
			cmd_name,
			obj.d,
			obj.p,
			obj.m,
			obj.o
		).customCommandSubscribe(ev)
	);
});
