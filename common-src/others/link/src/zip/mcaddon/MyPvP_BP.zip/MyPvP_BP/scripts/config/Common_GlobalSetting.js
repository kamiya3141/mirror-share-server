import constants from "./constants";

export let RANKING_BOARD_PLAYER_LENGTH = 3;

export let BATTLE_FIELDS_COUNT = 3;

const teamIdLengthMinMax = constants.createMinMaxObject(3, constants.CALC_MCC(2));
const teamNameLengthMinMax = constants.createMinMaxObject(2, constants.CALC_MCC(2));
const matchIdLengthMinMax = constants.createMinMaxObject(3, constants.CALC_MCC(5));

export const LOBBY_LOCATION = {
	x: 0,
	y: 0,
	z: 0
};

/**@summary Global Settings Object */
export const GSO = {
	limit: {
		team: {
			id: {
				reg_str: "0-9a-zA-Z",
				reg: new RegExp(
					`^[0-9a-zA-Z]{${teamIdLengthMinMax.min},${teamIdLengthMinMax.max}}$`
				),
				length: teamIdLengthMinMax
			},
			name: {
				reg_str: "全ての文字",
				reg: new RegExp(
					`^.{${teamNameLengthMinMax.min},${teamNameLengthMinMax.max}}$`
				),
				length: teamNameLengthMinMax
			},
			member: constants.createMinMaxObject(1, constants.CALC_MCC(4))
		},
		match: {
			id: {
				reg_str: "0-9a-zA-Z",
				reg: new RegExp(
					`^[0-9a-zA-Z]{${matchIdLengthMinMax.min},${matchIdLengthMinMax.max}}$`
				),
				length: matchIdLengthMinMax
			},
			time: {
				before_fighting: {
					min: 0,
					mid: 3,
					max: 5
				},
				pre_fighting:
				{
					min: 3,
					mid: (constants.DEBUG_MODE ? 5 : 10),
					max: (constants.DEBUG_MODE ? 10 : 45)
				},
				fighting: {
					min: 10,
					mid: 1 * 60,
					max: (constants.DEBUG_MODE ? 5 : 10) * 60
				},
				finished: {
					min: 0,
					mid: 3,
					max: 5
				},
				canceled: {
					min: 0,
					mid: 3,
					max: 5
				}
			}
		},
		field: [
			{
				name: "世界樹の町",
				id: "bf-1",
				enemy: {
					typeId: constants.NS("terrorist", "cso"),
					typeId0: constants.NS("zombie", "minecraft"),
					typeId1: constants.NS("iron_golem", "minecraft"),
					material: "iron"
				},
				location: {
					before_fighting: [
						[
							LOBBY_LOCATION
						],
						[
							LOBBY_LOCATION
						],
						[
							{
								x: 0,
								y: -50,
								z: 0
							},
							{
								x: 4,
								y: -50,
								z: 4
							},
							{
								x: -4,
								y: -50,
								z: 4
							},
							{
								x: 4,
								y: -50,
								z: -4
							},
							{
								x: -4,
								y: -50,
								z: -4
							}
						]
					],
					pre_fighting: [
						[
							{
								x: 76,
								y: 65,
								z: 281
							}
						],
						[
							{
								x: 0,
								y: 65,
								z: 324
							}
						],
						[
							{
								x: 0,
								y: 65,
								z: 324
							}
						]
					],
					fighting: [
						[
							{
								x: 76,
								y: 2,
								z: 281
							},
							{
								x: 76,
								y: 1,
								z: 311
							},
							{
								x: 96,
								y: 2,
								z: 281
							},
							{
								x: 76,
								y: 1,
								z: 256
							},
							{
								x: 48,
								y: 2,
								z: 281
							}
						],
						[
							{
								x: 0,
								y: 6,
								z: 324
							},
							{
								x: 0,
								y: 11,
								z: 356
							},
							{
								x: 31,
								y: 2,
								z: 324
							},
							{
								x: 0,
								y: 2,
								z: 296
							},
							{
								x: -28,
								y: 11,
								z: 324
							}
						],
						[
							{
								x: 0,
								y: 6,
								z: 324
							}
						]
					],
					finished: [
						[
							LOBBY_LOCATION
						],
						[
							LOBBY_LOCATION
						],
						[
							{
								x: 0,
								y: -32,
								z: 0
							},
							{
								x: 4,
								y: -32,
								z: 4
							},
							{
								x: -4,
								y: -32,
								z: 4
							},
							{
								x: 4,
								y: -32,
								z: -4
							},
							{
								x: -4,
								y: -32,
								z: -4
							}
						]
					],
					canceled: [
						[
							LOBBY_LOCATION
						],
						[
							LOBBY_LOCATION
						],
						[
							{
								x: 0,
								y: -32,
								z: 0
							},
							{
								x: 4,
								y: -32,
								z: 4
							},
							{
								x: -4,
								y: -32,
								z: 4
							},
							{
								x: 4,
								y: -32,
								z: -4
							},
							{
								x: -4,
								y: -32,
								z: -4
							}
						]
					]
				}
			},
			{
				name: "戦場 2",
				id: "bf-2",
				enemy: {
					typeId: constants.NS("terrorist", "cso"),
					typeId0: constants.NS("zombie", "minecraft"),
					typeId1: constants.NS("iron_golem", "minecraft"),
					material: "diamond"
				},
				location: {
					before_fighting: [
						[
							LOBBY_LOCATION
						],
						[
							LOBBY_LOCATION
						],
						[
							{
								x: 0,
								y: -50,
								z: 0
							},
							{
								x: 4,
								y: -50,
								z: 4
							},
							{
								x: -4,
								y: -50,
								z: 4
							},
							{
								x: 4,
								y: -50,
								z: -4
							},
							{
								x: -4,
								y: -50,
								z: -4
							}
						]
					],
					pre_fighting: [
						[
							{
								x: 129,
								y: 1,
								z: -10
							}
						],
						[
							{
								x: 133,
								y: 1,
								z: -24
							}
						],
						[
							{
								x: 133,
								y: 1,
								z: -24
							}
						]
					],
					fighting: [
						[
							{
								x: 128,
								y: 0,
								z: -17
							}
						],
						[
							{
								x: 134,
								y: 0,
								z: -17
							}
						],
						[
							{
								x: 134,
								y: 0,
								z: -17
							}
						]
					],
					finished: [
						[
							LOBBY_LOCATION
						],
						[
							LOBBY_LOCATION
						],
						[
							{
								x: 0,
								y: -32,
								z: 0
							},
							{
								x: 4,
								y: -32,
								z: 4
							},
							{
								x: -4,
								y: -32,
								z: 4
							},
							{
								x: 4,
								y: -32,
								z: -4
							},
							{
								x: -4,
								y: -32,
								z: -4
							}
						]
					],
					canceled: [
						[
							LOBBY_LOCATION
						],
						[
							LOBBY_LOCATION
						],
						[
							{
								x: 0,
								y: -32,
								z: 0
							},
							{
								x: 4,
								y: -32,
								z: 4
							},
							{
								x: -4,
								y: -32,
								z: 4
							},
							{
								x: 4,
								y: -32,
								z: -4
							},
							{
								x: -4,
								y: -32,
								z: -4
							}
						]
					]
				}
			},
			{
				name: "大聖堂",
				id: "cathedral",
				enemy: {
					typeId: constants.NS("terrorist", "cso"),
					typeId0: constants.NS("zombie", "minecraft"),
					typeId1: constants.NS("iron_golem", "minecraft"),
					material: "netherite"
				},
				location: {
					before_fighting: [
						[
							LOBBY_LOCATION
						],
						[
							LOBBY_LOCATION
						],
						[
							{
								x: 0,
								y: -50,
								z: 0
							},
							{
								x: 4,
								y: -50,
								z: 4
							},
							{
								x: -4,
								y: -50,
								z: 4
							},
							{
								x: 4,
								y: -50,
								z: -4
							},
							{
								x: -4,
								y: -50,
								z: -4
							}
						]
					],
					pre_fighting: [
						[
							{
								x: 1105,
								y: 33,
								z: 1093
							}
						],
						[
							{
								x: 1217,
								y: 33,
								z: 1124
							}
						],
						[
							{
								x: 1217,
								y: 33,
								z: 1124
							}
						]
					],
					fighting: [
						[
							{
								x: 1105,
								y: 4,
								z: 1093
							}
						],
						[
							{
								x: 1217,
								y: 4,
								z: 1124
							}
						],
						[
							{
								x: 1217,
								y: 4,
								z: 1124
							}
						]
					],
					finished: [
						[
							LOBBY_LOCATION
						],
						[
							LOBBY_LOCATION
						],
						[
							{
								x: 0,
								y: -32,
								z: 0
							},
							{
								x: 4,
								y: -32,
								z: 4
							},
							{
								x: -4,
								y: -32,
								z: 4
							},
							{
								x: 4,
								y: -32,
								z: -4
							},
							{
								x: -4,
								y: -32,
								z: -4
							}
						]
					],
					canceled: [
						[
							LOBBY_LOCATION
						],
						[
							LOBBY_LOCATION
						],
						[
							{
								x: 0,
								y: -32,
								z: 0
							},
							{
								x: 4,
								y: -32,
								z: 4
							},
							{
								x: -4,
								y: -32,
								z: 4
							},
							{
								x: 4,
								y: -32,
								z: -4
							},
							{
								x: -4,
								y: -32,
								z: -4
							}
						]
					]
				}
			}
		]
	}
};

export const ALLOW_START_SERVER = (() => {
	let bool = true;
	const cond_arr = [
		GSO.limit.field.length === BATTLE_FIELDS_COUNT,
		GSO.limit.field.every(f =>
			["pre_fighting", "fighting", "finished"].every(k =>
				Boolean(Object.hasOwn(f.location, k) && f.location[k].length === BATTLE_FIELDS_COUNT)
			)
		)
	];
	cond_arr.forEach(c => bool &&= Boolean(c));
	return bool;
})();