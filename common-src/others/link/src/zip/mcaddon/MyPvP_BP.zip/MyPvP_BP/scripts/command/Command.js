import { system } from "@minecraft/server";

import constants from "./../config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "./../config/Common_GlobalSetting";
import { ONLINE_PLAYERS, updateOnlinePlayerLength } from "../db/ObjectHistoryRepository";
import { wld } from "./../world/World";
import { Player } from "./../player/Player";
import { Team } from "./../team/Team";
import { Match } from "./../match/Match";
import { showMenu } from "./../ui/UI";

export class Command {
	constructor (name, desc, plv = 0, mprm = [], oprm = []) {
		this.name = name;
		this.desc = desc ?? "No Description.";
		this.plv = plv;
		this.mprm = mprm;
		this.oprm = oprm;
	}
	customCommandSubscribe(ev) {
		if (!this.name) return;
		ev.customCommandRegistry.registerCommand(
			{
				name: constants.NS(this.name),
				description: `${Command.CommandDataObject.descriptionHeader}: ${this.desc}`,
				permissionLevel: this.plv,
				mandatoryParameters: this.mprm,
				optionalParameters: this.oprm
			},
			(origin, ...args) => {
				const target = origin.sourceEntity;
				Command.exec(target, this.name, false, ...args);
				return { status: 0 };
			}
		);
	}
	static scriptEventSubscribe(ev) {
		const target = ev.sourceEntity;
		const cmd = String(ev.id).replaceAll(
			constants.NS("", constants.NAME_SPACE, false),
			""
		);
		const args = this.parseArgs(ev.message);

		Command.exec(target, cmd, true, args);
	}
	static exec(target, cmd, fromScriptEvent = false, ...args) {
		if (!Object.hasOwn(this.CommandDataObject.data, cmd))
			return;
		let stop_processing_flag = false;
		const org_args_arr = [...Command.CommandDataObject.data[cmd].m, ...Command.CommandDataObject.data[cmd].o];
		args = args.map((arg, arg_i) => {
			if (org_args_arr[arg_i].type === "String" || org_args_arr[arg_i].type === "Enum")
				return this.normalizeArgs(arg);
			else if (org_args_arr[arg_i].type === "Integer")
				return Number(arg);
			else if (org_args_arr[arg_i].type === "Boolean")
				return Boolean(arg);
			else if (org_args_arr[arg_i].type === "PlayerSelector")
				return [...arg].map(a_p => a_p?.id);
			else {
				stop_processing_flag = true;
				wld.tell(`未実装のコマンド引数の型が検出されました\n大至急管理者・アドオン制作者に連絡をしてください`, "err");
			}
		});
		if (!stop_processing_flag) {
			if (fromScriptEvent && this.CommandDataObject.data[cmd]?.sc && this.CommandDataObject.data[cmd].sc === false)
				Player.findOnlinePlayerTell(target.id, `このコマンドはScriptEventから実行できません`, "err");
			else
				this.CommandDataObject.data[cmd].f(target, ...args);
		} else
			Player.findOnlinePlayerTell(target.id, `エラーが発生したため、コマンドの処理が中断されました`, "err");
	}
	static normalizeArgs(str = "") {
		return str.replaceAll(`"`, "").replaceAll(`'`, "").replaceAll("`", "");
	}
	static parseArgs(message) {
		return message.trim().split(/\s+/).filter(Boolean);
	}
	static CommandDataObject = {
		descriptionHeader: `[${constants.stl_str(constants.NAME_SPACE.toUpperCase(), "nml")}${constants.RSS}]`,
		enum: [
			{
				name: constants.NS("battle-field"),
				data: new Array(BATTLE_FIELDS_COUNT).fill(0).map((_, _i) => String(_i))
			},
			{
				name: constants.NS("ui__menu-type"),
				data: ["top", "topTeam", "topMatchType", "topMatchEdit", "topMatchWatch", "topInfo", "topSuggestOrClaim"]
			},
			{
				name: constants.NS("rankingboard"),
				data: ["update"]
			},
			{
				name: constants.NS("rmtag"),
				data: ["select", "all"]
			}
		],
		data: {
			crtm: {
				d: "チームを新規作成します",
				p: 0,
				m: [
					{
						type: "String",
						name: "チームID"
					},
					{
						type: "String",
						name: "チーム名"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					const id = args[0];
					const name = args[1];
					if (
						!Team.checkIdString(id, player.id) ||
						!Team.checkNameString(name, player.id)
					)
						return;
					if (String(id).includes(Team.EnemyTeamSymbolStr))
						return player.tell("チームIDにEnemyTeamを含めることはできません", "err");
					if (Team.checkExistTeam(id, target.id, false))
						return player.tell("そのチームIDは既に存在します", "err");
					const team = new Team(id, name, player.id);
					team.saveDB();
				},
				sc: false
			},
			rmtm: {
				d: "チームを削除します",
				p: 0,
				m: [
					{
						type: "String",
						name: "チームID"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					const id = args[0];
					if (
						!Team.checkIdString(id, player.id) ||
						!Team.checkExistTeam(id, player.id)
					)
						return;
					if (String(id).includes(Team.EnemyTeamSymbolStr))
						return player.tell("チームIDにEnemyTeamが含まれたIDを削除することはできません", "err");
					const team = Team.findTeam(id);
					if (team.leader !== player.id)
						return player.tell("チームリーダーが貴方ではないため、チームを削除することができません", "err");
					team.removeTeam();
				},
				sc: false
			},
			admm: {
				d: "チームにメンバーを追加します",
				p: 0,
				m: [
					{
						type: "String",
						name: "チームID"
					},
					{
						type: "PlayerSelector",
						name: "プレイヤー名"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					const id = args[0];
					if (
						!Team.checkIdString(id, player.id) ||
						!Team.checkExistTeam(id, player.id)
					)
						return;
					const player_id_arr = args[1];
					player_id_arr.forEach(player_id => {
						const team = Team.findTeam(id);
						const p = Player.findPlayer(player_id);
						if (!p)
							return player.tell(`指定されたプレイヤーは存在しません`, "err");
						team.addMember(p.id);
						team.saveDB();
					});
				},
				sc: false
			},
			rmmm: {
				d: "チームからメンバーを削除します",
				p: 0,
				m: [
					{
						type: "String",
						name: "チームID"
					},
					{
						type: "PlayerSelector",
						name: "プレイヤー名"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					const id = args[0];
					if (
						!Team.checkIdString(id, player.id) ||
						!Team.checkExistTeam(id, player.id)
					)
						return;
					const player_id_arr = args[1];
					for (const player_id of player_id_arr) {
						const team = Team.findTeam(id);
						const p = Player.findPlayer(player_id);
						if (!p) {
							player.tell(`指定されたプレイヤーは存在しません`, "err");
							continue;
						}
						team.deleteMember(p.id);
						team.saveDB();
					}
				},
				sc: false
			},
			info_p: {
				d: "プレイヤー情報を出力します",
				p: 0,
				m: [
					{
						type: "PlayerSelector",
						name: "プレイヤー名"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					const player_id_arr = args[0];
					player_id_arr.forEach(player_id => {
						const p = Player.findPlayer(player_id);
						if (p)
							p.showData();
					});
				},
				sc: false
			},
			info_t: {
				d: "チーム情報を出力します",
				p: 0,
				m: [
					{
						type: "String",
						name: "チームID"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					const id = args[0];
					if (!Team.checkIdString(id, player.id) || !Team.checkExistTeam(id, player.id))
						return;
					const team = Team.findTeam(id);
					if (team)
						player.tell(team.outputData(), "nml");
					else
						player.tell(`指定されたチームが見つかりませんでした`, "err");
				},
				sc: false
			},
			info_m: {
				d: "試合情報を出力します",
				p: 0,
				m: [
					{
						type: "String",
						name: "試合ID"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					const org_id = args[0];
					const arr = Match.getMatchArrayByOriginalID(org_id, player.id);
					if (arr)
						arr.forEach(m => m.showData());
				},
				sc: false
			},
			pvp: {
				d: "個人試合申請(PvP)を実行します",
				p: 0,
				m: [
					{
						type: "PlayerSelector",
						name: "対戦するプレイヤー名"
					},
					{
						type: "Enum",
						name: constants.NS("battle-field")
					},
					{
						type: "String",
						name: "新規試合ID"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					if (player.isMatching || player.isWatching)
						return player.tell(`観戦中または試合中に試合を申請することはできません`, "err");
					const match_id = args[2];
					if (!Match.checkIdString(match_id, player.id))
						return;
					const player_id_arr = args[0];
					const field_index = args[1];
					if (player_id_arr.length > 1)
						return player.tell(`プレイヤーを2人以上選ぶことはできません`, "err");
					const pid = player_id_arr[0];
					const target_player = Player.findOnlinePlayer(pid);
					if (!target_player)
						return player.tell(`指定されたプレイヤーは存在しません`, "err");
					if (target_player.id === player.id)
						return player.tell(`自分自身を選択することはできません`, "err");
					if (target_player.isMatching || target_player.isWatching)
						return player.tell(`指定されたプレイヤーが観戦中または試合中のとき、試合を申請することはできません`, "err");
					if (!field_index && field_index !== 0)
						return player.tell(`有効な試合会場番号を入力してください`, "err");
					new Match(match_id, field_index, 0, [player.id, target_player.id]);
				},
				sc: false
			},
			tvt: {
				d: "チーム試合申請(TvT)を実行します",
				p: 0,
				m: [
					{
						type: "String",
						name: "申請側チームID"
					},
					{
						type: "String",
						name: "対戦側チームID"
					},
					{
						type: "Enum",
						name: constants.NS("battle-field")
					},
					{
						type: "String",
						name: "新規試合ID"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					if (player.isMatching || player.isWatching)
						return player.tell(`観戦中または試合中に試合を申請することはできません`, "err");
					const match_id = args[3];
					if (!Match.checkIdString(match_id, player.id))
						return;
					const my_team_id = args[0];
					if (!Team.checkExistTeam(my_team_id, null, false))
						return player.tell(`指定された申請チームは存在しません`, "err");
					const target_team_id = args[1];
					if (!Team.checkExistTeam(target_team_id, null, false))
						return player.tell(`指定された対戦チームは存在しません`, "err");
					if (my_team_id === target_team_id)
						return player.tell(`同じチームを選択することはできません`);
					const my_team = Team.findTeam(my_team_id);
					const target_team = Team.findTeam(target_team_id);
					if (my_team.isAllMembersOffline())
						return player.tell(`指定された申請チームが全員オフラインです`, "err");
					if (target_team.isAllMembersOffline())
						return player.tell(`指定された対戦チームが全員オフラインです`, "err");
					if (!my_team.existMember(player.id))
						return player.tell(`申請チームに${player.name}が存在していません`, "err");
					if (my_team.members.some(mid => target_team.members.includes(mid)))
						return player.tell(`各チーム内に同じプレイヤーは存在できません`, "err");
					const field_index = Number(args[2]);
					if (!field_index && field_index !== 0)
						return player.tell(`有効な試合会場番号を入力してください`, "err");
					new Match(match_id, field_index, 1, [my_team_id, target_team_id]);
				},
				sc: false
			},
			pve: {
				d: "個人・敵Mob間試合申請(PvE)を実行します",
				p: 0,
				m: [
					{
						type: "Enum",
						name: constants.NS("battle-field")
					},
					{
						type: "String",
						name: "新規試合ID"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					if (player.isMatching || player.isWatching)
						return player.tell(`観戦中または試合中に試合を申請することはできません`, "err");
					const match_id = args[1];
					if (!Match.checkIdString(match_id, player.id))
						return;
					const field_index = args[0];
					const pid = player.id;
					if (!field_index && field_index !== 0)
						return player.tell(`有効な試合会場番号を入力してください`, "err");
					system.run(() => {
						const target_player = Match.spawnEnemy(field_index);
						const match = new Match(match_id, field_index, 2, [pid, target_player.id]);
						match.matchingAccepted();
					});
				},
				sc: false
			},
			tve: {
				d: "チーム・敵Mob間試合申請(TvE)を実行します",
				p: 0,
				m: [
					{
						type: "String",
						name: "申請側チームID"
					},
					{
						type: "Enum",
						name: constants.NS("battle-field")
					},
					{
						type: "String",
						name: "新規試合ID"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					if (player.isMatching || player.isWatching)
						return player.tell(`観戦中または試合中に試合を申請することはできません`, "err");
					const match_id = args[2];
					if (!Match.checkIdString(match_id, player.id))
						return;
					const my_team_id = args[0];
					if (!Team.checkExistTeam(my_team_id, null, false))
						return player.tell(`指定された申請チームは存在しません`, "err");
					const field_index = Number(args[1]);
					if (!field_index && field_index !== 0)
						return player.tell(`有効な試合会場番号を入力してください`, "err");
					system.run(() => {
						const my_team_members_length = Team.findTeam(my_team_id)?.members.length ?? 3;
						const amount = Math.min(((my_team_members_length * (field_index + 1)) + 1), constants.CALC_MCC(0.75));
						const target_team = Match.spawnTeamEnemy(field_index, amount);
						const match = new Match(match_id, field_index, 3, [my_team_id, target_team.id]);
						match.matchingAccepted();
					});
				},
				sc: false
			},
			accept: {
				d: "試合申請の受諾を実行します",
				p: 0,
				m: [
					{
						type: "String",
						name: "試合ID"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					if (player.isMatching || player.isWatching)
						return player.tell(`観戦中または試合中に試合申請を受諾することはできません`, "err");
					const match_id = args[0];
					const match = Match.getMyWMArray(player.id, "p").find(m => m.originalID === match_id);
					if (!match)
						return player.tell(`申請記録から試合IDが見つかりませんでした`, "err");
					if (!match.isInTeamsPidArr(player.id) || match.teams_pid_arr[0].includes(player.id))
						return player.tell(`受諾権限がありません`, "err");
					if (match.isTeleporting)
						return player.tell(`テレポート中に試合の受諾はできません`, "err");
					match.matchingAccepted();
				},
				sc: false
			},
			cancel: {
				d: "試合申請の拒否を実行します",
				p: 0,
				m: [
					{
						type: "String",
						name: "試合ID"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					const match_id = args[0];
					const match = Match.findIdWM(match_id);
					if (!match)
						return player.tell(`申請記録から試合IDが見つかりませんでした`, "err");
					if (!match.isInTeamsPidArr(player.id))
						return player.tell(`棄却権限がありません`, "err");
					if (match.isFinished || match.isCanceled)
						return player.tell(`指定された試合は既に終了したか棄却済みです`, "err");
					if (match.isTeleporting)
						return player.tell(`テレポート中に試合の棄却はできません`, "err");
					match.matchingCanceled();
				},
				sc: false
			},
			watch: {
				d: "観戦状態へと移行します",
				p: 0,
				m: [
					{
						type: "Enum",
						name: constants.NS("battle-field")
					},
					{
						type: "Boolean",
						name: "観戦モード"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target.id);
					if (!player) return;
					if (player.isMatching)
						return player.tell(`試合中に観戦はできません`, "err");
					const field_index = Number(args[0]);
					if (!field_index && field_index !== 0)
						return player.tell(`有効な試合会場番号を入力してください`, "err");
					const mode = args[1];
					if (player.isWatching && mode)
						return player.tell(`既に観戦モードです`, "err");
					if (player.isIdling && !mode)
						return player.tell(`まだ観戦モードではありません`, "err");
					player.watching(field_index, mode);
				},
				sc: false
			},
			ui: {
				d: `${constants.NAME_SPACE_ORIGINAL}のUIを開きます`,
				p: 0,
				m: [],
				o: [
					{
						type: "PlayerSelector",
						name: "実行元のプレイヤー名"
					},
					{
						type: "Enum",
						name: constants.NS("ui__menu-type")
					}
				],
				f: (target, ...args) => {
					const player_id_arr = args.length > 0 ? args[0] : [target?.id];
					try {
						const player = Player.findOnlinePlayer(target?.id);
						if (!player_id_arr)
							return player?.tell(`プレイヤーが検出できませんでした`, "err");
						if (player_id_arr && player_id_arr.length > 1)
							return player?.tell(`プレイヤーを2人以上選ぶことはできません`, "err");
					} catch { return; }
					const pid = player_id_arr[0];
					const target_player = Player.findOnlinePlayer(pid);
					const menu_type = args.length === 2 ? args[1] : "top";
					if (target_player)
						system.run(async () => await showMenu(target_player.target, menu_type));
				},
				sc: true
			},
			rankingboard: {
				d: `ロビーのランキングボードを更新します`,
				p: 0,
				m: [],
				o: [
					{
						type: "PlayerSelector",
						name: "実行元のプレイヤー名"
					},
					{
						type: "Enum",
						name: constants.NS("rankingboard")
					}
				],
				f: (target, ...args) => {

					const player_id_arr = args.length > 0 ? args[0] : [target?.id];
					try {
						const player = Player.findOnlinePlayer(target?.id);
						if (!player_id_arr)
							return player?.tell(`プレイヤーが検出できませんでした`, "err");
						if (player_id_arr && player_id_arr.length > 1)
							return player?.tell(`プレイヤーを2人以上選ぶことはできません`, "err");
					} catch { return; }
					const pid = player_id_arr[0];
					const target_player = Player.findOnlinePlayer(pid);
					const exec_type = args.length === 2 ? args[1] : "update";
					if (exec_type === "update")
						updateOnlinePlayerLength();
					target_player.tell(`ランキングボードを更新しました`, "nml");
				},
				sc: true
			},
			rmtag: {
				d: `指定されたプレイヤーの指定された文字列を含むタグを消します`,
				p: 0,
				m: [
					{
						type: "Enum",
						name: constants.NS("rmtag")
					}
				],
				o: [
					{
						type: "String",
						name: "タグに含まれる文字"
					}
				],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target?.id);
					if (!player) return;
					const exec_type = args[0];
					if (exec_type === "select") {
						const _str = args.length > 1 ? args[1] : undefined;
						if (!_str)
							return player.tell(`第二引数に有効な文字列が指定されませんでした`, "err");
						player.removeSelectedTags(_str);
					} else if (exec_type === "all") {
						// player.removeAllTags();
						return player.tell(`こちらは実験的機能のためご使用になれません`, "err");
					}
					target_player.tell(`${player.name}のタグを更新しました`, "nml");
				},
				sc: false
			},
			crmp: {
				d: `新しい試合会場の定義をします`,
				p: 2,
				m: [
					{
						type: "String",
						name: "試合会場ID"
					},
					{
						type: "String",
						name: "試合会場名"
					}
				],
				o: [],
				f: (target, ...args) => {
					const player = Player.findOnlinePlayer(target?.id);
					if (!player) return;
					
				},
				sc: false
			}
		}
	};
}
