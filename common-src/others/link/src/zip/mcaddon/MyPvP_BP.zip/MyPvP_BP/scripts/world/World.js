import { system, world } from "@minecraft/server";

import constants from "./../config/constants";
import { WorldRepository } from "./../db/WorldRepository";

export class World extends WorldRepository {
	constructor (id = "world") {
		super(id);
	}
	get dimension() {
		return this.target.getDimension("overworld");
	}
	tell(msg = "", stl = "f") {
		msg = constants.style_str(msg, [[stl, true]]);
		msg = `${constants.stl_str(`[${constants.NAME_SPACE}]`, "f")} ${msg}`;
		this.target.sendMessage(msg);
	}
	cmd(cmd = "") {
		system.run(() => this.dimension.runCommand(cmd));
	}
	playSound(src = "", loc = { x: 0, y: 0, z: 0 }) {
		this.dimension.playSound(src, loc);
	}
	gamerule(rule = "", val) {
		this.target.gameRules[rule] = val;
	}
}

export const wld = new World();
