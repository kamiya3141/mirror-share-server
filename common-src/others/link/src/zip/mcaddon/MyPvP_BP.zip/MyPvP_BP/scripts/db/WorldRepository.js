import { system, world } from "@minecraft/server";

import { DynamicPropertyRepository } from "./DynamicPropertyRepository";

export class WorldRepository extends DynamicPropertyRepository {
	constructor (id = "world") {
		super(world, id);
		return;
	}
}