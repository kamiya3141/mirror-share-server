import constants from "./../config/constants";
import { TimeManager } from "./TimeManager";

export class Timer extends TimeManager {
	/**
	 * 
	 * @param {Timer} T 
	 * @returns 
	 */
	#myFunc = T => null;
	#myEndFunc = () => null;
	#string_option = [Timer.cs_set()];
	/**
	 * 
	 * @param {Number} limit 秒数を指定（内部で1000ミリ秒処理をします）
	 */
	constructor (limit_time = 0, string_option = [], n = 1) {
		super();
		this.endTime = 0;
		this.limit_time = limit_time * 1000;
		this.remainning = this.limit_time;
		this.totalSeconds = this.#calc_totalSeconds();
		this.minutes = this.#calc_minutes();
		this.seconds = this.#calc_seconds();
		this.#string_option = (!string_option || string_option.length === 0) ? [Timer.cs_set()] : [...string_option, Timer.cs_set("err", 0)];
		this.n = n;
	}
	static exFillZero(n = 0, c0 = 2, start = true) {
		return start ? String(n).padStart(c0, "0") : String(n).padEnd(c0, "0");
	}
	static cs_set(c = "f", s = 0) {
		return {
			color_style: c,
			seconds: s
		};
	}
	static ex_cs_set(arr = [[]]) {
		return arr.map(_a => Timer.cs_set(..._a));
	}
	start() {
		this.#calc_endTime();
		this.#subscribeTimer();
	}
	stop() {
		this.#clearTimer();
	}
	reset(with_start = false) {
		this.stop();
		if (with_start)
			this.start();
	}
	set myFunc(fn) {
		this.#myFunc = (_me) => fn(_me);
	}
	set myEndFunc(fn) {
		this.#myEndFunc = () => fn();
	}
	#calc_endTime() {
		this.endTime = this.now + this.limit_time;
	}
	#calc_remaining() {
		this.remaining = Math.max(0, this.endTime - this.now);
	}
	#calc_totalSeconds() {
		this.totalSeconds = Math.ceil(this.remaining / 1000);
	}
	#calc_minutes() {
		this.minutes = Math.floor(this.totalSeconds / 60);
	}
	#calc_seconds() {
		this.seconds = this.totalSeconds % 60;
	}
	#subscribeTimer() {
		this.#calc_remaining();
		this.createInterval(this.n, () => {
			this.remaining -= Math.floor(1000 * this.n);
			this.#calc_totalSeconds();
			this.#calc_minutes();
			this.#calc_seconds();
			if (this.remaining <= 0) {
				this.#myEndFunc();
				this.#clearTimer();
			} else
				this.#myFunc(this);
		});
	}
	#clearTimer() {
		this.removeInterval();
	}
	setStyleOption(str = "") {
		const option = this.#string_option.find(opt => this.seconds > opt.seconds);
		return constants.style_str(str, [[option?.color_style ?? "err", false]]);
	}
	get timeLimitStr() {
		const str = `${Timer.exFillZero(this.minutes)}:${Timer.exFillZero(this.seconds)}`;
		return this.setStyleOption(str);
	}
	get minutesStr() {
		return this.setStyleOption(String(this.minutes));
	}
	get secondsStr() {
		return this.setStyleOption(String(this.seconds));
	}
}