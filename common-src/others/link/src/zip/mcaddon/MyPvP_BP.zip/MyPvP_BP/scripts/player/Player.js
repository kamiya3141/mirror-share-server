import { system, world, EquipmentSlot, ItemStack } from "@minecraft/server";

import constants from "./../config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "./../config/Common_GlobalSetting";
import {
	ALL_PLAYERS_HISTORY,
	ONLINE_PLAYERS,
	ALL_TEAMS_HISTORY,
	ALL_HISTORY_SAVE_FUNC
} from "./../db/ObjectHistoryRepository";
import { wld } from "./../world/World";
import { MyPvPEntityRepository } from "./../db/MyPvPEntityRepository";
import { PlayerRepository } from "./../db/PlayerRepository";
import { MatchRepository } from "./../db/MatchRepository";
import { Team } from "./../team/Team";
import { Match } from "../match/Match";

export class Player extends PlayerRepository {
	constructor (player = null, isRestored = false, restoredData = {}) {
		super(player, isRestored, restoredData);
		if (!this.isMCPlayer)
			this.tag(constants.NS(this.id), 1);
		if (this.isRestored && constants.DEBUG_MODE)
			console.info(`${player.name} のプレイヤーデータを復元しました`);
		if (!this.isRestored)
			this.teams.forEach(tid => {
				if (!Team.findTeam(tid))
					this.leaveTeam = tid;
			});
	}
	static gameModeArray = ["Survival", "Creative", "Adventure", "Spectator"];
	static importantTagsArray = ["worldedit"];
	/**
	 *
	 * @param {String} playerId
	 * @returns {Player}
	 */
	static findPlayer(playerId = "") {
		if (!playerId)
			return undefined;
		return ALL_PLAYERS_HISTORY[playerId];
	}
	/**
	 *
	 * @param {String} playerName
	 * @returns {String?}
	 */
	static getPlayerIdByName(playerName = "", allow_offline = false) {
		const res = Object.values(allow_offline ? ALL_PLAYERS_HISTORY : ONLINE_PLAYERS).find(
			P => P.name === playerName
		)?.id;
		return res;
	}
	/**
	 *
	 * @param {String} playerId
	 * @returns {Player}
	 */
	static findOnlinePlayer(playerId = "") {
		if (!playerId)
			return undefined;
		return ONLINE_PLAYERS[playerId];
	}
	/**
	 * 
	 * @param  {...Player} players 
	 */
	static addOnlinePlayer(...players) {
		const allow_save = players.some(player => !Object.hasOwn(ONLINE_PLAYERS, player.id));
		players.forEach(player => {
			ONLINE_PLAYERS[player.id] = player;
			if (player.isMCPlayer)
				ALL_PLAYERS_HISTORY[player.id] = player;
		});
		if (allow_save)
			ALL_HISTORY_SAVE_FUNC(wld);
	}
	/**
	 * 
	 * @param  {...String} players_ids
	 */
	static delOnlinePlayer(...players_ids) {
		players_ids.forEach(pid => {
			/**@type {Player} */
			const p = ONLINE_PLAYERS[pid];
			if (p.isMCPlayer) {
				p.exist = false;
				ALL_PLAYERS_HISTORY[pid] = p;
			}
			delete ONLINE_PLAYERS[pid];
		});
		ALL_HISTORY_SAVE_FUNC(wld);
	}
	/**
	 *
	 * @param {String} playerId
	 * @returns {Boolean}
	 */
	static findOnlinePlayerIsOffline(playerId = "") {
		return this.findOnlinePlayer(playerId)?.isOffline;
	}
	/**
	 *
	 * @param {String} playerId
	 * @param {String} msg
	 * @param {String} stl
	 * @returns {null}
	 */
	static findOnlinePlayerTell(playerId = "", msg, stl) {
		return this.findOnlinePlayer(playerId)?.tell(msg, stl);
	}
	/**
	 *
	 * @param {String} playerId
	 * @param {String} cmd
	 * @returns {null}
	 */
	static findOnlinePlayerCmd(playerId = "", cmd) {
		return this.findOnlinePlayer(playerId)?.cmd(cmd);
	}
	static sameLocation(org_loc = LOBBY_LOCATION, ...locs) {
		return locs.every(loc => org_loc.x === loc?.x && org_loc.y === loc?.y && org_loc.z === loc?.z);
	}
	get isOffline() {
		return !this.exist;
		// return this.isRestored && !Boolean(Player.findOnlinePlayer(this.id));
	}
	get nameTag() {
		return this.target?.nameTag;
	}
	set nameTag(val = "") {
		try {
			this.target.nameTag = String(val);
		} catch { }
	}
	tell(msg = "", stl = "f") {
		if (this.isOffline || !this.isMCPlayer) return;
		msg = constants.style_str(msg, [[stl, true]]);
		msg = constants.stl_str(`[${constants.NAME_SPACE}]`, "f") + msg;
		this.target?.sendMessage(msg);
	}
	cmd(cmd = "", use_execute_cmd = false) {
		if (this.isOffline) return;
		if (use_execute_cmd)
			wld.cmd(["execute", "as", this.isMCPlayer ? this.name : `@e[tag="${constants.NS(this.id)}"]`, "at", "@s", "run", cmd].join(" "));
		else
			system.run(() => this.target?.runCommand(cmd));
	}
	tag(val = "", mode = 0) {
		if (this.isOffline) return;
		try {
			if (constants.isInRange(-1, mode, 1))
				return [
					v => system.run(() => this.target.removeTag(v)),
					v => this.target.hasTag(v),
					v => system.run(() => this.target.addTag(v))
				][mode + 1](val);
		} catch { }
	}
	getSelectedTags(val = "") {
		if (this.isOffline) return [];
		val = val ?? "";
		let res_arr = [];
		for (const tag of this.target.getTags())
			if (Player.importantTagsArray.every(_drt => !String(tag).includes(_drt)) && String(tag).includes(val))
				res_arr.push(tag);
		return res_arr;
	}
	removeSelectedTags(val = "") {
		if (this.isOffline) return;
		for (const tag of this.getSelectedTags(val))
			this.tag(String(tag), -1);
	}
	removeAllTags() {
		if (this.isOffline) return;
		this.removeSelectedTags("");
	}
	setTitle(ttl = "a", dur = 0, sbttl = "") {
		if (this.isOffline || !this.isMCPlayer) return;
		dur = Number.isNaN(Number(dur)) ? 0 : Number(dur);
		this.target.onScreenDisplay.setTitle(ttl, {
			subtitle: sbttl,
			fadeInDuration: 0,
			stayDuration: dur,
			fadeOutDuration: 0
		});
	}
	setSubtitle(msg = "", stl = "f") {
		if (this.isOffline || !this.isMCPlayer) return;
		// hud_screen.json 2773
		msg = constants.style_str(msg, [[stl, false]]);
		this.setTitle("a", 0, msg);
	}
	playSound(src = "", opt = { volume: 1.0, pitch: 1.0 }) {
		if (this.isOffline || !this.isMCPlayer) return;
		opt = opt ? opt : { volume: 1.0, pitch: 1.0 };
		system.run(() => this.target.playSound(src, opt));
	}
	getGamemode(index = null) {
		if (this.isOffline || !this.isMCPlayer) return;
		const res = this.target.getGameMode();
		return (typeof index === "number" && constants.isInRange(0, index, Player.gameModeArray.length - 1)) ? res === Player.gameModeArray[index] : res;
	}
	setGamemode(mode_index = 0) {
		if (this.isOffline || !this.isMCPlayer) return;
		mode_index = constants.fixInRange(0, mode_index, Player.gameModeArray.length - 1);
		try {
			system.run(() => this.target.setGameMode(Player.gameModeArray[mode_index]));
		} catch { }
	}
	teleport(...locs) {
		if (this.isOffline) return false;
		const loc = locs[constants.random(0, locs.length - 1)];
		try {
			/*loc["dimension"] = wld.dimension;
			system.run(() => this.target.teleport(loc));*/
			this.cmd(["tp", "@s", ...Object.values(loc)].join(" "), true);
		} catch (err) {
			this.tell(`指定座標へのテレポートに失敗しました\nアドオン制作者に連絡してください\n${err}`, "err");
			return false;
		}
		return true;
	}
	setSpawnPoint(...locs) {
		if (this.isOffline || !this.isMCPlayer) return false;
		const loc = locs[constants.random(0, locs.length - 1)];
		try {
			/*loc["dimension"] = wld.dimension;
			system.run(() => this.target.setSpawnPoint(loc));*/
			this.cmd(["spawnpoint", "@s", ...Object.values(loc)].join(" "), true);
		} catch (err) {
			this.tell(`指定座標へのリスポーン設定に失敗しました\nアドオン制作者に連絡してください\n${err}`, "err");
			return false;
		}
		return true;
	}
	kill() {
		try {
			this.target.kill();
		} catch { }
	}
	get inventory() {
		if (this.isOffline || !this.isMCPlayer) return;
		return this.target.getComponent(constants.NS("inventory", "minecraft"));
	}
	get inventoryContainer() {
		if (this.isOffline || !this.isMCPlayer) return;
		const inventory = this.inventory;
		if (!inventory)
			return;
		return inventory.container;
	}
	giveItem(itemId = "", amount = 1, ...args) {
		if (this.isOffline || !this.isMCPlayer) return;
		if (!itemId) return;
		if (args.length)
			this.cmd(["give", "@s", itemId, amount, ...args].join(" "), true);
		else
			this.giveItemForSlot(itemId, amount);
	}
	giveItemForSlot(itemId = "", amount = 1, slot_index) {
		if (this.isOffline || !this.isMCPlayer) return;
		if (!itemId) return;
		slot_index = Number.isInteger(slot_index) ? slot_index : this.inventoryContainer?.firstEmptySlot();
		system.run(() => this.inventoryContainer?.setItem(slot_index ?? 0, new ItemStack(itemId, amount)));
	}
	inventoryClearAll() {
		if (this.isOffline || !this.isMCPlayer) return;
		system.run(() => this.inventoryContainer?.clearAll());
	}
	get equippable() {
		return this.target.getComponent("equippable");
	}
	equipAnyPlace(place = "Head", itemId) {
		if (this.isOffline) return;
		if (!this.equippable || !itemId) return;
		if (!Match.equipmentPlaceArray.some(pl => pl === place)) return;
		this.equippable.setEquipment(EquipmentSlot[place], itemId);
	}
	watching(field_index = 0, mode = false) {
		this.setStatusIndex(mode ? PlayerRepository.watchingIndex : Player.idlingIndex);
		this.tag(MyPvPEntityRepository.joinedArr([`F${field_index}`, this.status], 1), mode ? 1 : -1);
		this.setGamemode(2 + Number(mode));
		const _status = MatchRepository.StatusKindsArray[(mode ? 2 : 0)];
		const _locs = GSO.limit.field[field_index].location[_status][0];
		this.teleport(..._locs);
	}
	setStatusIndex(index = 0) {
		this.status_index = constants.fixInRange(0, index, MyPvPEntityRepository.StatusKindsArray.length - 1);
		return this.status_index;
	}
	addMatchKills(n = 0) {
		if (this.isOffline) return;
		const key = "match_kills";
		if (!this.has(key)) this.set(key, String(0));
		const match_kills = Number(this.get(key)) ?? 0;
		n = Number.isNaN(Number(n)) ? 0 : Number(n);
		const result = match_kills + n;
		this.set(key, String(result));
		return result;
	}
	assignMatchKillsForKill() {
		this.killCount = this.addMatchKills(0);
	}
	outputData() {
		const data = constants.deepCopyObject(this.data);
		return `\n${Object.entries(data).map(arr => {
			const _func = _tid => (Team.findTeam(_tid)?.name ?? String(undefined));
			if (arr[0] === "teams")
				arr[1] = `\n${arr[1].map(tid => {
					if ((String(tid)))
						_func(tid);
				}).join(", \n")}`;
			return arr.join(": ");
		}).join("\n")}`;
	}
	showData() {
		this.tell(this.outputData());
	}
}
