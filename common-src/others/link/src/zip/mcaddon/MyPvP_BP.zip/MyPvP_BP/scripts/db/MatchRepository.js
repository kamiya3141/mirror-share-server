import constants from "./../config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "./../config/Common_GlobalSetting";
import { wld } from "./../world/World";
import { MyPvPEntityRepository } from "./MyPvPEntityRepository";
import {
	ALL_TEAMS_HISTORY,
	ALL_MATCHES_HISTORY
} from "./../db/ObjectHistoryRepository";
import { Player } from "./../player/Player";
import { Team } from "./../team/Team";
import { TimeManager } from "./../time/TimeManager";

export class MatchRepository extends MyPvPEntityRepository {
	#data = {
		id: "",
		field_index: 0,
		type_index: 0,
		teams_id: [],
		teams_pid_arr: [],
		status_index: 0,
		fighting_countdown: 0
	};
	constructor (id = "", field_index = 0, type_index = 0, teams_id = [], isRestored = false, restoredData = {}) {
		field_index = constants.fixInRange(0, field_index, BATTLE_FIELDS_COUNT - 1);
		type_index = constants.fixInRange(0, type_index, MatchRepository.TypeKindsArray.length - 1);
		if (!isRestored)
			id = MatchRepository.createRandomID(id, field_index, type_index, teams_id);
		super(wld.target, constants.NS(id, "match"), isRestored);
		this.#data.id = this.isRestored ? restoredData.id : id;
		this.#data.field_index = this.isRestored ? restoredData.field_index : field_index;
		this.#data.type_index = this.isRestored ? restoredData.type_index : type_index;
		this.#data.teams_id = this.isRestored ? restoredData.teams_id : teams_id;
		this.#data.teams_pid_arr = this.isRestored ? restoredData.teams_pid_arr : new Array(this.teams_id.length).fill(0).map((_, i) => {
			const id = this.teams_id[i];
			if ([0, 2].some(v => this.type_index === v))
				return [id];
			else if ([1, 3].some(v => this.type_index === v))
				return [...Team.findTeam(id).members.filter(mid => {
					const m = Player.findOnlinePlayer(mid);
					return (m && m.isIdling);
				})];
			else
				return wld.tell(`type_indexの範囲外エラーです\ntype_index: ${this.type_index}\nMatchRepository::constructor`);
		});
		this.#data.status_index = this.isRestored ? restoredData.status_index : 0;
		this.saveDB();
	}
	static TypeKindsArray = ["personal-vs-personal", "team-vs-team", "personal-vs-enemy", "team-vs-enemy"];
	static StatusKindsArray = ["before_fighting", "pre_fighting", "fighting", "finished", "canceled"];
	static createTeamID(index = 0) {
		return this.joinedArr([`T${index}`, constants.generateUUID(constants.CALC_MCC(1))], 1);
	}
	static createShortType(type = "", upper = false, lower_only_vs = false) {
		return this.TypeKindsArray.includes(type) ? type.split("-").map(str => ((upper && !(str === "vs" && lower_only_vs)) ? str.toUpperCase() : str)[0]).join("") : type;
	}
	static createRandomID(id = "Example", field_index = 0, type_index = 0, teams_id = []) {
		const res0 = this.joinedArr([`F${field_index}`, this.createShortType(this.TypeKindsArray[type_index], true, true), ...teams_id.map((_, _i) => this.createTeamID(_i))], 1);
		const res1 = this.joinedArr([id, res0], 2);
		return this.joinedArr([res1, TimeManager.MyDate], 3);
	}
	get originalID() {
		let _id = this.id;
		for (let i = 4; i > 1; i--)
			_id = _id.split(MyPvPEntityRepository.IDCH.repeat(i))[0];
		return _id;
	}
	get matchingTagID() {
		let _id = this.id;
		for (let i = 4; i > 1; i--)
			_id = _id.split(MyPvPEntityRepository.IDCH.repeat(i))[Number(Boolean(i === 2))];
		return _id;
	}
	get matchingTime() {
		let _id = this.id;
		for (let i = 4; i > 2; i--)
			_id = _id.split(MyPvPEntityRepository.IDCH.repeat(i))[Number(Boolean(i === 3))];
		return _id;
	}
	loadDB() {
		super.saveDB(this.#loadDB());
		return super.loadDB();
	}
	#loadDB() {
		return this.get("data");
	}
	saveDB(data = null) {
		if (typeof data === "object") Object.assign(this.#data, data);
		super.saveDB(this.#data);
		this.#saveDB();
	}
	#saveDB() {
		this.set("data", this.#data);
		if ([2, 3].every(n => this.type_index !== n))
			ALL_MATCHES_HISTORY[this.id] = this;
	}
	get id() {
		return this.#data.id;
	}
	set id(_id = "") {
		this.#data.id = _id;
		this.saveDB();
	}
	get field_index() {
		return this.#data.field_index;
	}
	get teams_id() {
		return this.#data.teams_id;
	}
	set teams_id(arr = []) {
		this.#data.teams_id = arr;
		this.saveDB();
	}
	get status_index() {
		return this.#data.status_index;
	}
	set status_index(index = 0) {
		this.#data.status_index = index;
		this.saveDB();
	}
	get status() {
		return MatchRepository.StatusKindsArray[this.status_index];
	}
	get type_index() {
		return this.#data.type_index;
	}
	set type_index(index = 0) {
		this.#data.type_index = constants.fixInRange(0, index, MatchRepository.TypeKindsArray.length - 1);
		this.saveDB();
	}
	get type() {
		return MatchRepository.TypeKindsArray[this.type_index];
	}
	get fighting_countdown() {
		return this.#data.fighting_countdown;
	}
	set fighting_countdown(time = 0) {
		this.#data.fighting_countdown = time;
		this.saveDB();
	}
	get teams_pid_arr() {
		return this.#data.teams_pid_arr;
	}
	setTeamsPidArr(i = 0, j = 0, pid = "") {
		i = constants.fixInRange(0, i, this.teams_pid_arr.length - 1);
		j = constants.fixInRange(0, j, this.teams_pid_arr[i].length - 1);
		this.#data.teams_pid_arr[i][j] = pid;
		this.saveDB();
	}
	isInTeamsPidArr(...ids) {
		return this.teams_pid_arr.some(pid_arr => ids.every(id => pid_arr.includes(id)));
	}
}
