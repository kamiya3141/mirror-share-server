import { system, world } from "@minecraft/server";

import constants from "./../config/constants";

export class TimeManager {
	constructor () {
		this.target = new Date();
		this.interval;
	}
	static get MyDate() {
		const d = new Date();
		const ymd_str = [d.getFullYear(), d.getMonth() + 1, d.getDate()].map(c => String(c).padStart(2, "0")).join("-");
		const hms_str = [d.getHours(), d.getMinutes(), d.getSeconds()].map(c => String(c).padStart(2, "0")).join(":");
		return [ymd_str, hms_str].join("--");
	}
	get now() {
		return this.target.getTime();
	}
	createInterval(n = 1, func = () => null) {
		if (n < 1)
			return;
		this.interval = system.runInterval(() => {
			func();
		}, constants.CALC_MCS(n));
	}
	removeInterval() {
		system.clearRun(this.interval);
	}
}