import constants from "./../config/constants";
import { World, wld } from "./../world/World";
import { Player } from "./../player/Player";
import { MyPvPEntityRepository } from "./MyPvPEntityRepository";
import {
	ALL_TEAMS_HISTORY
} from "./../db/ObjectHistoryRepository";
import { TimeManager } from "../time/TimeManager";

export class TeamRepository extends MyPvPEntityRepository {
	#data = {
		id: "",
		name: "",
		leader: "",
		members: [],
		killCount: 0,
		status_index: 0,
		removed: false
	};
	constructor (id = "", name = "", leader = "", status_index = 0, isRestored = false, restoredData = {}) {
		super(wld.target, constants.NS(id, "team"), isRestored);
		this.#data.id = this.isRestored ? restoredData.id : id;
		this.#data.name = this.isRestored ? restoredData.name : name;
		this.#data.leader = this.isRestored ? restoredData.leader : leader;
		this.#data.members = this.isRestored ? restoredData.members : [];
		this.#data.killCount = this.isRestored ? restoredData.killCount : 0;
		this.#data.status_index = this.isRestored ? restoredData.status_index : status_index;
		this.#data.removed = this.isRestored ? restoredData.removed : false;
		this.saveDB();
	}
	static EnemyTeamSymbolStr = "EnemyTeam";
	static createEnemyTeamId(id = "") {
		return `${id}${TeamRepository.EnemyTeamSymbolStr}`;
	}
	static createEnemyTeamName(name = "") {
		return `${name}${TeamRepository.EnemyTeamSymbolStr}Name`;
	}
	get isEnemyTeam() {
		return Boolean(this.id.endsWith(TeamRepository.EnemyTeamSymbolStr));
	}
	loadDB() {
		super.saveDB(this.#loadDB());
		return super.loadDB();
	}
	#loadDB() {
		return this.get("data");
	}
	saveDB(data = null) {
		if (typeof data === "object") Object.assign(this.#data, data);
		super.saveDB(this.#data);
		this.#saveDB();
	}
	#saveDB() {
		this.set("data", this.#data);
		ALL_TEAMS_HISTORY[this.id] = this;
	}
	get id() {
		return this.#data.id;
	}
	set id(id) {
		this.#data.id = id;
		this.saveDB();
	}
	get name() {
		return this.#data.name;
	}
	set name(name) {
		this.#data.name = name;
		this.saveDB();
	}
	get leader() {
		return this.#data.leader;
	}
	set leader(leader) {
		this.#data.leader = leader;
		this.saveDB();
	}
	/**
	 *
	 * @returns {Player[]}
	 */
	get members() {
		return this.#data.members;
	}
	/**
	 *
	 * @param  {Player} member
	 * かなりふさわしくないセッター命名
	 */
	set members(member_id) {
		this.#data.members.push(member_id);
		this.saveDB();
	}
	set delMember(member_id = "") {
		this.#data.members.splice(this.findIndexMember(member_id), 1);
		this.saveDB();
	}
	existMember(member_id = "") {
		return this.members.includes(member_id);
	}
	findMember(member_id = "") {
		const res_id = this.members.find(id => id === member_id);
		return !res_id ? false : Player.findOnlinePlayer(res_id);
	}
	findIndexMember(member_id = "") {
		return this.members.findIndex(id => id === member_id);
	}
	get status_index() {
		return this.#data.status_index;
	}
	set status_index(index = 0) {
		this.#data.status_index = index;
		this.saveDB();
	}
	get status() {
		return MyPvPEntityRepository.StatusKindsArray[this.status_index];
	}
	get removed() {
		return this.#data.removed;
	}
	set removed(bool = false) {
		this.#data.removed = Boolean(bool);
		if (this.isEnemyTeam) {
			this.delete("data");
			delete ALL_TEAMS_HISTORY[this.id];
		} else if (!MyPvPEntityRepository.isRemovedID(this.id))
			this.id = MyPvPEntityRepository.createRemovedID(MyPvPEntityRepository.joinedArr([this.id, TimeManager.MyDate], 3));
	}
}
