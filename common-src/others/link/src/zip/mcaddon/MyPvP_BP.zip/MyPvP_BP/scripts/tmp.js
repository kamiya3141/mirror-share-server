
/*
const wait_matches_data = wld.get(OH_KEYS["WM"]);
wait_matches_data.forEach((bf_obj, i) => {
	Object.entries(bf_obj).forEach(([bf_obj_k, bf_obj_v]) => {
		bf_obj_v.forEach(val => {
			if (Object.hasOwn(val, "data"))
				if (val) {
					const match = ALL_MATCHES_HISTORY[val.data.id];
					if (match && Match.sameMatching(match.originalID, match))
						WAIT_MATCHES[i][bf_obj_k].push(match);
				}
		});
	});
});
wait_matches_data.forEach((bf_obj, i) => {
	Object.keys(bf_obj).forEach(_k => {
		const match = WAIT_MATCHES[i][_k][0];
		if (match.isPreFighting)
			match.matchingPreStart();
		else if (match.isFighting)
			match.matchingStart();
	});
});*/

