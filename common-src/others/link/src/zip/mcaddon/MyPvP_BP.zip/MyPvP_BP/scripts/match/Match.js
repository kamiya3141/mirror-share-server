import { system, ItemStack } from "@minecraft/server";

import constants from "./../config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "./../config/Common_GlobalSetting";
import { MyPvPEntityRepository } from "./../db/MyPvPEntityRepository";
import { MatchRepository } from "./../db/MatchRepository";
import { ALL_HISTORY_SAVE_FUNC, ALL_MATCHES_HISTORY, ALL_TEAMS_HISTORY, updateOnlinePlayerLength, WAIT_MATCHES } from "./../db/ObjectHistoryRepository";
import { wld } from "./../world/World";
import { Timer } from "./../time/Timer";
import { Player } from "./../player/Player";
import { Team } from "./../team/Team";
import { PlayerRepository } from "../db/PlayerRepository";


export class Match extends MatchRepository {
	#teleporting = false;
	constructor (id, field_index, type_index, teams_id, isRestored = false, restoredData = {}) {
		super(id, field_index, type_index, teams_id, isRestored, restoredData);
		this.status_timer = [...MatchRepository.StatusKindsArray].map((lbl, i) => new Timer(i === 2 && this.isRestored && this.isFighting ? this.fighting_countdown : GSO.limit.match.time[lbl].max,
			Timer.ex_cs_set([
				["nml", GSO.limit.match.time[lbl].mid],
				["dng", GSO.limit.match.time[lbl].min]
			])
		));
		if (!this.isRestored)
			this.matchingInit();
	}
	static equipmentPlaceArray = ["Head", "Chest", "Legs", "Feet", "Mainhand", "Offhand"];
	static giveItemBeginTagStr = constants.NS("give_item");
	static equipMatchingWeaponAndArmor(p) {
		if (constants.DEBUG_MODE && !p.getGamemode(1))
			p.getSelectedTags(Match.giveItemBeginTagStr).forEach(tag => {
				const reg_str = constants.NS(".*?", Match.giveItemBeginTagStr);
				const reg = new RegExp(".*", constants.NS(reg_str));
				const bool = reg.test(tag);
				if (bool) {
					const new_tag = tag.replace(Match.giveItemBeginTagStr, "");
					const index = new_tag.indexOf(":");
					const result = [new_tag.slice(0, index), new_tag.slice(index + 1)];
					p.equipAnyPlace(...result);
				}
			});
	}
	static equipNothing(p) {
		if (constants.DEBUG_MODE && !p.getGamemode(1))
			this.equipmentPlaceArray.forEach(place => p.equipAnyPlace(place, undefined));
	}
	static checkIdString(id, pid, allow_error = true) {
		if (GSO.limit.match.id.reg.test(id)) {
			for (const [k, ttl] of [["waiting", "試合"], ["pending", "申請"]]) {
				const _i = WAIT_MATCHES.findIndex(bf_obj => bf_obj[k].some(m => Match.sameMatching(id, m)));
				if (_i > -1)
					return allow_error ? Player.findOnlinePlayerTell(pid, `試合会場番号${_i}の${ttl}待機列にて試合IDが使用されています\n別の試合IDを使用してください`, "err") : false;
			}
			return true;
		} else if (allow_error) {
			Player.findOnlinePlayerTell(
				pid,
				`チームID: ${id}は無効です\n${GSO.limit.match.id.length.min}~${GSO.limit.match.id.length.max}文字の${GSO.limit.match.id.reg_str}のみ登録可能です`,
				"err"
			);
		}
		return false;
	}
	static existIdWM(id) {
		for (const i = 0; i < BATTLE_FIELDS_COUNT; i++) {
			for (const kinds of ["pending", "waiting"]) {
				/**@type {Match[]} */
				const arr = WAIT_MATCHES[i][kinds];
				if (arr.find(m => Match.sameMatching(id, m)))
					return true;
			}
		}
		return false;
	}
	/**
	 * 
	 * @param {String} id 
	 * @returns {Match}
	 */
	static findIdWM(id) {
		for (let i = 0; i < BATTLE_FIELDS_COUNT; i++) {
			for (const kinds of ["pending", "waiting"]) {
				const res = WAIT_MATCHES[i][kinds].find(m => Match.sameMatching(id, m));
				if (res)
					return res;
			}
		}
		return undefined;
	}
	/**
	 * 
	 * @param {String} id
	 * @param {Match} match 
	 */
	static sameMatching(id, match) {
		return id === match.originalID && !MyPvPEntityRepository.isFinishedID(match.id) && !MyPvPEntityRepository.isCanceledID(match.id);
	}
	static spawnEntity(dimension, typeId = "zombie", ...locs) {
		const idx = constants.random(0, locs.length - 1);
		const loc = locs[idx];
		const new_entity = dimension.spawnEntity(typeId, loc);
		return new_entity;
	}
	static EnemyReferIndex = 2;
	static spawnEnemy(field_index = 0, status_index = 0) {
		const locs = GSO.limit.field[field_index].location[MatchRepository.StatusKindsArray[status_index]][this.EnemyReferIndex];
		const new_entity = this.spawnEntity(wld.dimension, GSO.limit.field[field_index].enemy.typeId, ...locs);
		const equippable = new_entity.getComponent(constants.NS("equippable", "minecraft"));
		if (equippable) {
			[
				["Head", "helmet"],
				["Chest", "chestplate"],
				["Legs", "leggings"],
				["Feet", "boots"],
				["Mainhand", "sword"],
				["Offhand", "shield"]
			].forEach((a, i, arr) => equippable.setEquipment(
				a[0],
				new ItemStack(constants.NS((i !== (arr.length - 1) ? `${GSO.limit.field[field_index].enemy.material}_${a[1]}` : a[1]), "minecraft"), 1)
			));
		}
		const new_player_entity = new Player(new_entity);
		Player.addOnlinePlayer(new_player_entity);
		return new_player_entity;
	}
	static spawnTeamEnemy(field_index = 0, amount = 1) {
		const leader_enemy = this.spawnEnemy(field_index, 0);
		if (!leader_enemy || !leader_enemy.id)
			return wld.tell(`TeamEnemyの作成エラー::leader_enemy > undefined`, "err");
		const team = new Team("", "", leader_enemy.id, 0, false, {}, true);
		team.saveDB();
		for (let i = 0; i < amount - 1; i++) {
			const enemy = this.spawnEnemy(field_index, 0);
			team.addMember(enemy.id);
		}
		team.saveDB();
		return team;
	}
	static delMatching(...match_ids) {
		const allow_save = match_ids.some(mch_id => !Object.hasOwn(ALL_MATCHES_HISTORY, mch_id));
		match_ids.forEach(mch_id => {
			if (Object.hasOwn(ALL_MATCHES_HISTORY, mch_id)) {
				/**@type {Match} */
				const m = ALL_MATCHES_HISTORY[mch_id];
				if (m.has("data"))
					m.delete("data");
				delete ALL_MATCHES_HISTORY[mch_id];
			}
		});
		if (allow_save)
			ALL_HISTORY_SAVE_FUNC(wld);
	}
	static getMyWMArray(pid, mode = "a") {
		let res_arr = [];
		let key_arr = ["pending", "waiting"];
		if (mode === "p")
			key_arr.pop();
		else if (mode === "w")
			key_arr.shift();
		for (let i = 0; i < BATTLE_FIELDS_COUNT; i++)
			for (const _key of key_arr)
				res_arr.push(...WAIT_MATCHES[i][_key].filter(m => m.isInTeamsPidArr(pid)));
		return res_arr;
	}
	static getMatchArrayByOriginalID(id, pid, allow_error = true) {
		const org_ids = Object.values(ALL_MATCHES_HISTORY);
		const passed_ids = org_ids.filter(m => String(m.id).includes(id));
		if (!passed_ids && allow_error)
			Player.findOnlinePlayerTell(pid, `試合情報を見つけられませんでした`, "err");
		return passed_ids;
	}
	execMatching_WM_pending(push = true) {
		const _key = "pending";
		if (push) {
			if (!WAIT_MATCHES[this.field_index][_key].find(m => Match.sameMatching(this.originalID, m)))
				WAIT_MATCHES[this.field_index][_key].push(this);
		} else {
			const _idx = WAIT_MATCHES[this.field_index][_key].findIndex(m => Match.sameMatching(this.originalID, m));
			if (_idx > -1)
				WAIT_MATCHES[this.field_index][_key].splice(_idx, 1);
		}
		this.saveDB();
	}
	execMatching_WM_waiting(push = true) {
		const _key = "waiting";
		if (push)
			WAIT_MATCHES[this.field_index][_key].push(this);
		else
			WAIT_MATCHES[this.field_index][_key].shift();
		if (WAIT_MATCHES[this.field_index][_key].length)
			WAIT_MATCHES[this.field_index][_key][0].matchingMovePreFightingRoom();
		this.saveDB();
	}
	get isBeforeFighting() {
		return this.status_index === 0;
	}
	get isPreFighting() {
		return this.status_index === 1;
	}
	get isFighting() {
		return this.status_index === 2;
	}
	get isFinished() {
		return this.status_index === 3 || MyPvPEntityRepository.isCanceledID(this.id);
	}
	get isCanceled() {
		return this.status_index === 4 || MyPvPEntityRepository.isFinishedID(this.id);
	}
	get isTeleporting() {
		return this.#teleporting;
	}
	set isTeleporting(bool = false) {
		this.#teleporting = Boolean(bool);
	}
	setStatusIndex(index = 0) {
		index = constants.fixInRange(0, index, MatchRepository.StatusKindsArray.length - 1);
		this.status_index = index;

		if (this.isCanceled)
			this.tell(`試合がキャンセルされました\nID: ${this.originalID}`, "err");

		let teams_status_index = 0;

		if (this.isBeforeFighting)
			teams_status_index = 1;
		else if (this.isPreFighting || this.isFighting)
			teams_status_index = 2;
		else if (this.isCanceled || this.isFinished) {
			teams_status_index = 0;
			if (Match.sameMatching(this.id, this)) {
				Match.delMatching(this.id);
				if (this.isFinished)
					this.id = MyPvPEntityRepository.createFinishedID(this.id);
				else
					this.id = MyPvPEntityRepository.createCanceledID(this.id);
			}
		}
		this.setStatusTeams(teams_status_index);
	}
	setStatusTeams(index = 0) {
		this.processTeamsPidArr(p => p.setStatusIndex(index), p => p.setStatusIndex(index), true);
	}
	tell(msg = "", stl = "f") {
		this.processTeamsPidArr(p => p.tell(msg, stl));
	}
	requireExistTeams() {
		const result = this.checkExistTeams();
		if (!result) {
			this.tell(`対戦相手を検出できなかったため試合申請を自動でキャンセルします`, "err");
			this.matchingCanceled();
		}
		return result;
	}
	checkExistTeams() {
		return this.teams_id.every(_id => this.processTeams(_id, p => !p?.isOffline, t => !t?.removed && !t?.isAllMembersOffline(), undefined, undefined, true));
	}
	matchingInit() {
		this.matchingTeams_Tell(
			"個人試合申請を送信しました",
			`個人試合申請を受信しました\n受諾する場合は /${constants.NS("accept")} ${this.originalID}`,
			"チーム試合申請を送信しました",
			`チーム試合申請を受信しました\n受諾する場合は /${constants.NS("accept")} ${this.originalID}`
		);
		this.setStatusIndex(0);
		this.execMatching_WM_pending(true);
	}
	matchingAccepted() {
		this.execMatching_WM_pending(false);
		this.matchingTeams_Tell(
			"個人試合申請が受諾されました",
			"個人試合申請を受諾しました",
			"チーム試合申請が受諾されました",
			"チーム試合申請を受諾しました",
			`試合会場の解放後に自動でテレポートします`
		);
		this.execMatching_WM_waiting(true);
	}
	matchingCanceled() {
		if (this.isTeleporting)
			return this.tell(`テレポート準備中は試合の棄却ができません`, "err");
		this.matchingTeams_Tell(
			"個人試合申請が拒否されました",
			"個人試合申請を拒否しました",
			"チーム試合申請が拒否されました",
			"チーム試合申請を拒否しました"
		);
		if (this.isBeforeFighting) {
			this.execMatching_WM_pending(false);
			this.setStatusIndex(4);
		} else if (this.isPreFighting || this.isFighting) {
			this.execMatching_WM_waiting(false);
			this.setStatusIndex(4);
			this.status_timer[this.status_index].myFunc = T => {
				this.matchingTeams_Gamemode_Title_Sound(-1, T.secondsStr, constants.CALC_MCS(1), "", "vault.eject_item");
			};
			this.status_timer[this.status_index].myEndFunc = () => {
				this.matchingTeams_Gamemode_Title_Sound(2, "移動完了", constants.CALC_MCS(1), "", "");
				this.matchingTeams_Teleport_setSpawnPoint_EditNameTag();
				this.isTeleporting = false;
				this.matchingAfterProcess();
			};
			this.processTeamsPidArr(p => p.setGamemode(3));
			this.isTeleporting = true;
			this.status_timer[this.status_index].start();
		}
	}
	matchingBeforeProcess() {
		this.processTeamsPidArr(p => p.removeSelectedTags(constants.NS(constants.NS("setup_complete", "match"))));
		this.matchingTeams_InventoryClear_GiveAccesstem();
		this.matchingTeams_GiveMyItems();
	}
	matchingAfterProcess() {
		if (this.type_index === 3) {
			const t = Team.findTeam(this.teams_id[1]);
			if (t)
				t.removeTeam();
		}
		this.processTeamsPidArr(p => {
			if (p.isMCPlayer) {
				if (!this.isCanceled)
					p.assignMatchKillsForKill();
			} else
				p.kill();
		});
		this.matchingTeams_ClearMyItems();
		this.matchingTeams_InventoryClear_GiveAccesstem();
		updateOnlinePlayerLength();
	}
	matchingMovePreFightingRoom() {
		const str = `${GSO.limit.match.time.before_fighting.max}秒後にテレポートします`;
		this.matchingTeams_Tell(str, str);
		this.status_timer[this.status_index].myFunc = T => {
			if (this.isCanceled)
				T.stop();
			this.matchingTeams_Gamemode_Title_Sound(-1, T.secondsStr, constants.CALC_MCS(1), "", "vault.eject_item");
		};
		this.status_timer[this.status_index].myEndFunc = () => {
			if (this.isCanceled)
				return;
			this.matchingBeforeProcess();
			this.isTeleporting = false;
			this.matchingPreStart();
		};
		this.isTeleporting = true;
		this.status_timer[this.status_index].start();
	}
	matchingPreStart() {
		this.setStatusIndex(1);
		this.matchingTeams_Teleport_setSpawnPoint_EditNameTag();
		this.matchingTeams_Gamemode_Title_Sound(2, "- 試合準備 -", constants.CALC_MCS(1), "", "random.toast");
		this.status_timer[this.status_index].myFunc = T => {
			if (this.isCanceled)
				T.stop();
			this.matchingTeams_Gamemode_Title_Sound(-1, T.secondsStr, constants.CALC_MCS(1), "", "vault.eject_item");
		};
		this.status_timer[this.status_index].myEndFunc = () => {
			if (!this.isCanceled) {
				this.isTeleporting = false;
				this.matchingStart();
			}
		};
		this.isTeleporting = true;
		this.status_timer[this.status_index].start();
	}
	matchingStart() {
		this.setStatusIndex(2);
		this.matchingTeams_Gamemode_Title_Sound(2, "試合開始", constants.CALC_MCS(3), "", "raid.horn", { volume: 1.5, pitch: 1.5 });
		this.matchingTeams_Teleport_setSpawnPoint_EditNameTag();
		this.status_timer[this.status_index].myFunc = T => {
			if (this.isCanceled)
				T.stop();
			this.processTeamsPidArr(p => p.setSubtitle(T.timeLimitStr, "r"));
			if (T.seconds % GSO.limit.match.time[this.status].min === 0)
				this.fighting_countdown = T.totalSeconds;
		};
		this.status_timer[this.status_index].myEndFunc = () => {
			if (!this.isCanceled)
				this.matchingFinish();
		};
		this.status_timer[this.status_index].start();
	}
	matchingFinish() {
		this.setStatusIndex(3);
		this.matchingTeams_Gamemode_Title_Sound(3, "試合終了", constants.CALC_MCS(3), "", "random.toast");
		this.status_timer[this.status_index].myFunc = T => {
			if (this.isCanceled)
				T.stop();
			this.processTeamsPidArr(p => p.setTitle(`あと${T.secondsStr}秒でテレポートします`, constants.CALC_MCS(2), ""));
		};
		this.status_timer[this.status_index].myEndFunc = () => {
			if (this.isCanceled)
				return;
			this.matchingTeams_Gamemode_Title_Sound(2, "移動します...", constants.CALC_MCS(1), "", "");
			this.matchingTeams_Teleport_setSpawnPoint_EditNameTag();
			this.isTeleporting = false;
			this.matchingAfterProcess();
			this.execMatching_WM_waiting(false);
		};
		this.isTeleporting = true;
		this.status_timer[this.status_index].start();
	}
	matchingTeams_InventoryClear_GiveAccesstem() {
		this.processTeamsPidArr(p => {
			if (constants.DEBUG_MODE && !p.getGamemode(1) && p.isMCPlayer) {
				p.inventoryClearAll();
				p.giveItemForSlot(constants.NS("kikaku_accesstem", "dashkikaku"), 1, 8);
			}
		});
	}
	matchingTeams_GiveMyItems() {
		if (constants.DEBUG_MODE && !p.getGamemode(1) && p.isMCPlayer)
			this.processTeamsPidArr(p => Match.equipMatchingWeaponAndArmor(p));
	}
	matchingTeams_ClearMyItems() {
		this.processTeamsPidArr(p => {
			if (constants.DEBUG_MODE && !p.getGamemode(1) && p.isMCPlayer)
				Match.equipNothing(p);
		});
	}
	matchingTeams_Teleport_setSpawnPoint_EditNameTag() {
		this.processTeamsPidArr((p, i) => {
			if (Object.hasOwn(GSO.limit.field[this.field_index].location, this.status)) {
				if (this.isFighting || this.isFinished || this.isCanceled)
					p.nameTag = this.isFighting ? "" : p.name;
				const _idx = p.checkEnemyEntity(this.field_index) ? 2 : i;
				const arr = GSO.limit.field[this.field_index].location[this.status][_idx];
				p.setSpawnPoint(...arr);
				p.teleport(...arr);
			}
		});
	}
	matchingTeams_Gamemode_Title_Sound(mode_index = 0, ttl = "", dur = constants.CALC_MCS(1), sbttl = "", src = "", opt = {}) {
		this.processTeamsPidArr(p => {
			if (mode_index >= 0 && !p.getGamemode(1))
				p.setGamemode(mode_index);
			if (ttl)
				p.setTitle(ttl, dur, sbttl);
			if (src)
				p.playSound(src, opt);
		});
	}
	matchingTeams_Tell(s_str_p = "", r_str_p = "", s_str_t = s_str_p, r_str_t = r_str_p, all_add_str = "") {
		const str_p = new Array(this.teams_pid_arr.length)
			.fill([`${r_str_p}\nID: ${this.originalID}\n${all_add_str}`, "crt"])
			.map((v, _i) => _i === 0 ? [`${s_str_p}\nID: ${this.originalID}\n${all_add_str}`, "crt"] : v);
		const str_t = new Array(this.teams_pid_arr.length)
			.fill([`${r_str_t}\nID: ${this.originalID}\n${all_add_str}`, "crt"])
			.map((v, _i) => _i === 0 ? [`${s_str_t}\nID: ${this.originalID}\n${all_add_str}`, "crt"] : v);
		this.processTeamsPidArr((p, i) => p.tell(...str_p[i]), (p, i) => p.tell(...str_t[i]));
	}
	processTeams(_id, p_fn, t_fn, insteadOfArg_P = undefined, insteadOfArg_T = undefined) {
		if (this.type_index === 0 || this.type_index === 2) {
			const p = Player.findOnlinePlayer(_id);
			return p_fn(p ? p : insteadOfArg_P);
		} else if (this.type_index === 1 || this.type_index === 3) {
			const t = Team.findTeam(_id);
			return t_fn(t ? t : insteadOfArg_T);
		}
	}
	/**
	 * 
	 * @param {Function} p_fn 
	 * @param {Function} t_fn 
	 * @returns 
	 */
	processTeamsPidArr(p_fn, t_fn = p_fn, allow_offline = false) {
		let p_mode = undefined;
		if ([0, 2].some(v => this.type_index === v))
			p_mode = true;
		else if ([1, 3].some(v => this.type_index === v))
			p_mode = false;
		else
			return wld.tell(`type_indexが範囲外です\nMatch::processTeamsPidArr`, "err");
		this.teams_pid_arr.forEach((arr, i) => {
			arr.forEach((pid, j) => {
				let p = Player.findOnlinePlayer(pid);
				if (!p && allow_offline)
					p = Player.findPlayer(pid);
				if (p) {
					if (p_mode)
						p_fn(p, i, j);
					else
						t_fn(p, i, j);
				}
			});
		});
	}
	outputData() {
		const data = constants.deepCopyObject(this.data);
		return `\n${Object.entries(data).map(arr => {
			const _func = _pid => (Player.findPlayer(_pid)?.name ?? String(undefined));
			if (arr[0] === "teams_id") {
				arr[1] = "表示が規制されています";
			} else if (arr[0] === "teams_pid_arr")
				arr[1] = `\n${arr[1].map((pid_arr, _i) => `${["申請側", "受諾側", "不明"][_i]} | \n${pid_arr.map(pid => _func(pid)).join(", ")}`).join(", \n")}`;
			return arr.join(": ");
		}).join("\n")}`;
	}
	showData() {
		this.tell(this.outputData());
	}
}