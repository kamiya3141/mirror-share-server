import { system, world } from "@minecraft/server";

import constants from "./config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "./config/Common_GlobalSetting";
import {
	OH_KEYS,
	ALL_PLAYERS_HISTORY,
	ALL_TEAMS_HISTORY,
	ALL_MATCHES_HISTORY,
	ONLINE_PLAYERS,
	WAIT_MATCHES,
	ALL_HISTORY_SAVE_FUNC
} from "./db/ObjectHistoryRepository";
import { wld } from "./world/World";
import { Player } from "./player/Player";
import { TeamRepository } from "./db/TeamRepository";
import { Team } from "./team/Team";
import { Match } from "./match/Match";
import "./subscribe/WorldSubScribe";
import "./subscribe/SystemSubScribe";
import "./command/DashHoloCraftPlus";

const DB_RESET = constants.DEBUG_MODE && false;

function mainInitFunc() {
	if (!wld.get(OH_KEYS["APH"])) wld.set(OH_KEYS["APH"], ALL_PLAYERS_HISTORY);
	if (!wld.get(OH_KEYS["ATH"])) wld.set(OH_KEYS["ATH"], ALL_TEAMS_HISTORY);
	if (!wld.get(OH_KEYS["AMH"])) wld.set(OH_KEYS["AMH"], ALL_MATCHES_HISTORY);
	if (!wld.get(OH_KEYS["WM"])) wld.set(OH_KEYS["WM"], WAIT_MATCHES);
	if (DB_RESET)
		ALL_HISTORY_SAVE_FUNC(wld);

	// これまでのプレイヤー履歴やチームデータなどを復元
	const player_data_history = wld.get(OH_KEYS["APH"]);
	Object.entries(player_data_history).forEach(([id, val]) => {
		if (Object.hasOwn(val, "data"))
			if (id) ALL_PLAYERS_HISTORY[id] = new Player(val.data, true, val.data);	// 入れているのはplayer, worldではないので注意
	});
	const team_data_history = wld.get(OH_KEYS["ATH"]);
	Object.entries(team_data_history).forEach(([id, val]) => {
		if (Object.hasOwn(val, "data")) {
			if (id && !id.includes(TeamRepository.EnemyTeamSymbolStr))
				ALL_TEAMS_HISTORY[id] = new Team(
					val.data.id,
					val.data.name,
					val.data.leader,
					val.data.status_index,
					true,
					val.data
				);
		}
	});
	const match_data_history = wld.get(OH_KEYS["AMH"]);
	Object.entries(match_data_history).forEach(([id, val]) => {
		if (Object.hasOwn(val, "data"))
			if (id)
				ALL_MATCHES_HISTORY[id] = new Match(
					val.data.id,
					val.data.field_index,
					val.data.type_index,
					val.data.teams_id,
					true,
					val.data
				);
	});
	if (constants.DEBUG_MODE)
		console.info(`\n${Object.keys(ALL_TEAMS_HISTORY).join("\n")}`);
	ALL_HISTORY_SAVE_FUNC(wld);
}

function worldSettingInitFunc() {
	wld.gamerule("playerWaypoints", "off");
	wld.gamerule("tntExplodes", false);
}

system.run(() => {
	if (ALLOW_START_SERVER)
		mainInitFunc();
	worldSettingInitFunc();
	console.info(`[${constants.NAME_SPACE_ORIGINAL}] main.js loaded`);
});
