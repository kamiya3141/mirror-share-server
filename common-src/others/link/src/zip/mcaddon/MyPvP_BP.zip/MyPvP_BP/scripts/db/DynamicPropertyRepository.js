import constants from "./../config/constants";

export class DynamicPropertyRepository {
	#keys_key = "keys-key";
	#keys = [];
	constructor (target, ns = "") {
		this.target = target;
		ns = ns ?? "";
		this.ns = constants.NS(ns);
	}

	stdout_ns() {
		console.info(this.ns);
		console.info(`\n${this.#getKeysStr}\n`, "DynamicPropertyRepository::stdout_ns");
	}

	get #getKeysStr() {
		return this.#keys.join(", ");
	}
	set #addKeys(key) {
		if (!this.#keys.includes(key)) {
			this.#keys.push(key);
			this.set(this.#keys_key, this.#keys);
		}
	}
	#delKeys(...keys) {
		keys.forEach(key => {
			if (this.#keys.includes(key))
				this.#keys.splice(this.#keys.indexOf(key), 1);
		});
	}

	has(key) {
		return Boolean(this.get(key) !== null);
	}

	get(key) {
		key = constants.NS(key, this.ns);
		const value = this.target?.getDynamicProperty(key);
		if (typeof value !== "string")
			return null;
		try {
			return JSON.parse(value);
		} catch (error) {
			console.warn(
				`Invalid JSON: ${key}`,
				"DynamicPropertyRepository::get"
			);
			return null;
		}
	}

	set(key, value) {
		key = constants.NS(key, this.ns);
		this.#addKeys = key;
		this.target?.setDynamicProperty(
			key,
			JSON.stringify(value)
		);
		return value;
	}

	delete(key) {
		key = constants.NS(key, this.ns);
		this.target.setDynamicProperty(key, undefined);
		this.#delKeys(key);
		return true;
	}
}