import constants from "./../config/constants";
import { BATTLE_FIELDS_COUNT, LOBBY_LOCATION, GSO, ALLOW_START_SERVER } from "./../config/Common_GlobalSetting";
import {
	ALL_TEAMS_HISTORY
} from "./../db/ObjectHistoryRepository";
import { wld } from "./../world/World";
import { MyPvPEntityRepository } from "./../db/MyPvPEntityRepository";
import { Player } from "./../player/Player";
import { TeamRepository } from "./../db/TeamRepository";

export class Team extends TeamRepository {
	constructor (id, name, leader, status_index, isRestored = false, restoredData = {}, isEnemyTeam = false) {
		const org = constants.generateUUID(constants.CALC_MCC(1));
		if (isEnemyTeam && !isRestored) {
			id = TeamRepository.createEnemyTeamId(org);
			name = TeamRepository.createEnemyTeamName(org);
		} else if (!id)
			id = org;
		super(id, name, leader, status_index, isRestored, restoredData);
		if (!isRestored) {
			this.addMember(leader);
			this.tell(
				`チームが作られました！\nID: ${id}, チーム名: ${name}\nリーダー: ${String(Player.findOnlinePlayer(this.leader)?.name)}`,
				"crt"
			);
			this.saveDB();
		} else if (constants.DEBUG_MODE)
			console.info(`${id} のチームデータを復元しました`);
	}
	static checkIdString(id, pid, allow_error = true) {
		if (GSO.limit.team.id.reg.test(id)) return true;
		if (allow_error)
			Player.findOnlinePlayerTell(
				pid,
				`チームID: ${id}は無効です\n${GSO.limit.team.id.length.min}~${GSO.limit.team.id.length.max}文字の${GSO.limit.team.id.reg_str}のみ登録可能です`,
				"err"
			);
	}
	static checkNameString(name, pid, allow_error = true) {
		if (GSO.limit.team.name.reg.test(name)) return true;
		if (allow_error)
			Player.findOnlinePlayerTell(
				pid,
				`チーム名: ${name}は無効です\n${GSO.limit.team.name.length.min}~${GSO.limit.team.name.length.max}文字の${GSO.limit.team.name.reg_str}のみ登録可能です`,
				"err"
			);
	}
	static checkExistTeam(tid, pid, allow_error = true) {
		if (Object.keys(ALL_TEAMS_HISTORY).includes(tid) && !ALL_TEAMS_HISTORY[tid].removed) return true;
		if (allow_error)
			Player.findOnlinePlayerTell(
				pid,
				`チームID: ${tid}は存在していません`,
				"err"
			);
		return false;
	}
	/**
	 * 
	 * @param {String} tid 
	 * @returns {Team}
	 */
	static findTeam(tid) {
		if (!this.checkExistTeam(tid, null, false)) return undefined;
		return ALL_TEAMS_HISTORY[tid];
	}
	/**
	 *
	 * @param {String} teamName
	 * @returns {String?}
	 */
	static getTeamIdByName(teamName = "", allow_removed = false) {
		const res = Object.values(ALL_TEAMS_HISTORY).find(
			T => T.name === teamName && ((!allow_removed && !T.removed) || allow_removed)
		)?.id;
		return res;
	}
	/**
	 * 
	 * @param {String} pid 
	 * @returns {Team[]}
	 */
	static getAllMyTeamArray(pid) {
		let res_arr = [];
		Object.values(ALL_TEAMS_HISTORY).forEach(team => {
			if (team.existMember(pid) && !team.removed)
				res_arr.push(team);
		});
		return res_arr;
	}
	saveDB(data = null) {
		super.saveDB(data);
		ALL_TEAMS_HISTORY[this.id] = this;
	}
	tell(msg = "", stl = "f") {
		this.members.forEach(id => Player.findOnlinePlayerTell(id, msg, stl));
	}
	addMember(member_id) {
		if (this.members.length >= GSO.limit.team.member.max)
			return this.tell("上限に達したためメンバーを追加できません", "err");
		if (this.existMember(member_id))
			return this.tell(`指定されたプレイヤーは既にメンバーです`);
		this.members = member_id;
		const member = Player.findOnlinePlayer(member_id) ?? Player.findPlayer(member_id);
		member.tag(constants.NS(this.id), 1);
		this.tell(`メンバーを追加しました: ${member.name}`, "crt");
	}
	deleteMember(member_id) {
		if (this.members.length <= GSO.limit.team.member.min)
			return this.tell("下限に達したためメンバーを削除できません", "err");
		if (!this.existMember(member_id))
			return this.tell(`指定されたプレイヤーはメンバーではありません`);
		const member = Player.findOnlinePlayer(member_id) ?? Player.findPlayer(member_id);
		member.tag(constants.NS(this.id), -1);
		member.leaveTeam = this.id;
		this.delMember = member_id;
		this.tell(`メンバーを削除しました: ${member.name}`, "crt");
	}
	removeTeam() {
		this.tell(`チーム名: ${this.name}（ID: ${this.id}）が削除されます`, "dng");
		// 参照渡しで、値が消える可能性があるから
		const _members = [...this.members];
		// 参加している全てのプレイヤーからチームIDを削除
		_members.forEach(mid => {
			const p = Player.findOnlinePlayer(mid);
			if (p)
				p.leaveTeam = this.id;
		});
		this.removed = true;
	}
	setStatusIndex(index = 0) {
		this.status_index = constants.fixInRange(0, index, MyPvPEntityRepository.StatusKindsArray.length - 1);
		this.members.forEach(pid => Player.findPlayer(pid)?.setStatusIndex(index));
		return this.status_index;
	}
	isAllMembersOffline() {
		return this.members.every(pid => Player.findOnlinePlayerIsOffline(pid));
	}
	tag(val = "", mode = 0) {
		this.members.forEach(pid => Player.findOnlinePlayer(pid)?.tag(val, mode));
	}
	setTitle(ttl = "", dur = 0) {
		this.members.forEach(pid => Player.findOnlinePlayer(pid)?.setTitle(ttl, dur));
	}
	setSubtitle(sbttl = "", stl = "") {
		this.members.forEach(pid => Player.findOnlinePlayer(pid)?.setSubtitle(sbttl, stl));
	}
	playSound(src = "", opt = { volume: 1.0, pitch: 1.0 }) {
		this.members.forEach(pid => Player.findOnlinePlayer(pid)?.playSound(src, opt));
	}
	setGamemode(mode_index = 0) {
		this.members.forEach(pid => Player.findOnlinePlayer(pid)?.setGamemode(mode_index));
	}
	teloport(...locs) {
		return (
			!locs.length ?
				(this.tell(`チームのテレポートに失敗しました\nアドオン制作者に連絡してください`, "err"), true) :
				this.members.every(pid => Player.findOnlinePlayer(pid)?.teleport(...locs))
		);
	}
	setSpawnPoint(...locs) {
		return (
			!locs.length ?
				(this.tell(`チームのリスポーン設定に失敗しました\nアドオン制作者に連絡してください`, "err"), true) :
				this.members.every((pid, i) => !!Player.findOnlinePlayer(pid)?.setSpawnPoint(...locs))
		);
	}
	kill() {
		this.members.forEach(pid => Player.findOnlinePlayer(pid)?.kill());
	}
	assignMatchKillsForKill() {
		this.members.forEach(pid => Player.findOnlinePlayer(pid)?.assignMatchKillsForKill());
	}
	/**
	 * 
	 * @param {String} _members 
	 * @returns {Number[]}
	 */
	getKills(_members = this.members) {
		return _members.map(mid => (Player.findOnlinePlayer(mid)?.get("match_kills") ?? 0));
	}
	outputData() {
		const data = constants.deepCopyObject(this.data);
		return `\n${Object.entries(data).map(arr => {
			const _func = _pid => (Player.findPlayer(_pid)?.name ?? String(undefined));
			if (arr[0] === "leader")
				arr[1] = _func(arr[1]);
			else if (arr[0] === "members")
				arr[1] = `\n${arr[1].map(pid => _func(pid)).join(", \n")}`;
			return arr.join(": ");
		}).join("\n")}`;
	}
	showData() {
		this.tell(this.outputData());
	}
}
