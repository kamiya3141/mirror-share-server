#!/bin/bash

arg=$1

play_mp3() {
	file=$1
	mpg123 -o alsa -a default "$file" >/dev/null 2>&1 &
	exit
}

SCRIPT_DIR="/home/tamura/Documents/bluetooth"

if [ -n "$arg" ]; then
	if [ "$arg" = "BEGIN" ]; then
		play_mp3 "$SCRIPT_DIR/cyber-boot-sound.mp3"
	elif [ "$arg" = "AA" ]; then
		play_mp3 "$SCRIPT_DIR/tech-short.mp3"
	else
		play_mp3 "$SCRIPT_DIR/tech-short2.mp3"
	fi
else
	echo -e "\aError: arguments value is NULL !!"
fi

exit