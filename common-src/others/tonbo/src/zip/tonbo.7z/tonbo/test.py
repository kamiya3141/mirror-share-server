import math
import numpy as np
import cv2
import os



base_export_img_dir = "./export/img/png/";

def val_range(v, mn, mx):
	return (mn <= v and v < mx);

def existColorRed(_pix):
	return _pix[0] == 0 and _pix[1] == 0 and _pix[2] == 255;

def existColorWhite(_pix):
	return _pix[0] == 255 and _pix[1] == 255 and _pix[2] == 255;

def searchIndex(img, x, y):
	_img = img;
	_x = x;
	_y = y;
	xmx = len(_img[0]);
	ymx = len(_img);
	xymx = xmx * ymx;
	dir_arr = ((0, 1), (-1, 0));
	hit_white = False;
	hit_dir = False;
	_v = 0;
	for i in range((x * ymx) + y, xymx):
		_x, _y = (i // ymx, i % ymx);
		if existColorWhite(_img[_y][_x]):
			hit_white = True;
			hit_dir = False;
			for c in dir_arr:
				__x, __y = (_x + c[0], _y + c[1]);
				if val_range(__x, 0, xmx) and val_range(__y, 0, ymx) and existColorWhite(_img[__y][__x]):
					hit_dir = True;
					break;
			break;
	return (_x, _y, hit_white, hit_dir);

def strokeRed2(img, x, y):
	_img = img;
	_x = x;
	_y = y;
	hit_count = 0;

	dir_arr = ((0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (-1, 1), (1, -1), (1, 1));
	
	_x_max = len(_img[0]);
	_y_max = len(_img);
	while True:
		_img[_y][_x]= [0, 0, 255];
		hit_count += 1;
		#print(f"{_x}, {_y}");
		hit_white = False;
		for i in range(len(dir_arr)):
			c = dir_arr[i];
			dir_constrain = val_range(_x + c[0], 0, _x_max) and val_range(_y + c[1], 0, _y_max);
			if not dir_constrain:
				continue;
			add_bl = (True if (i < len(dir_arr) / 2) else (existColorRed(_img[_y + c[1]][_x]) or existColorRed(_img[_y][_x + c[0]])));
			if existColorWhite(_img[_y + c[1]][_x + c[0]]) and add_bl:
				_x += c[0];
				_y += c[1];
				hit_white = True;
				break;
		if not hit_white:
			break;
	return (_img, _x, _y, hit_count);

delete_space_pix = 1;

def countRed2(img):
	red_amount = 0;
	x = 0;
	y = 0;
	all_count = 0;
	while True:
		if existColorWhite(img[y][x]):
			img, x, y, h_c = strokeRed2(img, x, y);
			all_count += h_c;
		else:
			x, y, h_w, h_d = searchIndex(img, x, y);
			if not h_d:
				if all_count > delete_space_pix:
					red_amount += 1;
					print("red_amount + 1 !!");
				all_count = 0;
				if not h_w:
					break;
	return (img, red_amount);


def init_img():
	img_map = (
		(0,0,0,2,2,0,2,0),
		(0,0,0,0,0,0,2,0),
		(0,0,0,2,2,0,2,0),
		(0,0,0,2,2,0,2,0),
		(0,0,0,2,2,0,2,0),
		(0,0,0,2,2,0,2,0),
	);
	img_map2 = ((255, 255, 255), (0, 0, 255), (128, 128, 128));

	height, width = (len(img_map), len(img_map[0]));

	img = np.zeros((height, width, 3), dtype=np.uint8);

	for y in range(len(img)):
		for x in range(len(img[y])):
			t_pix = img_map2[img_map[y][x]];
			img[y][x] = [t_pix[0], t_pix[1], t_pix[2]];
	return img;

def main_func():
	img = init_img();
	img, cnt = countRed2(img);
	print(f"\ncount -> {cnt}");
	cv2.imwrite(f"{base_export_img_dir}text.png", img);
	return 0;

main_func();