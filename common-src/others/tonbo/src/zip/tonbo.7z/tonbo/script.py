import math
import numpy as np
import cv2
import os

#2025/07/31/16:00開始

base_img_name = "img";
base_img_dir = "./src/img/png/";
img_num = len(os.listdir(base_img_dir));

img_arr = []
for i in range(img_num):
	img_arr.append(f"{base_img_name} ({str(i + 1)}).png");

base_export_img_dir = "./export/img/png/";
os.makedirs(base_export_img_dir, exist_ok=True);


def val_range(v, mn, mx):
	return (mn <= v and v < mx);

def existColorRed(_pix):
	return _pix[0] == 0 and _pix[1] == 0 and _pix[2] == 255;

def existColorWhite(_pix):
	return _pix[0] == 255 and _pix[1] == 255 and _pix[2] == 255;

#名づけとかは勘弁してくれ (役割は、白黒をはっきりさせて、反転した時に枠を検知しやすくするための関数)
def splitFly(_img, _org_img):
	avr_gr = _org_img.mean(axis=(0, 1)).mean();
	std_gr = cv2.merge([avr_gr, avr_gr, avr_gr]).std(axis=(0, 1)).mean();
	gr = std_gr * 1.75;
	for cl in _img:
		for pix in cl:
			pix[:] = 0 if pix.mean() < gr else 255;
	return _img;

#こいつはchatgpt
def mask_inside_red_circle(img):
	# 画像を複製（元を壊さない）
	original = img.copy()

	# 赤色の範囲を定義（マスク生成）
	lower_red1 = np.array([0, 0, 100])
	upper_red1 = np.array([80, 80, 255])
	mask_red = cv2.inRange(img, lower_red1, upper_red1)

	# 赤い線の輪郭を取得
	contours, _ = cv2.findContours(mask_red, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

	if not contours:
		return img  # 赤い線が見つからなければそのまま返す

	# 最も大きい輪郭（丸）の内側を白いマスクとして使う
	mask = np.zeros_like(mask_red)
	cv2.drawContours(mask, contours, -1, 255, thickness=cv2.FILLED)

	# 3チャンネル化してマスク適用
	mask_3ch = cv2.merge([mask, mask, mask])
	result = np.where(mask_3ch == 255, original, 255).astype(np.uint8)

	return result

def searchIndex(img, x, y):
	_img = img;
	_x = x;
	_y = y;
	xmx = len(_img[0]);
	ymx = len(_img);
	xymx = xmx * ymx;
	dir_arr = ((0, 1), (-1, 0));
	hit_white = False;
	hit_dir = False;
	_v = 0;
	for i in range((x * ymx) + y, xymx):
		_x, _y = (i // ymx, i % ymx);
		if existColorWhite(_img[_y][_x]):
			hit_white = True;
			hit_dir = False;
			for c in dir_arr:
				__x, __y = (_x + c[0], _y + c[1]);
				if val_range(__x, 0, xmx) and val_range(__y, 0, ymx) and existColorWhite(_img[__y][__x]):
					hit_dir = True;
					break;
			break;
	return (_x, _y, hit_white, hit_dir);

def strokeRed2(img, x, y):
	_img = img;
	_x = x;
	_y = y;
	hit_count = 0;

	dir_arr = ((0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (-1, 1), (1, -1), (1, 1));
	
	_x_max = len(_img[0]);
	_y_max = len(_img);
	while True:
		_img[_y][_x]= [0, 0, 255];
		hit_count += 1;
		#print(f"{_x}, {_y}");
		hit_white = False;
		for i in range(len(dir_arr)):
			c = dir_arr[i];
			dir_constrain = val_range(_x + c[0], 0, _x_max) and val_range(_y + c[1], 0, _y_max);
			if not dir_constrain:
				continue;
			add_bl = (True if (i < len(dir_arr) / 2) else (existColorRed(_img[_y + c[1]][_x]) or existColorRed(_img[_y][_x + c[0]])));
			if existColorWhite(_img[_y + c[1]][_x + c[0]]) and add_bl:
				_x += c[0];
				_y += c[1];
				hit_white = True;
				break;
		if not hit_white:
			break;
	return (_img, _x, _y, hit_count);

delete_space_pix = 50;

def countRed2(img):
	red_amount = 0;
	x = 0;
	y = 0;
	all_count = 0;
	while True:
		if existColorWhite(img[y][x]):
			img, x, y, h_c = strokeRed2(img, x, y);
			all_count += h_c;
		else:
			x, y, h_w, h_d = searchIndex(img, x, y);
			if not h_d:
				if all_count > delete_space_pix:
					red_amount += 1;
					print("red_amount + 1 !!");
				all_count = 0;
				if not h_w:
					break;
	return (img, red_amount);

def main_func():
	for c in img_arr:
		img = cv2.imread(base_img_dir + c);
		org_img = img.copy();
		img = mask_inside_red_circle(img);
		img = splitFly(img, org_img);
		img, cnt = countRed2(img);
		export_img_path = base_export_img_dir + c;
		print(export_img_path);
		cv2.imwrite(export_img_path, img);
		print(f"空間の数：{cnt}");
		input("Enterキーを押して終了...");

main_func();


"""

def fillWithoutRedLine(_img):
	pos_list = [-1, 0, 1, 0];
	for i in range(len(_img)):
		cl = _img[i];
		pos_idx = 1 if existColorRed(cl[0]) else 0;
		pix_st = [0, pos_list[pos_idx]];
		for x in range(len(cl)):
			pix = cl[x];
			now_pix_st = [x, pos_list[pos_idx]];
			if existColorRed(pix) and pos_idx != 1 and pos_idx != 3:
				if pos_idx == 0:
					cl[pix_st[0]:now_pix_st[0], : ] = 255;
				pos_idx += 1;
				pix_st = [x, pos_list[pos_idx]];
			elif not existColorRed(pix):
				if pos_idx == 1:
					pos_idx += 1;
					pix_st = [x, pos_list[pos_idx]];
				if pos_idx == 3:
					pos_idx = 0;
					pix_st = [x, pos_list[pos_idx]];
			if x == len(cl) - 1:
				cl[pix_st[0]:len(cl), : ] = 255;

	return _img;

"""