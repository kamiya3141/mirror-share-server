class EjectedRock extends Ball {
	int randomIndex = (int)random(0, Setting.ejectedRockPImageArray.length);
	float allowUpdateTime = random(2.0, 10.0);
	boolean broken = false;
	PImage img;
	EjectedRock(float x, float y, float r) {
		super(x, y, r);
		this.vx = random(r / 16, r / 8);
		this.img = Setting.ejectedRockPImageArray[this.randomIndex];
		// this.setEffectAudioFilePath(Setting.audioSrcBase + "through.mp3");
		this.setEffectAudioFilePath(Setting.audioSrcBase + "brake/" + this.randomIndex + ".mp3");
		this.effectAudioArrayIndex = 0;
		this.effectAudioStartDefault = false;
		this.effectAudioAutoPlay = false;
		this.allowUpdate = false;
	}
	@Override
	void show() {

		if (this.touchFloor && !this.broken) {
			this.startEffectAudio();
			this.broken = true;
		}

		if (Setting.getViewPortPositionX() < this.x && this.x < Setting.getViewPortPositionX() + Setting.fcvw && Setting.getViewPortPositionY() < this.y && this.y < Setting.getViewPortPositionY() + Setting.fcvh)
			image(this.img, Setting.calcCanvasExportX(this.x - this.r / 2), Setting.calcCanvasExportY(this.y - this.r / 2), Setting.calcCanvasExportR(this.r), Setting.calcCanvasExportR(this.r));
	}
}