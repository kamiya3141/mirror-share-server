import java.util.*;
import processing.serial.*;
import processing.sound.*;

Serial serialPort;
boolean firstContact = false;

byte[] inByte = new byte[3];

int oval;

int mouseButtonMinusValue = 37, oval_min = 15, oval_max = 125;

// ############################################################################################################################


boolean DEBUGMODE = false;


boolean mbLeftFlagIndexIsOne = true;


int mbLeftInitOval = oval_min;
int mbLeftOval = oval_min + 90;


int mbRightInitOval = oval_min;
int mbRightOval = oval_min + 90;

// ############################################################################################################################

int mbLeftFlagIndex = (mbLeftFlagIndexIsOne ? 1 : 2), mbRightFlagIndex = (mbLeftFlagIndexIsOne ? 2 : 1);

boolean outputRealBall = false;

int mouseClickIndex = 0;

Ball ball;
Bullet bullet;
int EjectedRockArrayLength = 20;
ArrayList<EjectedRock> EjectedRockArray = new ArrayList<EjectedRock>();
// float[] EjectedRockAllowUpdateTimeArray = new float[EjectedRockArrayLength] = {9.766613,	8.086761,	7.70033,	4.71082,	2.685443,	2.3490858,	6.9041576,	9.17322,	5.054592,	5.69138,	9.210579,	8.54037,	5.462342,	6.0994687,	4.6519003,	9.727555,	5.1784854,	3.7476354,	8.971666};
float[] EjectedRockAllowUpdateTimeArray = {
	9.766613, 8.086761, 7.70033, 4.71082, 2.685443,
	2.3490858, 6.9041576, 9.17322, 5.054592,
	5.69138, 9.210579, 8.54037, 5.462342,
	6.0994687, 4.6519003, 9.727555,
	5.1784854, 3.7476354, 8.971666, 8.612345
};

int EnvironmentEffectAudioArrayLength = 15;
int EnvironmentEffectAudioArrayIndex = 0, EnvironmentEffectAudioArrayAvailableMaxIndex = 0;
String EnvironmentEffectAudioFilePath = "";
boolean EnvironmentEffectAudioFinished = false, EnvironmentEffectAudioStarted = false;

SoundFile[] EnvironmentEffectAudioArray = new SoundFile[EnvironmentEffectAudioArrayLength];

PImage backgroundImg, dokanImg, warningMarkImg, cannonImg;

int warningColorAlpha = 0;
int last = 0;
float countTimeAfterEruption = 0;

void settings() {
	// fullScreen();
	size((int)Setting.fcvw,(int)Setting.fcvh);
	Setting.init(this);
}

void setup() {
	surface.setResizable(true);
	textFont(createFont("https://kamiya3141.github.io/mirror-share-server/common-src/css/font/Explex/ttf/Explex/Explex-Regular.ttf", 16));

	Setting.setViewPortPosition(Setting.fcvw * 2, Setting.fcvh * 2);
	Setting.setCanvasScale(1);
	// 多分bulletは使わないかも
	bullet = new Bullet(Setting.fcvw * 7 / 10, Setting.fcvh * 7 / 10, Setting.fcvh / 8);
	bullet.allowPhysicalEffect = false;
	ball = new Ball(Setting.fcvw * 4 / 10, Setting.fcvh * 0.1 / 10, Setting.fcvh / 8);

	for (int i = 0; i < EjectedRockArrayLength; i++) {
		EjectedRockArray.add(new EjectedRock(random(Setting.fcvh / 8, Setting.fcvw * 4 / 5 - Setting.fcvh / 8), -Setting.fcvh * random(0.1, 1) / 10, Setting.fcvh / 8));
		EjectedRockArray.get(i).allowUpdateTime = EjectedRockAllowUpdateTimeArray[i];
		// println(EjectedRockArray.get(i).allowUpdateTime);
	}

	setEnvironmentEffectAudioFilePath("fall3");
	setEnvironmentEffectAudioFilePath("bupigan");
	setEnvironmentEffectAudioFilePath("keihou");
	setEnvironmentEffectAudioFilePath("muon");
	setEnvironmentEffectAudioFilePath("ready-shot");
	setEnvironmentEffectAudioFilePath("shot");
	setEnvironmentEffectAudioFilePath("muon");
	setEnvironmentEffectAudioFilePath("eruption-before");
	setEnvironmentEffectAudioFilePath("eruption-after");	// 8
	setEnvironmentEffectAudioFilePath("iyo");
	setEnvironmentEffectAudioFilePath("muon");
	setEnvironmentEffectAudioFilePath("pon");

	EnvironmentEffectAudioArrayIndex = 0;

	backgroundImg = loadImage(Setting.imageSrcBase + "background.png");
	dokanImg = loadImage(Setting.imageSrcBase + "dokan.png");
	warningMarkImg = loadImage(Setting.imageSrcBase + "warning-mark.png");
	cannonImg = loadImage(Setting.imageSrcBase + "cannon.png");
	frameRate(60);

	String[] portNameArray = Serial.list();
	for (String v : portNameArray)
		println(v);
	
	String portName = (portNameArray.length == 0 ? "AHAHA" : portNameArray[2]);
	/*
	serialPort = new Serial(this, portName, 9600);
	serialPort.buffer(inByte.length);
	*/

	oval = mbLeftInitOval;
	sendServo(mbLeftFlagIndex);
	oval = mbRightInitOval;
	sendServo(mbRightFlagIndex);
	// ############################################################################################################################
	
	EnvironmentEffectAudioArrayIndex = 7;

	// ############################################################################################################################


}

void draw() {
	background(220);
	if (Setting.animationStart)
		main();
}

void main() {
	background(128);
	push();
	stroke(0);
	for (float i = 0; i < Setting.cvscaleTimesMax; i++) {
		line(Setting.calcCanvasExportX(0), Setting.calcCanvasExportY(Setting.fcvh * i), Setting.calcCanvasExportX(Setting.org_cvw), Setting.calcCanvasExportY(Setting.fcvh * i));
		line(Setting.calcCanvasExportX(Setting.fcvw * i), Setting.calcCanvasExportY(0), Setting.calcCanvasExportX(Setting.fcvw * i), Setting.calcCanvasExportY(Setting.org_cvh));
	}
	pop();

	image(backgroundImg, 0, 0, Setting.fcvw, Setting.fcvh);

	ball.update();

	drawDokan();

	text(countTimeAfterEruption, 100, 100);

	if (EnvironmentEffectAudioArrayIndex == 2) {
		warningColorAlpha += 128 / 60;
		warningColorAlpha %=  128;
		push();
		fill(255, 0, 0, warningColorAlpha);
		rect(0, 0, Setting.fcvw, Setting.fcvh);
		pop();
		drawWarningMark();
	} else if (EnvironmentEffectAudioArrayIndex > 2) {
		drawCannon();
		if (EnvironmentEffectAudioArrayIndex >= 8) {

			if (millis() - last >= 1000) {
				last = millis();
				countTimeAfterEruption += 1.0;
			}

			for (EjectedRock ej : EjectedRockArray) {
				if (ej.allowUpdateTime < countTimeAfterEruption)
					ej.allowUpdate = true;
				ej.update();
			}

			if (countTimeAfterEruption >= 9 && !outputRealBall) {
				oval = mbRightOval;
				sendServo(mbRightFlagIndex);
			}
		}
		if (EnvironmentEffectAudioArrayIndex >= 10) {
			push();
			fill(128, 128, 128, 180);
			rect(0, 0, Setting.fcvw, Setting.fcvh);
			fill(255);
			textAlign(CENTER, CENTER);
			textSize(Setting.fcvh / 6);
			text("噴火の際には", Setting.fcvw / 2, Setting.fcvh / 6);
			pop();
		}
		if (EnvironmentEffectAudioArrayIndex >= 11) {
			push();
			fill(255, 5, 5);
			textAlign(CENTER, CENTER);
			textSize(Setting.fcvh / 4.5);
			text("噴石にご注意を", Setting.fcvw / 2, Setting.fcvh * 2.5 / 4);
			pop();
		}
	}

	updateEnvironmentEffectAudio();

}

// ゴミプロ
void drawDokan() {
	image(dokanImg, Setting.fcvw * 4 / 10 - Setting.fcvh / 8, Setting.fcvh - Setting.fcvh / 4, Setting.fcvh / 4, Setting.fcvh / 2);
}
void drawWarningMark() {
	image(warningMarkImg, Setting.fcvw / 2 - Setting.fcvw / 4, Setting.fcvh / 2 - Setting.fcvh / 4, Setting.fcvw / 2, Setting.fcvh / 2);
}
void drawCannon() {
	image(cannonImg, Setting.fcvw * 1.5 / 10 - Setting.fcvw / 8, Setting.fcvh - Setting.fcvh / 4, Setting.fcvw / 4, Setting.fcvh / 4);
}

void setEnvironmentEffectAudioFilePath(String _path) {
	EnvironmentEffectAudioFilePath = _path;
	if (checkExistEnvironmentEffectAudio()) {
		EnvironmentEffectAudioArray[EnvironmentEffectAudioArrayIndex] = new SoundFile(Setting.myPApplet, Setting.audioSrcBase + EnvironmentEffectAudioFilePath + ".mp3");
		EnvironmentEffectAudioArrayIndex++;
		EnvironmentEffectAudioArrayAvailableMaxIndex++;
	}
}

void startEnvironmentEffectAudio() {
	if (checkPlayableEnvironmentEffectAudio()) {
		if (!EnvironmentEffectAudioArray[EnvironmentEffectAudioArrayIndex].isPlaying())
			EnvironmentEffectAudioArray[EnvironmentEffectAudioArrayIndex].play();
	}
}
boolean checkExistEnvironmentEffectAudio() {
	return (EnvironmentEffectAudioFilePath.length() > 0 && EnvironmentEffectAudioArrayIndex < EnvironmentEffectAudioArrayLength);
}
boolean checkPlayableEnvironmentEffectAudio() {
	return (checkExistEnvironmentEffectAudio() && EnvironmentEffectAudioArrayIndex < EnvironmentEffectAudioArrayAvailableMaxIndex);
}
void resetEnvironmentEffectAudioArrayVarsValue() {
	if (checkExistEnvironmentEffectAudio()) {
		EnvironmentEffectAudioFinished = false;
		EnvironmentEffectAudioStarted = false;
	}
}


void updateEnvironmentEffectAudio() {
	if (checkPlayableEnvironmentEffectAudio()) {
		// startEnvironmentEffectAudio();
		EnvironmentEffectAudioFinished = (EnvironmentEffectAudioStarted && !EnvironmentEffectAudioArray[EnvironmentEffectAudioArrayIndex].isPlaying());
		EnvironmentEffectAudioStarted = (!EnvironmentEffectAudioFinished && EnvironmentEffectAudioArray[EnvironmentEffectAudioArrayIndex].isPlaying());
		// EnvironmentEffectAudioArrayIndex += (EnvironmentEffectAudioFinished ? 1 : 0);
		if (!EnvironmentEffectAudioArray[EnvironmentEffectAudioArrayIndex].isPlaying()) {
			EnvironmentEffectAudioArrayIndex++;
			startEnvironmentEffectAudio();
			// ゴミプロ
			if (EnvironmentEffectAudioArrayIndex == 8) {
				oval = mbLeftOval;
				sendServo(mbLeftFlagIndex);
			}
		}
		
		// resetEnvironmentEffectAudioArrayVarsValue();
	}
}

void mousePressed(MouseEvent event) {
	if (DEBUGMODE) {
		int mouse_value = (((int)event.getButton() - mouseButtonMinusValue) < 1 ? mbLeftFlagIndex : mbRightFlagIndex);
		int[] RLOvalArray = {0, mbLeftInitOval, mbRightInitOval};
		if (!mbLeftFlagIndexIsOne) {
			RLOvalArray[1] = mbRightInitOval;
			RLOvalArray[2] = mbLeftInitOval;
		}
		oval = RLOvalArray[mouse_value];
		sendServo(mouse_value);
	} else {
		if (mouseClickIndex == 0) {
			Setting.animationStart = true;
			startEnvironmentEffectAudio();
			mouseClickIndex++;
		}
	}
}
void mouseReleased(MouseEvent event) {
	if (DEBUGMODE) {
		int mouse_value = (((int)event.getButton() - mouseButtonMinusValue) < 1 ? mbLeftFlagIndex : mbRightFlagIndex);
		int[] RLOvalArray = {0, mbLeftOval, mbRightOval};
		if (!mbLeftFlagIndexIsOne) {
			RLOvalArray[1] = mbRightOval;
			RLOvalArray[2] = mbLeftOval;
		}
		oval = RLOvalArray[mouse_value];
		sendServo(mouse_value);
	}
}

void mouseWheel(MouseEvent event) {
	float new_cvscalse = Setting.getCanvasScale() + 1 / (Setting.cvscaleTimesMax * 10 * event.getCount());
	// Setting.setCanvasScale(new_cvscalse);
}


void serialEvent(Serial port) {
	inByte = port.readBytes();
	
	if (firstContact == false) {
		if (inByte[0] == 'C') {
			port.clear();
			firstContact = true;
		}
	}
}

void sendServo(int id) {
	if (!firstContact) return;
	oval = (int)constrain(oval, oval_min, oval_max);
	serialPort.write((byte)'S');
	serialPort.write((byte)id);
	serialPort.write((byte)oval);
}