static class Setting {
	public static final float fcvw = 1366;
	public static final float fcvh = 768;
	public static final float cvscaleTimesMax = 3;
	private static float cvscale = 1;
	private static float cvx = 0;
	private static float cvy = 0;
	public static final float org_cvw = Setting.fcvw * Setting.cvscaleTimesMax;
	public static final float org_cvh = Setting.fcvh * Setting.cvscaleTimesMax;
	private static float cvw = Setting.org_cvw;
	private static float cvh = Setting.org_cvh;
	private static float vpx = 0;
	private static float vpy = 0;
	private static final float vpw = Setting.fcvw;
	private static final float vph = Setting.fcvh;

	public static String srcBase = "./src/";
	public static String audioSrcBase = Setting.srcBase + "mp3/";
	public static String imageSrcBase = Setting.srcBase + "png/";

	private static boolean animationStart = false;
	public static float gravity = 9.8 / 12;

	public static PImage[] ejectedRockPImageArray = new PImage[5];

	public static PApplet myPApplet;

	public static void init(PApplet app) {
		Setting.myPApplet = app;
		for (int i = 0; i < Setting.ejectedRockPImageArray.length; i++)
			Setting.ejectedRockPImageArray[i] = Setting.myPApplet.loadImage(Setting.imageSrcBase + "EjectedRock/" + str(i) + ".png");
	}
	
	public static boolean getAnimationStart() {
		return Setting.animationStart;
	}
	public static void setAnimationStart(boolean _tf) {
		Setting.animationStart = _tf;
	}
	public static float getViewPortPositionX() {
		return Setting.vpx;
	}
	public static float getViewPortPositionY() {
		return Setting.vpy;
	}
	public static void setViewPortPosition(float _vpx, float _vpy) {
		Setting.vpx = constrain(_vpx, 0, Setting.cvw - Setting.vpw);
		Setting.vpy = constrain(_vpy, 0, Setting.cvh - Setting.vph);
	}
	private static void calcViewPortPosition(float _pre_scl) {
		float _times = Setting.cvscale / _pre_scl;
		Setting.setViewPortPosition(Setting.vpx * _times, Setting.vpy * _times);
	}
	public static float getCanvasPositionX() {
		return Setting.cvx;
	}
	public static float getCanvasPositionY() {
		return Setting.cvy;
	}

	private static void setCanvasPosition(float _cvx, float _cvy) {
		Setting.cvx = constrain(_cvx, Setting.vpw - Setting.cvw, 0);
		Setting.cvy = constrain(_cvy, Setting.vph - Setting.cvh, 0);
	}
	private static void calcCanvasPosition(float _pre_scl) {
		Setting.setCanvasPosition(-Setting.vpx, -Setting.vpy);
	}

	public static float getCanvasSizeW() {
		return Setting.cvw;
	}
	public static float getCanvasSizeH() {
		return Setting.cvh;
	}
	private static void setCanvasSize(float _cvw, float _cvh) {
		Setting.cvw = constrain(_cvw, 0, Setting.fcvw * Setting.cvscaleTimesMax);
		Setting.cvh = constrain(_cvh, 0, Setting.fcvh * Setting.cvscaleTimesMax);
	}
	private static void calcCanvasSize(float _pre_scl) {
		float _times = Setting.cvscale / _pre_scl;
		Setting.setCanvasSize(Setting.cvw * _times, Setting.cvh * _times);
	}

	public static float getCanvasScale() {
		return Setting.cvscale;
	}
	public static void setCanvasScale(float _scl) {
		float _pre_scl = Setting.cvscale;
		Setting.cvscale = constrain(_scl, 1 / Setting.cvscaleTimesMax, 1);

		Setting.calcCanvasSize(_pre_scl);
		Setting.calcViewPortPosition(_pre_scl);
		Setting.calcCanvasPosition(_pre_scl);
	}

	// 外部
	public static float calcCanvasExportX(float _x) {
		return Setting.cvx + (_x * Setting.cvscale);
	}
	public static float calcCanvasExportY(float _y) {
		return Setting.cvy + (_y * Setting.cvscale);
	}
	public static float calcCanvasExportR(float _r) {
		return _r * Setting.cvscale;
	}
}

/*

フリー音源のリンク:
	流れ星02: https://on-jin.com/sound/listshow.php?pagename=ta&title=%E6%B5%81%E3%82%8C%E6%98%9F02&janl=%E3%81%9D%E3%81%AE%E4%BB%96%E9%9F%B3&bunr=%E6%98%9F&kate=%E6%93%AC%E9%9F%B3%E3%83%BB%E3%82%AA%E3%83%8E%E3%83%9E%E3%83%88%E3%83%9A
	災害・火山噴火: https://on-jin.com/sound/listshow.php?pagename=kan&title=%E7%81%BD%E5%AE%B3%E3%83%BB%E7%81%AB%E5%B1%B1%E5%99%B4%E7%81%AB&janl=%E7%92%B0%E5%A2%83%E7%B3%BB%E9%9F%B3&bunr=%E7%81%AB%E5%B1%B1&kate=%E7%81%AB
	爆破・爆発02: https://on-jin.com/sound/listshow.php?pagename=sen&title=%E7%88%86%E7%A0%B4%E3%83%BB%E7%88%86%E7%99%BA02&janl=%E6%88%A6%E9%97%98%E7%B3%BB%E9%9F%B3&bunr=%E7%88%86%E7%A0%B4&kate=%E7%88%86%E7%99%BA%E3%83%BB%E8%A1%9D%E6%92%83
	
	建物が大きく崩れる1: https://soundeffect-lab.info/sound/battle/mp3/building-collapse1.mp3
	建物が大きく崩れる2: https://soundeffect-lab.info/sound/battle/mp3/building-collapse2.mp3
	崖崩れ: https://soundeffect-lab.info/sound/various/mp3/cliff-failure1.mp3

	ぶっぴがん: https://www.myinstants.com/media/sounds/butsupigan-from-ms-gundam.mp3

	https://otologic.jp/free/se/motion-falling-whistle01.html
	https://www.senses-circuit.com/sounds/se/iyopon/
*/