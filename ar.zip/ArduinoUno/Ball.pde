class Ball {
	float x, y, r;
	float vx, vy;
	int col, alpha;
	boolean allowUpdate = true, allowPhysicalEffect = true, touchFloor = false;
	String effectAudioFilePath = "";

	int effectAudioArrayIndex = 0, effectAudioArrayAvailableMaxIndex = 0, effectAudioArrayLength = 5;
	SoundFile[] effectAudioArray = new SoundFile[this.effectAudioArrayLength];

	SoundFile effectAudio;
	boolean effectAudioStarted = false, effectAudioFinished = false;
	boolean effectAudioStartDefault = true, effectAudioAutoPlay = true;
	Ball(float x, float y, float r) {
		this.x = Setting.getViewPortPositionX() + x;
		this.y = Setting.getViewPortPositionY() + y;
		this.r = r;
		this.vx = 0;
		this.vy = 0;
		this.col = #000000;
		this.alpha = 255;
	}
	void setColor(int _col) {
		this.col = constrain(_col, #000000, #ffffff);
	}
	void setAlpha(int _alpha) {
		this.alpha = constrain(_alpha, 0, 255);
	}
	void setColorAndAlpha(int _col, int _alpha) {
		this.setColor(_col);
		this.setAlpha(_alpha);
	}
	void setEffectAudioFilePath(String _path) {
		this.effectAudioFilePath = _path;
		if (this.checkExistEffectAudio()) {
			this.effectAudioArray[this.effectAudioArrayIndex] = new SoundFile(Setting.myPApplet, this.effectAudioFilePath);
			this.effectAudioArrayIndex++;
			this.effectAudioArrayAvailableMaxIndex++;
		} else
			this.effectAudioArrayIndex = 0;
	}
	void startEffectAudio() {
		if (this.checkPlayableEffectAudio()) {
			if (!this.effectAudioArray[this.effectAudioArrayIndex].isPlaying())
				this.effectAudioArray[this.effectAudioArrayIndex].play();
		}
	}
	boolean checkExistEffectAudio() {
		return (this.effectAudioFilePath.length() > 0 && this.effectAudioArrayIndex < this.effectAudioArrayLength);
	}
	boolean checkPlayableEffectAudio() {
		return (this.checkExistEffectAudio() && this.effectAudioArrayIndex < this.effectAudioArrayAvailableMaxIndex);
	}
	void resetEffectAudioArrayVarsValue() {
		if (this.checkExistEffectAudio()) {
			this.effectAudioFinished = false;
			this.effectAudioStarted = false;
		}
	}

	void show() {
		push();
		noStroke();
		fill(this.col);
		circle(Setting.calcCanvasExportX(this.x), Setting.calcCanvasExportY(this.y), Setting.calcCanvasExportR(this.r));
		pop();
	}
	void update() {
		if (!this.allowUpdate)
			return;
		this.updateGravity();

		this.updateXY();
		
		this.x = constrain(this.x, this.r / 2, Setting.org_cvw - this.r / 2);
		this.y = constrain(this.y, this.r / 2, Setting.org_cvh - this.r / 2);
		
		this.show();

		this.updateEffectAudio();
	}
	void updateXY() {
		if (!this.allowPhysicalEffect)
			return;
		this.x += this.vx;
		this.y += this.vy;
	}
	void updateGravity() {
		if (!this.allowPhysicalEffect)
			return;
		// 着地と同時に等加速度直線運動を止める
		if (this.y > Setting.org_cvh - this.r) {
			this.vx = 0;
			this.touchFloor = true;
			if (this.effectAudioStartDefault)
				this.startEffectAudio();
		}
		this.vy += Setting.gravity;
		this.updateVectorXY();
		if (this.touchFloor)
			this.vx = 0;
	}
	void updateVectorXY() {
		this.vx = constrain(this.vx, -this.r * 100, this.r * 100);
		this.vy = constrain(this.vy, -this.r * 100, this.r * 100);
	}
	void updateEffectAudio() {
		if (this.checkPlayableEffectAudio()) {
			//	ここいいね！by 自分
			this.effectAudioFinished = (this.effectAudioStarted && !this.effectAudioArray[this.effectAudioArrayIndex].isPlaying());
			this.effectAudioStarted = (!this.effectAudioFinished && this.effectAudioArray[this.effectAudioArrayIndex].isPlaying());
			// this.effectAudioArrayIndex += (this.effectAudioFinished ? 1 : 0);
			if (this.effectAudioAutoPlay && !this.effectAudioArray[this.effectAudioArrayIndex].isPlaying()) {
				this.effectAudioArrayIndex++;
				this.startEffectAudio();
			}
			// this.resetEffectAudioArrayVarsValue();
		}
	}
}
