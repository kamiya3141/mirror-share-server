class Bullet extends Ball {
	Bullet(float x, float y, float r) {
		super(x, y, r);
	}
	@Override
	void show() {
		push();
		fill(0);
		float rad = atan2(this.vy, this.vx);
		translate(Setting.calcCanvasExportX(this.x), Setting.calcCanvasExportY(this.y));
		rotate(rad);
		float _r = Setting.calcCanvasExportR(this.r);
		float w = _r * 0.5;
		float h = _r * 1.8;
		// head
		triangle(0, 0 - h / 2, 0 - w / 2, 0, 0 + w / 2, 0);
		// body
		rect(0, 0 + h / 4, w, h / 2);
		// right
		triangle(0 + w / 2, 0 + h / 4, 0 + w / 2, 0 + h / 2, 0 + w * 3 / 4, 0 + h / 2);
		// left
		triangle(0 - w / 2, 0 + h / 4, 0 - w / 2, 0 + h / 2, 0 - w * 3 / 4, 0 + h / 2);
		pop();
	}
}
